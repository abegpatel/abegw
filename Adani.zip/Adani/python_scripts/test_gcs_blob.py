from google.cloud import storage

bucket_name = 'sftp_bucket_apsez_datalake'
source_blob_name = 'B.csv'
destination_file_name = '/python_scripts/B.csv'
storage_client = storage.Client()
bucket = storage_client.bucket(bucket_name)
blob = bucket.blob(source_blob_name)
blob.download_to_filename(destination_file_name)
