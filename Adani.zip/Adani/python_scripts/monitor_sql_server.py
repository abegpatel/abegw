import time
import datetime
import pymssql
from threading import Thread

try:
    import pymssql  
    con = pymssql.connect(server='10.81.162.22', user='analytics_user@10.81.162.22', password='analytics$user', database='MercuryDB')  
    cursor = conn.cursor()
except KeyboardInterrupt:
    if cursor:
        cursor.close()
        print("closed")
    if con:
        con.close()
        print("closed 11")

def fetch_data(table_name,cursor):
    while True:
        query = "select count(*) from dbo."+table_name
        try:
            cursor.execute(query)
        except Exception as e:
            print(str(e))
            print(f"QUERY : {query}")
        resp = cursor.fetchone()
        resp = resp[0]
        main_resp = {table_name:[resp,datetime.datetime.now().strftime('%m/%d/%Y, %H:%M:%S')]}
        with open(table_name+'_rowcount.txt','a') as f:
            f.write(str(main_resp)+'\n')
            
        query_latest_record = table_query_dict[table_name]
        cursor.execute(query_latest_record)
        resp_rec = cursor.fetchone()
        resp_rec = resp_rec
        main_resp_rec = {table_name:[resp_rec,datetime.datetime.now().strftime('%m/%d/%Y, %H:%M:%S')]}
        with open(table_name+'_time.txt','a') as f:
            f.write(str(main_resp_rec)+'\n')
        time.sleep(1800)

threads = []

tables = ['dbo.tblVesselCargoInfoOracle']
queries = ["Select top 1 ETLID,INS_UPD_DTTM,TimeStamp from dbo.tblVesselCargoInfoOracle order by INS_UPD_DTTM desc;"]

table_query_dict = dict(zip(tables,queries))

if __name__=='__main__':
    for table in table_query_dict.keys():
        threads.append(Thread(target=fetch_data,args=(table,con.cursor())))
    for t in threads:
        t.start()
    for t in threads:
        t.join()
