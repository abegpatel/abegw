import cx_Oracle
import time
import datetime
from threading import Thread

try:
    con = cx_Oracle.connect('analytics.user1/analyticsuser1@10.202.16.114:1521/ENIPPRD',threaded=True)
    cursor = con.cursor()
except cx_Oracle.DatabaseError as e:
    print("There is a problem with Oracle", e)
except KeyboardInterrupt:
    if cursor:
        cursor.close()
        print("closed")
    if con:
        con.close()
        print("closed 11")

def fetch_data(table_name,cursor):
    while True:
        time.sleep(10)
        query = "select count(*) from "+table_name
        try:
            cursor.execute(query)
        except Exception as e:
            print(str(e))
            print(f"QUERY : {query}")
        resp = cursor.fetchone()
        resp = resp[0]
        main_resp = {table_name:[resp,datetime.datetime.now().strftime('%m/%d/%Y, %H:%M:%S')]}
        with open(table_name+'_rowcount.txt','a') as f:
            f.write(str(main_resp)+'\n')
            
        query_latest_record = table_query_dict[table_name]
        cursor.execute(query_latest_record)
        resp_rec = cursor.fetchone()
        resp_rec = resp_rec
        main_resp_rec = {table_name:[resp_rec,datetime.datetime.now().strftime('%m/%d/%Y, %H:%M:%S')]}
        with open(table_name+'_time.txt','a') as f:
            f.write(str(main_resp_rec)+'\n')

threads = []

tables = ['tos_usr.ctrdtls_o','tos_usr.pty_im']
queries = ["select INT_CTR_NO,TO_CHAR(ADT_UPD_DTTM,'YYYY-MM-DD HH24:MI:SS') from tos_usr.ctrdtls_o where ADT_UPD_DTTM is not null and rownum<=1 order by ADT_UPD_DTTM desc",
          "select ID,TO_CHAR(ADT_UPD_DTTM,'YYYY-MM-DD HH24:MI:SS') from tos_usr.pty_im where ADT_UPD_DTTM is not null and rownum<=1 order by ADT_UPD_DTTM desc"]
table_query_dict = dict(zip(tables,queries))

if __name__=='__main__':
    for table in table_query_dict.keys():
        threads.append(Thread(target=fetch_data,args=(table,con.cursor())))
    for t in threads:
        t.start()
    for t in threads:
        t.join()
