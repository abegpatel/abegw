import subprocess
from time import sleep
while True:
    subprocess.call('gsutil cp /python_scripts/tos_usr.* gs://latency_analysis/ENNORE',shell=True)
    subprocess.call('gsutil cp /python_scripts/ct2_stats/tos_usr.* gs://latency_analysis/CT2',shell=True)
    sleep(900)
