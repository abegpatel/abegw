import cx_Oracle
import time
import datetime
from threading import Thread

try:
    con = cx_Oracle.connect('analytics.user1/analyticsuser1@10.6.145.150:1521/mitosdr',threaded=True)
    cursor = con.cursor()
    print("Connection Successfull")
    print(cx_Oracle.version)
except cx_Oracle.DatabaseError as e:
    print("There is a problem with Oracle", e)
except KeyboardInterrupt:
    if cursor:
        cursor.close()
        print("closed")
    if con:
        con.close()
        print("closed 11")

