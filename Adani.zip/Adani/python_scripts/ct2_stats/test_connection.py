import cx_Oracle

try:
    con = cx_Oracle.connect('analytics_user1/analytics#user1@10.6.63.212:1521/AMCTDR',threaded=True)
    cursor = con.cursor()
    data = cursor.execute("select sysdate from dual")
    data = data.fetchone()
    print(data)
    con.close()
except cx_Oracle.DatabaseError as e:
    print("There is a problem with Oracle", e)
except KeyboardInterrupt:
    if cursor:
        cursor.close()
        print("closed")
    if con:
        con.close()
        print("closed 11")
