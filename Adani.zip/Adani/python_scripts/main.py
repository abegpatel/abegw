import cx_Oracle
import time
try:
    con = cx_Oracle.connect('analytics.user1/analyticsuser1@10.202.16.114:1521/ENIPPRD')
    cursor = con.cursor()
    while True:
        time.sleep(5)
        cursor.execute("select count(*) from tos_usr.ctrdtls_o")
        resp_tos_usr_ctrdtls_o = cursor.fetchone()
        resp = resp[0]
        print(resp)
except cx_Oracle.DatabaseError as e:
    print("There is a problem with Oracle", e)
except KeyboardInterrupt:
    if cursor:
        cursor.close()
        print("closed")
    if con:
        con.close()
        print("closed 11")
