from google.cloud import bigquery 


prod_project_id = 'apsez-svc-prod-datalake'
dataset_id = 'TestDev'
table_id = 'Activity_Based_Costing_Dahej'
client = bigquery.Client()

# endpoint_url = 'https://<>'

def check_new_requests_bq(project_id,dataset_id,table_id):
    query = """select * from {project_id}.{dataset_id}.{table_id}"""
    df = client.query(query).result().to_dataframe()
    result = df.to_dict('records')
    result = json.dumps(result)
    payload_string = result.encode("utf-8")
    print(payload_string)

check_new_requests_bq(project_id,dataset_id,table_id)


