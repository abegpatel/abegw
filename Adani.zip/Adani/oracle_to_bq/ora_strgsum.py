import apache_beam as beam
import time
import jaydebeapi
import os
import argparse
from google.cloud import bigquery
import logging
import sys
from google.cloud import storage as gstorage
import pandas as  pd
from oauth2client.client import GoogleCredentials
from datetime import datetime
import pandas as pd
from apache_beam.options.pipeline_options import PipelineOptions, StandardOptions


class setenv(beam.DoFn):
    def process(self,context):
        import jaydebeapi
        import pandas as pd
        src1='gs://apsez_dataflow_test/dataflow_test_code/dataengineering-master/JAVA_JDK_AND_JAR'
        os.system('gsutil cp '+src1+'/ojdbc6.jar /tmp/' +'&&'+ 'gsutil cp -r '+src1+'/jdk-8u202-linux-x64.tar.gz /tmp/')
        logging.info('Jar copied to Instance..')
        logging.info('Java Libraries copied to Instance..')
        os.system('mkdir -p /usr/lib/jvm  && tar zxvf /tmp/jdk-8u202-linux-x64.tar.gz -C /usr/lib/jvm  && update-alternatives --install "/usr/bin/java" "java" "/usr/lib/jvm/jdk1.8.0_202/bin/java" 1 && update-alternatives --config java')
        logging.info('copying job config file..')
        src2='gs://apsez_dataflow_test/dataflow_test_code/dataengineering-master'
        os.system('gsutil cp '+src2+'/oracle_STRGINVSumM_E.json /tmp/')
        logging.info('copying connection file..')
        src3='gs://apsez_dataflow_test/dataflow_test_code/dataengineering-master'
        os.system('gsutil cp '+src3+'/ora_to_bq_connection_details.json /tmp/')
        logging.info('Enviornment Variable set.')
        return list("1")


class readfromoracle(beam.DoFn):
    def process(self, context):
        import jaydebeapi
        import pandas as pd
        import pandas_gbq as pdq

        json_data = []
        try:
            logging.info('Reading config file..')
            with open('/tmp/oracle_STRGINVSumM_E.json') as json_file:
                json_data = json.load(json_file)
        except Exception as e:
            logging.error(e)

        connection_details = []
        try:
            logging.info('Reading connection file..')
            with open('/tmp/ora_to_bq_connection_details.json') as json_file_1:
                connection_details = json.load(json_file_1)
        except Exception as e:
            logging.error(e)


        database_user= connection_details['IPOS_APMS_HIST'][0]['database_user']
        database_password = connection_details['IPOS_APMS_HIST'][0]['database_password']
        database_host = connection_details['IPOS_APMS_HIST'][0]['database_host']
        database_port = connection_details['IPOS_APMS_HIST'][0]['database_port']
        database_db = connection_details['IPOS_APMS_HIST'][0]['database_db']

        jclassname = "oracle.jdbc.driver.OracleDriver"
        url = ("jdbc:oracle:thin:"+database_user+"/"+database_password+"@"+database_host +":"+database_port+"/"+database_db)
        jars = ["/tmp/ojdbc6.jar"]
        libs = None
        logging.info('connection starts')
        try: 
            cnx = jaydebeapi.connect(jclassname, url, jars=jars,libs=libs)
        except Exception as e:
            logging.error(e)
        logging.info('Connection Successful..')

        print('------')
        size=len(json_data['JOBID'])
        logging.info('Table count -%s', size)
        print('-------')

        for i in range(len(json_data['JOBID'])):
            print('=========================================================================')
            logging.info('Load Job Parameters for Job ID -%s ', i)

            Table = json_data['JOBID'][i]['TableName']
            ColumnsL = json_data['JOBID'][i]['ColumnsList']
            SchemaData= json_data['JOBID'][i]['Schema']
            IncrCol = json_data['JOBID'][i]['Inc_Col']
            NDays = json_data['JOBID'][i]['NDays'] #90
            BQTable = json_data['JOBID'][i]['BQ_Table']
            LoadStrategy = json_data['JOBID'][i]['loadstrategy']
            histyear = json_data['JOBID'][i]['HistYear']

            print('Connecting to Source System....')
               
            logging.info('Quering table....')
            print(LoadStrategy)
            if str(LoadStrategy) == "Y" or str(LoadStrategy) == "y":
               logging.info('Doing historying load')
               #query_pattern = "select * from "+str(Table)+" where TO_CHAR("+str(IncrCol)+",'YYYY') = '2002' "
               query_pattern = "select * from "+str(Table)+" where TO_CHAR("+str(IncrCol)+",'YYYY') = '"+str(histyear)+"' "
            elif str(LoadStrategy) == "FullLoad":
               logging.info('Full Load..')
               query_pattern = "select * from "+str(Table)

            else:
               logging.info('Incremental load..')
               #select * from tos_usr.DELAY_CM where ADT_UPD_DTTM >= trunc(ADT_UPD_DTTM)-10
               query_pattern = "select * from "+str(Table)+" where "+str(IncrCol)+" >= trunc(SYSDATE) - "+str(NDays)

            logging.info(query_pattern)

            bigquery_schema=SchemaData

            BIGQUERY_TABLE = 'apsez-svc-dev-datalake.'+str(BQTable)

            logging.info('BQ Target table -%s',BIGQUERY_TABLE)

            try:
                 print('Quering on a Table:')
                 if str(LoadStrategy) == 'Y' or str(LoadStrategy) == 'y':
                     #sql1="delete from "+str(BQTable)+" where extract(year from CAST("+str(IncrCol)+" AS TIMESTAMP)) = 2023 "
                     sql1="delete from "+str(BQTable)+" where extract(year from CAST("+str(IncrCol)+" AS TIMESTAMP)) = "+str(histyear)
                 elif str(LoadStrategy) =='FullLoad':
                     sql1="truncate table "+str(BQTable)

                 else:
                     sql1="delete from "+str(BQTable)+" where date(CAST("+str(IncrCol)+" AS TIMESTAMP)) >= DATE_SUB(current_date,interval "+str(NDays)+" DAY)"
                 logging.info(sql1)
                 pd.read_gbq(sql1, project_id='apsez-svc-dev-datalake')
                 logging.info('table is deleted!!')
            except:
                logging.info('Table is not created yet!!.Creating table....')
                pass

            project_id='apsez-svc-dev-datalake'
            project=str(BQTable)
            df=pd.read_sql(query_pattern,cnx)
            chunk_size=500000
            batch_no=0
            logging.info('Loading to  DataFrame....')
            try:
              for chunk in pd.read_sql(query_pattern,cnx,chunksize=chunk_size):
                logging.info('Taking data into DataFrame....')
                df = pd.DataFrame(chunk,columns=ColumnsL,index=None)
                logging.info('Loading data in bq: %s',df)
                try:
                    logging.info('loading to bq starts..')
                    pdq.to_gbq(df,project,project_id,if_exists='append',table_schema=SchemaData,api_method="load_csv")
                except Exception as e:
                    logging.error(e)
                batch_no+=1
                logging.info('Data Loaded : %s for batch no :%s ',BQTable,batch_no)
                logging.info('Job Run Complete:%s',BIGQUERY_TABLE)
                    #logging.info('Returning df..')
                    #df2 = pd.DataFrame(df,index=None)
                    #df3 =df2.to_dict('records')
                    #logging.info('DataFrame: %s',df3)
                    # return df3
            except Exception as e:
                logging.error(e)



def run():
    try:
        parser = argparse.ArgumentParser()
        known_args, pipeline_args = parser.parse_known_args()
        pipeline_options = PipelineOptions(pipeline_args)
        pcoll = beam.Pipeline(options=pipeline_options)
        dummy= pcoll | 'Initializing..' >> beam.Create(['1'])
        dummy_env = (dummy | 'Setting up Instance..' >> beam.ParDo(setenv()) | 'Processing & Loading To BigQuery' >>  beam.ParDo(readfromoracle()))
        #| 'WriteToGCS' >>  beam.io.WriteToText("gs://apsez_dataflow_test/sqlserver_files/delay_cm_test.txt"))
        p=pcoll.run()
        p.wait_until_finish()
    except:
        logging.exception('Failed to launch datapipeline')
        raise

if __name__ == "__main__":
     run()

