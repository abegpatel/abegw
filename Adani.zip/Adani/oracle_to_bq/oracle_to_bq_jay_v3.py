import apache_beam as beam
import time
import jaydebeapi
import os
import argparse
from google.cloud import bigquery
import logging
import sys
from google.cloud import storage as gstorage
import pandas as  pd
from oauth2client.client import GoogleCredentials
from datetime import datetime
import pandas as pd
from apache_beam.options.pipeline_options import PipelineOptions, StandardOptions
from threading import Thread,Lock
import time

class setenv(beam.DoFn):
    def process(self,context):
        import jaydebeapi
        import pandas as pd
        src1='gs://apsez_dataflow_test/dataflow_test_code/dataengineering-master/JAVA_JDK_AND_JAR'
        os.system('gsutil cp '+src1+'/ojdbc7.jar /tmp/' +'&&'+ 'gsutil cp -r '+src1+'/jdk-8u202-linux-x64.tar.gz /tmp/')
        logging.info('Jar copied to Instance..')
        logging.info('Java Libraries copied to Instance..')
        #print('jar copied')
        os.system('mkdir -p /usr/lib/jvm  && tar zxvf /tmp/jdk-8u202-linux-x64.tar.gz -C /usr/lib/jvm  && update-alternatives --install "/usr/bin/java" "java" "/usr/lib/jvm/jdk1.8.0_202/bin/java" 1 && update-alternatives --config java')
        logging.info('copying job config file..')
        src2='gs://apsez_dataflow_test/dataflow_test_code/dataengineering-master'
        os.system('gsutil cp '+src2+'/JOB_V1.json /tmp/')
        logging.info('copying connection file..')
        src3='gs://apsez_dataflow_test/dataflow_test_code/dataengineering-master'
        os.system('gsutil cp '+src3+'/ora_to_bq_connection_details_v1.json /tmp/')
        logging.info('Enviornment Variable set.')
        #print('variabel set')
        return list("1")

def ReadFromOracle(query_pattern,ColumnsL,SchemaData):
        import jaydebeapi
        import pandas as pd
        import pandas_gbq as pdq
        from threading import Thread, Lock
        import json
        import time
    #__lock = Lock()
    #def __init__(self,query_pattern,ColumnsL,SchemaData):
    #    Thread.__init__(self)
    #    self.query = query_pattern
    #    self.cols = ColumnsL
    #    self.schema = SchemaData
    #    
    #def run(self):   
    
        database_user= 'ANALYTICS_USER1'
        database_password = 'analytics#user1'
        database_host = '10.6.63.212'
        database_port = '1521'
        database_db = 'AMCTDR'
        
        
        jclassname = "oracle.jdbc.driver.OracleDriver"
        url = ("jdbc:oracle:thin:"+database_user+"/"+database_password+"@"+database_host +":"+database_port+"/"+database_db)
        jars = ["/tmp/ojdbc7.jar"]
        libs = None
        logging.info('connection starts')
        print('connection starts')
        cnx = jaydebeapi.connect(jclassname, url, jars=jars,libs=libs)
        logging.info('Connection Successful..')
        print('connection tested')
        
        project_id='apsez-svc-dev-datalake'
        BQTable='Test_Dev.ct2_cmpltdtrainsidemvs_oc_test001'
        chunk_size=50000
        batch_no=0
        logging.info('Loading to  DataFrame....')
        print('firing query')
        
        try:
            for chunk in pd.read_sql(query_pattern,cnx,chunksize=chunk_size):
              logging.info('Taking data into DataFrame....')
              print('data loading to df')
              df = pd.DataFrame(chunk,columns=ColumnsL,index=None)
              logging.info('Loading data in bq: %s',df)
              try:
                 logging.info('loading to bq starts..')
                 print('data loading in bq')
                 df.to_gbq(BQTable,project_id,if_exists='append',table_schema=SchemaData)
              except Exception as e:
                 logging.error(e)
              batch_no+=1
              logging.info('Data Loaded : %s for batch no :%s ',BQTable,batch_no)
              print('data laoded for',BQTable,batch_no)
              #logging.info('Job Run complete for %s - %s',BQTable,batch_no)
        except Exception as e:
              logging.error(e)
              print(e)
        

def load(self):
        #def process(self,context):    
        import json
        import time
        json_data = []
        try:
            logging.info('Reading config file..')
            with open('/tmp/JOB_V1.json') as json_file:
                 json_data = json.load(json_file)
        except Exception as e:
            logging.info(e)
            
        Table = json_data['JOBID'][0]['TableName']
        ColumnsL = json_data['JOBID'][0]['ColumnsList']
        SchemaData= json_data['JOBID'][0]['Schema']
        IncrCol = json_data['JOBID'][0]['Inc_Col']
        NDays = json_data['JOBID'][0]['NDays'] #90
        BQTable = json_data['JOBID'][0]['BQ_Table']
        HistLoad = json_data['JOBID'][0]['histload']
        #histyear = json_data['JOBID'][i]['HistYear']

        logging.info('Connecting to Source System....')
        logging.info('Quering table....')
        print('creating sql statement')
              
        if str(HistLoad) == "Y" or str(HistLoad) == "y":
               logging.info('Doing historying load')
               queryload1= "select * from TOS_USR.cmpltdtrainsidemvs_oc  where TO_CHAR(ADT_UPD_DTTM,'YYYY') = '2020' "
               queryload2= "select * from TOS_USR.cmpltdtrainsidemvs_oc  where TO_CHAR(ADT_UPD_DTTM,'YYYY') = '2021' "
               queryload3= "select * from TOS_USR.cmpltdtrainsidemvs_oc  where TO_CHAR(ADT_UPD_DTTM,'YYYY') = '2022' "
              
        logging.info('%s , %s , %s ',queryload1,queryload2,queryload3)
        print(queryload1,queryload2,queryload3)
        bigquery_schema=SchemaData
        BIGQUERY_TABLE = 'apsez-svc-dev-datalake.Test_Dev.ct2_cmpltdtrainsidemvs_oc_test001'
        logging.info('BQ Target table -%s',BIGQUERY_TABLE)
        
        logging.info("calling threading")
        print('calling threading')
        worker1 = ReadFromOracle(queryload1,ColumnsL,bigquery_schema)
        worker2 = ReadFromOracle(queryload2,ColumnsL,bigquery_schema)
        worker3 = ReadFromOracle(queryload3,ColumnsL,bigquery_schema)
        logging.info('call for 2020')
        print('call for 2020')
        for i in [worker1,worker2,worker3]:
          i.start()  
          logging.info('call for 2021')
          print('call for 2021')
          time.sleep(20)
        #worker2.start()  
        #print('call for 2022')
        #logging.info('call for 2022')
        #worker3.start()     
        
def run():
    try:
        parser = argparse.ArgumentParser()
        known_args, pipeline_args = parser.parse_known_args()
        pipeline_options = PipelineOptions(pipeline_args)
        pcoll = beam.Pipeline(options=pipeline_options)
        dummy= pcoll | 'Initializing..' >> beam.Create(['1'])
        dummy_env = (dummy | 'Setting up Instance..' >> beam.ParDo(setenv()) | 'Processing & Loading To BigQuery' >>  beam.ParDo(load))
        p=pcoll.run()
        p.wait_until_finish()
    except:
        logging.exception('Failed to launch datapipeline')
        raise

if __name__ == "__main__":
     run()
