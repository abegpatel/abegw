import setuptools

setuptools.setup(
    name='set_libs',
    version='0.1.1',
    packages=setuptools.find_packages(),
    install_requires=['pandas','pandas_gbq','jaydebeapi','threaded','SQLAlchemy','flask_sqlalchemy','pymssql','google-cloud-bigquery']
