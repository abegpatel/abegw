import apache_beam as beam
import time
import jaydebeapi 
import os
import argparse
from google.cloud import bigquery
import logging
import sys
from google.cloud import storage as gstorage
import pandas as  pd
from oauth2client.client import GoogleCredentials
from datetime import datetime
import pandas as pd
from apache_beam.options.pipeline_options import PipelineOptions, StandardOptions


class setenv(beam.DoFn): 
      def process(self,context):
          import jaydebeapi
          import pandas as pd
          src1='gs://apsez_dataflow_test/dataflow_test_code/dataengineering-master/JAVA_JDK_AND_JAR'
          os.system('gsutil cp '+src1+'/ojdbc7.jar /tmp/' +'&&'+ 'gsutil cp -r '+src1+'/jdk-8u202-linux-x64.tar.gz /tmp/')
          logging.info('Jar copied to Instance..')
          logging.info('Java Libraries copied to Instance..')
          os.system('mkdir -p /usr/lib/jvm  && tar zxvf /tmp/jdk-8u202-linux-x64.tar.gz -C /usr/lib/jvm  && update-alternatives --install "/usr/bin/java" "java" "/usr/lib/jvm/jdk1.8.0_202/bin/java" 1 && update-alternatives --config java')
          logging.info('Enviornment Variable set.')
          return list("1")
          

class readfromoracle(beam.DoFn): 
      def process(self, context):
          import jaydebeapi
          import pandas as pd
          query='select * from tos_usr.bthdtls_o FETCH FIRST 10 ROWS ONLY'
          database_user='ANALYTICS_USER1'
          database_password='analytics#user1'
          database_host='10.6.63.212'
          database_port='1521'
          database_db='AMCTDR'
          
          jclassname = "oracle.jdbc.driver.OracleDriver"
          url = ("jdbc:oracle:thin:"+database_user+"/"+database_password+"@"+database_host +":"+database_port+"/"+database_db)
          jars = ["/tmp/ojdbc7.jar"]
          libs = None
          logging.info('connection starts')
          cnx = jaydebeapi.connect(jclassname, url, jars=jars,libs=libs)   
          logging.info('Connection Successful..') 
          cursor = cnx.cursor()
          logging.info('Query submitted to Oracle Database..')
          sql_query = pd.read_sql(query, cnx)
          logging.info('query output :%s',sql_query)
          sql_query.to_gbq('Test_Dev.bthdtls_o_testdf', 'apsez-svc-dev-datalake',if_exists='append')
          logging.info('printing data')
          df = pd.DataFrame(sql_query,index=None)
          df2 = df.to_dict('records')
          logging.info(df2)
          return df2 
   

def run():
    try:
        parser = argparse.ArgumentParser()
        known_args, pipeline_args = parser.parse_known_args()
        pipeline_options = PipelineOptions(pipeline_args)
        pcoll = beam.Pipeline(options=pipeline_options)
        dummy= pcoll | 'Initializing..' >> beam.Create(['1'])
        dummy_env = (dummy | 'Setting up Instance..' >> beam.ParDo(setenv()) | 'Processing & Loading To BigQuery' >>  beam.ParDo(readfromoracle()) | 'WriteToGCS' >>  beam.io.WriteToText("gs://apsez_dataflow_test/sqlserver_files/bthdtls_o_test_2.txt"))
        p=pcoll.run()
        p.wait_until_finish()
    except:
        logging.exception('Failed to launch datapipeline')
        raise    

if __name__ == "__main__":
     run()
