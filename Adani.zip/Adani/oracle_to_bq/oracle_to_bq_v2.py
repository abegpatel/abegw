import apache_beam as beam
import time
import jaydebeapi
import os
import argparse
from google.cloud import bigquery
import logging
import sys
from google.cloud import storage as gstorage
import pandas as  pd
from oauth2client.client import GoogleCredentials
from datetime import datetime
import pandas as pd
from apache_beam.options.pipeline_options import PipelineOptions, StandardOptions


class setenv(beam.DoFn):
    def process(self,context):
        import jaydebeapi
        import pandas as pd
        src1='gs://apsez_dataflow_test/dataflow_test_code/dataengineering-master/JAVA_JDK_AND_JAR'
        os.system('gsutil cp '+src1+'/ojdbc7.jar /tmp/' +'&&'+ 'gsutil cp -r '+src1+'/jdk-8u202-linux-x64.tar.gz /tmp/')
        logging.info('Jar copied to Instance..')
        logging.info('Java Libraries copied to Instance..')
        os.system('mkdir -p /usr/lib/jvm  && tar zxvf /tmp/jdk-8u202-linux-x64.tar.gz -C /usr/lib/jvm  && update-alternatives --install "/usr/bin/java" "java" "/usr/lib/jvm/jdk1.8.0_202/bin/java" 1 && update-alternatives --config java')
        src2='gs://apsez_dataflow_test/dataflow_test_code/dataengineering-master'
        os.system('gsutil cp '+src2+'/job_df_3.json /tmp/')
        logging.info('Enviornment Variable set.')
        return list("1")


class readfromoracle(beam.DoFn):
    def process(self, context):
        import jaydebeapi
        import pandas as pd
        import pandas_gbq as pdq

        
        database_user='ANALYTICS_USER1'
        database_password='analytics#user1'
        database_host='10.6.63.212'
        database_port='1521'
        database_db='AMCTDR'

        jclassname = "oracle.jdbc.driver.OracleDriver"
        url = ("jdbc:oracle:thin:"+database_user+"/"+database_password+"@"+database_host +":"+database_port+"/"+database_db)
        jars = ["/tmp/ojdbc7.jar"]
        libs = None
        logging.info('connection starts')
        cnx = jaydebeapi.connect(jclassname, url, jars=jars,libs=libs)
        logging.info('Connection Successful..')

        #custom query, schema, column list, target table, incremental column, no. of days of incremental data,  history/incremental load
        
        json_data = []
        try:
            logging.info('Reading config file..')
            with open('/tmp/job_df_3.json') as json_file:
                json_data = json.load(json_file)
        except Exception as e:
            logging.error(e)
        
        print('------')
        size=len(json_data['JOBID'])
        logging.info('Table count -%s', size)
        print('-------')

        for i in range(len(json_data['JOBID'])):
            print('=========================================================================')
            logging.info('Load Job Parameters for Job ID -%s ', i)

            Table = json_data['JOBID'][i]['TableName']
            ColumnsL = json_data['JOBID'][i]['ColumnsList']
            SchemaData= json_data['JOBID'][i]['Schema']
            IncrCol = json_data['JOBID'][i]['Inc_Col']
            NDays = json_data['JOBID'][i]['NDays'] #90
            BQTable = json_data['JOBID'][i]['BQ_Table']
            HistLoad = json_data['JOBID'][i]['histload']
            histyear = json_data['JOBID'][i]['HistYear']

            print('Connecting to Source System....')
               
            logging.info('Quering table....')
            print(HistLoad)
            if str(HistLoad) == "Y" or str(HistLoad) == "y":
               logging.info('Doing historying load')
               query_pattern = "select * from "+str(Table)+" where TO_CHAR("+str(IncrCol)+",'YYYY') = '"+str(histyear)+"' "
            else:
               logging.info('Incremental load..')
               #select * from tos_usr.DELAY_CM where ADT_UPD_DTTM >= trunc(ADT_UPD_DTTM)-10
               query_pattern = "select * from "+str(Table)+" where "+str(IncrCol)+" >= trunc(SYSDATE) - "+str(NDays)

            logging.info(query_pattern)

            bigquery_schema=SchemaData

            BIGQUERY_TABLE = 'apsez-svc-dev-datalake.'+str(BQTable)

            logging.info('BQ Target table -%s',BIGQUERY_TABLE)

            try:
                 print('Quering on a Table:')
                 if str(HistLoad) == 'Y' or str(HistLoad) == 'y':
                     sql1="delete from "+str(BQTable)+" where extract(year from CAST("+str(IncrCol)+" AS TIMESTAMP)) = "+str(histyear)
                 else:
                     sql1="delete from "+str(BQTable)+" where date(CAST("+str(IncrCol)+" AS TIMESTAMP)) >= DATE_SUB(current_date,interval "+str(NDays)+" DAY)"
                 logging.info(sql1)
                 pd.read_gbq(sql1, project_id='apsez-svc-dev-datalake')
                 logging.info('table is deleted!!')
            except:
                logging.info('Table is not created yet!!.Creating table....')
                pass

            project_id='apsez-svc-dev-datalake'
            project=str(BQTable)
            chunk_size=50000
            batch_no=0
            logging.info('Loading to  DataFrame....')
            try:
              for chunk in pd.read_sql(query_pattern,cnx,chunksize=chunk_size):
                logging.info('Taking data into DataFrame....')
                df = pd.DataFrame(chunk,columns=ColumnsL,index=None)
                logging.info('Loading data in bq: %s',df)
                try:
                    logging.info('loading to bq starts..')
                    df.to_gbq(project,project_id,if_exists='append',table_schema=SchemaData)
                except Exception as e:
                    logging.error(e)
                batch_no+=1
                logging.info('Data Loaded : %s for batch no :%s ',BQTable,batch_no)
                logging.info('Job Run Complete:%s',BIGQUERY_TABLE)
                    #logging.info('Returning df..')
                    #df2 = pd.DataFrame(df,index=None)
                    #df3 =df2.to_dict('records')
                    #logging.info('DataFrame: %s',df3)
                    # return df3
            except Exception as e:
                logging.error(e)



def run():
    try:
        parser = argparse.ArgumentParser()
        known_args, pipeline_args = parser.parse_known_args()
        pipeline_options = PipelineOptions(pipeline_args)
        pcoll = beam.Pipeline(options=pipeline_options)
        dummy= pcoll | 'Initializing..' >> beam.Create(['1'])
        dummy_env = (dummy | 'Setting up Instance..' >> beam.ParDo(setenv()) | 'Processing & Loading To BigQuery' >>  beam.ParDo(readfromoracle()))
        #| 'WriteToGCS' >>  beam.io.WriteToText("gs://apsez_dataflow_test/sqlserver_files/delay_cm_test.txt"))
        p=pcoll.run()
        p.wait_until_finish()
    except:
        logging.exception('Failed to launch datapipeline')
        raise

if __name__ == "__main__":
     run()

