import cx_Oracle
 
con = cx_Oracle.connect('ANALYTICS_USER1/analytics#123@10.12.45.109:1521/CT1IPUAT')
print(con.version)
cursor = con.cursor()
                
cursor.execute("select log_mode from V$DATABASE")
data = cursor.fetchall()
print(data)
con.close()

