import cx_Oracle
import time
try:
    con = cx_Oracle.connect('analytics_user1/analytics#123@10.12.45.109:1521/CT1IPUAT')
    cursor = con.cursor()
    for i in range(6500,10000):
      cursor.execute("insert into analytics_user1.test_employee(ID,NAME,IDNO) values("+str(i)+",'ABC_XYZ',1001)")
      con.commit()
      time.sleep(1)
      print('Record inserted successfully for Number -',i)

except cx_Oracle.DatabaseError as e:
        print("There is a problem with Oracle", e)
        
