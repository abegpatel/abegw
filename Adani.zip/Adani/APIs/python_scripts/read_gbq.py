import pandas as pd

query ="""select * from apsez-svc-dev-datalake.Test_Dev.trackyourcont_container_tracking_mv limit 10"""

#Declaring Variables for Pandas GBQ
project_id='apsez-svc-dev-datalake'
result = pd.read_gbq(query, project_id = project_id)
df = str(result.to_dict('records'))
print(df)
print(type(df))
