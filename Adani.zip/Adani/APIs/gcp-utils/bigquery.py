from pandas_gbq import read_gbq
import pandas as pd
from google.cloud import bigquery


prod_project_id = 'apsez-svc-prod-datalake'
dataset_id = 'TestDev'
table_id = 'Activity_Based_Costing_Dahej'
dev_project_id = 'apsez-svc-prod-datalake'
client = bigquery.Client()

# Prod Operations
def client_prod_read_bq(project_id,dataset_id,table_id):
    query = f"select * from {project_id}.{dataset_id}.{table_id} limit 100"
    df = client.query(query).result().to_dataframe()
    print(df.head())

def prod_read_bq(project_id,dataset_id,table_id):
    query = f"select * from {project_id}.{dataset_id}.{table_id} limit 100"
    df = read_gbq(query,project_id = project_id)
    print(df.head())

# Dev Operations
def client_dev_read_bq(project_id,dataset_id,table_id):
    query = f"select * from {project_id}.{dataset_id}.{table_id} limit 100"
    df = client.query(query).result().to_dataframe()
    print(df.head())

def dev_read_bq(project_id,dataset_id,table_id):
    query = f"select * from {project_id}.{dataset_id}.{table_id} limit 100"
    df = read_gbq(query,project_id = project_id)
    print(df.head())

def dev_create_dataset_bq(dataset_id):
    query = f"CREATE OR REPLACE DATASET {dataset_id}"
    client = bigquery.Client(query)

def dev_create_table_bq(dataset_id,table_id,):
    query1 = f"USE {dataset_id}"
    query2 = f"CREATE OR REPLACE TABLE()"










