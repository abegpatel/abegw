#import functions_framework
import json
import pandas as pd
import os
import sys
import io
import traceback
from datetime import datetime, timedelta
from urllib.parse import unquote
import numpy as np
import pandas_gbq as pbq
from google.cloud import storage
from google.cloud import bigquery
from itertools import groupby
from utils import distance_query,teu_cost_query


client = bigquery.Client()



request_json = '{"margin_haulage":20,"margin_terminal":20,"margin_first_mile":20,"margin_last_mile":20,"bss_flag":1,"round_trip_flag":1,"origin":"Mundra","destination":"Patli","wt_20_l_trip1":"More than 10T and less than or equal to 20T", "no_c_20_loaded_trip1":10, "no_c_20_empty_trip1":0,"wt_40_l_trip1":"More than 20T and less than or equal to 40T", "no_c_40_l_trip1":10, "no_c_40_e_trip1":10,"wt_20_l_trip2":"More than 10T and less than or equal to 20T", "no_c_20_loaded_trip2":0, "no_c_20_empty_trip2":0,"wt_40_l_trip2":"More than 20T and less than or equal to 40T", "no_c_40_l_trip2":0, "no_c_40_e_trip2":10}'


def logistics_pricing_quotation(request_json):
    ist_time = datetime.now()+timedelta(minutes=330)
    """request_json = request.get_json(silent=True)
    request_args = request.args
    print(request_json)
    print("request : ",request)"""
    #json_df = pd.DataFrame(json.loads(request_json))
    # json_df = pd.json_normalize(json_data)
    try:
        #json_dct = json_df.to_dict('records')
        json_dct = json.loads(request_json)
        print(json_dct)
    except:
        print("JSON input is empty")
        json_dct = {}

    """try:
        param_string=str(request).split("?")[1].split(" ")[0].replace("'","")
        param_string=unquote(param_string)
        print(param_string)
        param_dict=dict()
        col1=param_string.split("&")[0].split("=")[0]
        value1=param_string.split("&")[0].split("=")[1]
        param_dict[col1] = value1
        if param_dict['master'].lower() == 'true':
            master = True
        else:
            master = False
    except:
        print("master argument not passed.")
        master = False
    """


    """headers = {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "GET,OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type,x-api-key",
        "Access-Control-Max-Age": "3600",
        "Access-Control-Allow-Credentials": True
    }


    if request.method == "OPTIONS":
        # Allows GET requests from any origin with the Content-Type
        # header and caches preflight response for an 3600s
        headers = {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "GET,OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type,x-api-key",
        "Access-Control-Max-Age": "3600",
        "Access-Control-Allow-Credentials": True
        }"""
   
    def get_slab_dist(distance,data_price):
        for index, row in data_price.iterrows():
            if row['from']<=distance<=row['to']:
                return row['slab'], index

    def get_slab_wt_20(weight):
        list_20=['up_to_10t', 'more_than_10_t_to_20_t', 'more_than_20_t_to_26_t', 'more_than_26_t_to_31_t', 'more_than_31_t']
        if weight=='Upto 10T':
            return list_20[0]
        if weight=='More than 10T and less than or equal to 20T':
            return list_20[1]
        if weight=='More than 20T and less than or equal to 26T':
            return list_20[2]
        if weight=='More than 26T and less than or equal to 31T':
            return list_20[3]
        if weight=='More Than 31T':
            return list_20[4]

    def get_slab_wt_40(weight):
        list_20=['up_to_10t', 'more_than_10_t_to_20_t', 'more_than_20_t_to_26_t', 'more_than_26_t_to_31_t', 'more_than_31_t']
        if weight=='Upto 20T':
            return list_20[0]
        if weight=='More than 20T and less than or equal to 40T':
            return list_20[1]
        if weight=='More than 40T and less than or equal to 52T':
            return list_20[2]
        if weight=='More than 52T and less than or equal to 62T':
            return list_20[3]
        if weight=='More Than 62T':
            return list_20[4]
        
    def get_average(df):
        df_average=pd.DataFrame(columns=df.columns)
        for i in list(set(df.Terminal.to_list())):
            a=df[df.Terminal==i].sort_values(['Year', 'Month'], ascending=[True, True]).reset_index(drop=True).tail(3)
            df_average=pd.concat([df_average, a], ignore_index=True)
        return df_average    
    
    def trip_calc(margin_haulage,margin_terminal,margin_first_mile,margin_last_mile,
         bss_flag,
         origin,destination,
         wt_20_l, no_c_20_loaded, no_c_20_empty,
         wt_40_l, no_c_40_l, no_c_40_e,
         df1, df2, terminal_cost):

        distance=df1[(df1.origin==origin )& (df1.destination==destination)].reset_index()['distance'][0]
        dist_slab, index=get_slab_dist(distance,df2)

        weight_slab_20= get_slab_wt_20(wt_20_l)
        weight_slab_40_l= get_slab_wt_40(wt_40_l)

        # weight_slab_40_u= get_slab_wt(weight_40_u/2,df2)
        c_origin=0
        c_destination=0
        if origin in terminal_cost.Terminal.to_list():
            c_origin=terminal_cost[terminal_cost.Terminal==origin].reset_index().average_cost[0]
            c_origin=c_origin*(no_c_20_loaded+no_c_20_empty+no_c_40_l*2+no_c_40_e*2)
        if destination in terminal_cost.Terminal.to_list():
            c_destination=terminal_cost[terminal_cost.Terminal==destination].reset_index().average_cost[0]
            c_destination=c_destination*(no_c_20_loaded+no_c_20_empty+no_c_40_l*2+no_c_40_e*2)

        terminal_cost=round(c_origin+c_destination)
        terminal_cost_gst=round((terminal_cost)*0.05)
        terminal_cost_w_gst=terminal_cost+terminal_cost_gst
        terminal_cost_margin=terminal_cost_w_gst/(1-margin_terminal/100)

        cost_20=(df2[weight_slab_20][index]) * no_c_20_loaded + (df2['discounted_empty_container_single_deck'][index]) * no_c_20_empty

        cost_40_l=(df2[weight_slab_40_l][index]) * no_c_40_l *1.8 + (df2['discounted_empty_flat_wagon'][index]) * no_c_40_e*2


        cost_distance= round(cost_20+cost_40_l)
        cost_distance_bss=round(0.1* cost_distance*bss_flag)
        cost_distance_dsc=round(0.05* (cost_distance + cost_distance_bss))
        cost_distance_gst=round((cost_distance+ cost_distance_bss+cost_distance_dsc)*0.05)
        cost_distance_wo_gst=cost_distance+cost_distance_bss+cost_distance_dsc
        cost_distance_w_gst=cost_distance_wo_gst + cost_distance_gst
        cost_distance_margin=cost_distance_w_gst/(1-margin_haulage/100)

        # bss= round(terminal_cost_bss+ cost_distance_bss)
        # dsc= round(terminal_cost_dsc + cost_distance_dsc)
        # gst= round(terminal_cost_gst + cost_distance_gst)
        # total_cost_wo_gst=round(cost_distance_wo_gst + terminal_cost_wo_gst)
        # total_cost_w_gst= round(cost_distance_w_gst+terminal_cost_w_gst)

        # final_cost_margin=cost_distance_margin+terminal_cost_margin

        return terminal_cost,terminal_cost_gst,terminal_cost_w_gst,terminal_cost_margin,cost_distance,cost_distance_bss,cost_distance_dsc, cost_distance_gst,cost_distance_wo_gst,cost_distance_w_gst,cost_distance_margin

    json_dct = {k.lower().replace(" ","_"): v for k,v in json_dct.items()}

    """storage_client = storage.Client()
    bucket = storage_client.get_bucket('asia-south1-apsez-prod-auto-3c810704-bucket')
    # try:
    blob = bucket.blob('dags/scripts/SQL/route_wise_distance_pricing_calc.txt')
    distance_query = blob.download_as_string(client=None)
    distance_query = distance_query.decode('utf-8')
    distance_query = str(distance_query).replace('\r\n','')
    print("distance_query ",distance_query)

    blob = bucket.blob('dags/scripts/SQL/terminal_wise_teu_cost.txt')
    teu_cost_query = blob.download_as_string(client=None)
    teu_cost_query = teu_cost_query.decode('utf-8')
    teu_cost_query = teu_cost_query.replace('\r\n','')
    # except Exception as e:
    #     print("Error occured while loading terminal_wise_teu_cost.txt or route_wise_distance_pricing_calc", e)
    #     return
    """

    query_maintance='''SELECT terminal_code,terminal_name FROM apsez-svc-prod-datalake.logistics_cleansed.layer2_terminal_master where terminal_code in ('FL','SBT','CP','TNPM','MB','SGWF','TKD','UMB','KOTA','SMP','HAPA','LLH','NHYD','CEBD','SREW','BFTL')'''
    q_maintanace=client.query(query_maintance).result()
    df_maintanace = q_maintanace.to_dataframe()
    df_maintanace.terminal_name=df_maintanace.terminal_name.str.title()
    maintance_locs=df_maintanace.terminal_name.unique()

    q_distance=client.query(distance_query).result()
    df_distance = q_distance.to_dataframe()
    df_distance.dropna(subset=['distance','origin','destination'], inplace=True)
    df_distance.distance=df_distance.distance.astype('float64').round(0)
    df_distance=df_distance.drop_duplicates()
    idx2=df_distance.groupby(['origin', 'destination'])['distance'].idxmax()
    df_distance=df_distance.loc[idx2].reset_index(drop=True)
    df_distance=df_distance.reset_index(drop=True)
    df_distance.origin=df_distance.origin.str.title()
    df_distance.destination=df_distance.destination.str.title()
    df_distance=df_distance[~df_distance.origin.isin(maintance_locs)]
    df_distance=df_distance[~df_distance.destination.isin(maintance_locs)]
    df_route_master = df_distance[['origin','destination']]
    
    """if master:
        route_dict = df_route_master.groupby('origin')['destination'].unique().apply(list).to_dict()
        result = json.dumps(route_dict)
        return (result,200, headers)"""
    
    df=df_distance

    query_price="""SELECT * FROM `apsez-svc-prod-datalake.logistics_master.layer2_haulage_calculator`"""
    q_price=client.query(query_price).result()
    df_haulage = q_price.to_dataframe()

    query_miles="""Select LOCATION,Factory,transaction_type,GROSS_WT,TEUS,COMMODITY,Cost, from apsez-svc-prod-datalake.logistics_semantic.layer4_rt_all_road_operations_p2_mv
    where transaction_type in ( 'First Mile' , 'Last Mile' ) and factory is not null"""
    query_job_miles=client.query(query_miles).result()
    df_miles= query_job_miles.to_dataframe()
    df_miles.GROSS_WT=df_miles.GROSS_WT.astype('float')
    df_miles.TEUS=df_miles.TEUS.astype('float')
    df_miles.Cost=df_miles.Cost.astype('float')
    df_miles.dropna(subset=['Cost'],inplace=True)
    df_miles.LOCATION=df_miles.LOCATION.str.title()
    df_miles.Factory=df_miles.Factory.str.title()
    df_miles['cost_per_teu']=round(df_miles['Cost']/df_miles['TEUS'])
    df_miles=df_miles.groupby(['LOCATION','Factory'],as_index=False).agg({"cost_per_teu":'mean'})
    df_miles.rename(columns={'LOCATION':'origin', 'Factory':'factory'}, inplace=True)
    df_miles.cost_per_teu=round(df_miles.cost_per_teu)
    df_miles



    query_job_ct=client.query(teu_cost_query).result()
    df_terminal_wise_teu_cost = query_job_ct.to_dataframe()
    df_terminal_wise_teu_cost['Terminal'][df_terminal_wise_teu_cost['Terminal'].isin(['KISHAN GARH'])] = df_terminal_wise_teu_cost['Terminal'][df_terminal_wise_teu_cost['Terminal'].isin(['KISHAN GARH'])].apply(lambda x: x.replace(' ', ''))
    df_terminal_wise_teu_cost.Terminal=df_terminal_wise_teu_cost.Terminal.str.title()
    # result_median= df_terminal_wise_teu_cost.groupby(['Terminal'], as_index=False).agg({'per_teu_cost':['median'],})
    result_average=get_average(df_terminal_wise_teu_cost)
    result_average=result_average.groupby(['Terminal'], as_index=False).agg({'per_teu_cost':np.mean,})
    terminal_list=['Kandla','Taloja','Patli','Kila Raipur','Maliya Miyana','Kishangarh','M/S.Hind Terminal Pvt. Ltd.','Mundra','Pncs','Pipavav','Sonipat','Nagpur','Malur','Tumb']
    # df_average=df_average[df_average.Terminal.isin(terminal_list)]
    average_cost=result_average[result_average.Terminal.isin(terminal_list)].per_teu_cost.mean()
    result_average['average_cost']=average_cost
    result_average.columns=['Terminal','per_teu_cost','average_cost']

    # origin_code=df[df.from_terminal_name==json_dct['origin']].reset_index().from_terminal_code[0]
    # destination_code_code=df[df.from_terminal_name==json_dct['destination']].reset_index().from_terminal_code[0]
    terminal_cost_trip1,terminal_cost_gst_trip1,terminal_cost_w_gst_trip1,terminal_cost_margin_trip1,  cost_distance_trip1,cost_distance_bss_trip1,cost_distance_dsc_trip1, cost_distance_gst_trip1,cost_distance_wo_gst_trip1,cost_distance_w_gst_trip1,cost_distance_margin_trip1=trip_calc(json_dct["margin_haulage"],json_dct["margin_terminal"],json_dct["margin_first_mile"],json_dct["margin_last_mile"],json_dct["bss_flag"],json_dct["origin"],json_dct["destination"],json_dct["wt_20_l_trip1"], json_dct["no_c_20_loaded_trip1"], json_dct["no_c_20_empty_trip1"],json_dct['wt_40_l_trip1'], json_dct['no_c_40_l_trip1'], json_dct['no_c_40_e_trip1'],df, df_haulage, result_average)
    terminal_cost_trip2,terminal_cost_gst_trip2,terminal_cost_w_gst_trip2,terminal_cost_margin_trip2,  cost_distance_trip2,cost_distance_bss_trip2,cost_distance_dsc_trip2, cost_distance_gst_trip2,cost_distance_wo_gst_trip2,cost_distance_w_gst_trip2,cost_distance_margin_trip2=0,0,0,0,0,0,0,0,0,0,0
    if json_dct['round_trip_flag']==1:
        terminal_cost_trip2,terminal_cost_gst_trip2,terminal_cost_w_gst_trip2,terminal_cost_margin_trip2,  cost_distance_trip2,cost_distance_bss_trip2,cost_distance_dsc_trip2, cost_distance_gst_trip2,cost_distance_wo_gst_trip2,cost_distance_w_gst_trip2,cost_distance_margin_trip2=trip_calc(json_dct['margin_haulage'],json_dct['margin_terminal'],json_dct['margin_first_mile'],json_dct['margin_last_mile'],json_dct['bss_flag'],json_dct['destination'],json_dct['origin'],json_dct['wt_20_l_trip2'], json_dct['no_c_20_loaded_trip2'], json_dct['no_c_20_empty_trip2'],json_dct['wt_40_l_trip2'], json_dct['no_c_40_l_trip2'], json_dct['no_c_40_e_trip2'],df, df_haulage, result_average)


    haulage_cost=cost_distance_trip1+cost_distance_trip2
    haulage_cost_bss=cost_distance_bss_trip1+cost_distance_bss_trip2
    haulage_cost_dsc=cost_distance_dsc_trip1+cost_distance_dsc_trip2
    haulage_cost_gst=cost_distance_gst_trip1+cost_distance_gst_trip2
    haulage_cost_wo_gst=cost_distance_wo_gst_trip1+cost_distance_wo_gst_trip2
    haulage_cost_w_gst=cost_distance_w_gst_trip1+cost_distance_w_gst_trip2
    haulage_cost_margin=cost_distance_margin_trip1+cost_distance_margin_trip2

    terminal_cost=terminal_cost_trip1+terminal_cost_trip2
    terminal_cost_gst=terminal_cost_gst_trip1+terminal_cost_gst_trip2
    terminal_cost_w_gst=terminal_cost_w_gst_trip1+terminal_cost_w_gst_trip2
    terminal_cost_margin=terminal_cost_margin_trip1+terminal_cost_margin_trip2

    final_cost_margin=haulage_cost_margin+terminal_cost_margin
    final_cost_wo_gst=haulage_cost_wo_gst+terminal_cost
    final_cost_w_gst=haulage_cost_w_gst+terminal_cost_w_gst


    result_dct = {'final_cost_margin' : final_cost_margin,'final_cost_wo_gst' : final_cost_wo_gst,'final_cost_w_gst' : final_cost_w_gst,
                  'haulage_cost' : haulage_cost,'haulage_cost_bss' : haulage_cost_bss ,'haulage_cost_dsc' : haulage_cost_dsc, 
                  'haulage_cost_gst' : haulage_cost_gst,'haulage_cost_wo_gst' : haulage_cost_wo_gst,'haulage_cost_w_gst':haulage_cost_w_gst,
                  'haulage_cost_margin':haulage_cost_margin,'terminal_cost':terminal_cost,'terminal_cost_gst':terminal_cost_gst,
                  'terminal_cost_w_gst':terminal_cost_w_gst,'terminal_cost_margin':terminal_cost_margin}
    print("Result dict : ",result_dct)
    result = json.dumps(result_dct)
    return result

print(logistics_pricing_quotation(request_json))