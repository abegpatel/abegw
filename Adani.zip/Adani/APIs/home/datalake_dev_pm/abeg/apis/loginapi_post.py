import requests

url = "http://15.207.129.235:8181/api/api-login"

payload = {'user_name': 'AdaniCustomerAPI24',
'password': 'LtAOqZiNGvVEuTY'}
files=[

]
headers = {
  'Accept': 'application/json'
}

response = requests.request("POST", url, headers=headers, data=payload, files=files)

print(response.text)
print(response.status_code)
 
if (response.status_code == 200):
    token = response.json().get('token')
    print(token)
else:
    print(respo.status_code,response.text)