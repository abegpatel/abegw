distance_query="""select bp.terminal_name as origin,  ep.terminal_name destination,BILLABLE_DISTANCE, ACTUAL_DISTANCE as distance from `gg_replica.layer1_cfsmag_et_route_master` rm
left join  `gg_replica.layer1_cfsmag_et_terminal_master` bp on cast(bp.TERMINAL_REF_ID  as string)= rm.begin_port
left join `gg_replica.layer1_cfsmag_et_terminal_master` ep on cast(ep.terminal_ref_id as string) = rm.end_port
where route_id in (
select distinct ob_route_code from `gg_replica.layer1_cfsmag_et_train_visit` tv
right join  `gg_replica.layer1_cfsmag_et_rake_master` rm on rm.rake_id = tv.rake_id
where date(actual_departure_date) >= date_sub(current_date, INTERVAL 2 year)
and rm.UNIT_NAME in ('ALL', 'ALSPL'))"""
teu_cost_query="""select location_name Terminal,yr Year,mnth Month, sum(teus) Volume ,sum(amount) Amount, sum(amount)/sum(teus) per_teu_cost from(SELECT d.LOCATION_NAME,
    d.BOOKING_NO,
    d.CONT_NO,
    d.TEUS,
    e.cost_type,
    d.yr,
    d.mnth,
 
    sum(e.terminal_cost) AS amount
   FROM ( SELECT d_1.LOCATION_NAME,
            d_1.BOOKING_NO,
            d_1.CONT_NO,
            d_1.TEUS,
            EXTRACT(YEAR from d_1.ARRIVAL_DATE) AS yr,
            EXTRACT(MONTH from d_1.ARRIVAL_DATE) AS mnth
           FROM ( SELECT LOCATION_NAME,
                    ARRIVAL_DATE,
                    RAKE_NAME,
                    TRAIN_NO,
                    BOOKING_NO,
                    CATEGORY,
                    BOOKING_TYPE,
                    BOOKING_PARTY,
                    LINE,
                    IN_ACC_OF,
                    CONT_NO,
                    CONT_SIZE,
                    CONT_STATUS,
                    TEUS,
                    FROM_LOC,
                    TO_LOC,
                    MODE
                   FROM `apsez-svc-prod-datalake.logistics_semantic.layer4_cfsmag_bt_all_terminal_volume_vw`
                  WHERE upper(LOCATION_NAME) <> 'MUNDRA' AND business_unit = 'ALL'
                UNION DISTINCT
                 SELECT LOCATION_NAME,
                    ARRIVAL_DATE,
                    RAKE_NAME,
                    TRAIN_NO,
                    BOOKING_NO,
                    CATEGORY,
                    BOOKING_TYPE,
                    BOOKING_PARTY,
                    LINE,
                    IN_ACC_OF,
                    CONT_NO,
                    CONT_SIZE,
                    CONT_STATUS,
                    TEUS,
                    FROM_LOC,
                    TO_LOC,
                    MODE
                   FROM `apsez-svc-prod-datalake.logistics_semantic.layer4_cfsmag_bt_all_terminal_volume_vw`
                  WHERE upper(LOCATION_NAME) = 'MUNDRA' AND CATEGORY = 'DOMESTIC' AND business_unit = 'ALL' and CONCAT(UPPER(FROM_LOC),UPPER(TO_LOC)) NOT IN('MUNDRAMALIYA MIYANA','MALIYA MIYANAMUNDRA')
) d_1) d
                  JOIN
  (SELECT b.year,
            b.month,
            a.LOCATION_NAME,
            b.amount,
            a.volume,
            b.cost_type,
            (b.amount / a.volume) AS terminal_cost
           FROM ( SELECT EXTRACT(YEAR from a_1.ARRIVAL_DATE) AS yr,
                    EXTRACT(MONTH from a_1.ARRIVAL_DATE) AS mnth,
                    a_1.LOCATION_NAME,
                    count(a_1.CONT_NO) AS volume
                   FROM ( SELECT LOCATION_NAME,
                            ARRIVAL_DATE,
                            RAKE_NAME,
                            TRAIN_NO,
                            BOOKING_NO,
                            CATEGORY,
                            BOOKING_TYPE,
                            BOOKING_PARTY,
                            LINE,
                            IN_ACC_OF,
                            CONT_NO,
                            CONT_SIZE,
                            CONT_STATUS,
                            TEUS,
                            FROM_LOC,
                            TO_LOC,
                            MODE
                           FROM `apsez-svc-prod-datalake.logistics_semantic.layer4_cfsmag_bt_all_terminal_volume_vw`
                          WHERE upper(LOCATION_NAME) <> 'MUNDRA' AND business_unit = 'ALL'
                        UNION DISTINCT
                         SELECT LOCATION_NAME,
                            ARRIVAL_DATE,
                            RAKE_NAME,
                            TRAIN_NO,
                            BOOKING_NO,
                            CATEGORY,
                            BOOKING_TYPE,
                            BOOKING_PARTY,
                            LINE,
                            IN_ACC_OF,
                            CONT_NO,
                            CONT_SIZE,
                            CONT_STATUS,
                            TEUS,
                            FROM_LOC,
                            TO_LOC,
                            MODE
                           FROM `apsez-svc-prod-datalake.logistics_semantic.layer4_cfsmag_bt_all_terminal_volume_vw`
                          WHERE upper(LOCATION_NAME) = 'MUNDRA' AND business_unit = 'ALL' AND CATEGORY = 'DOMESTIC' and CONCAT(UPPER(FROM_LOC),UPPER(TO_LOC)) NOT IN('MUNDRAMALIYA MIYANA','MALIYA MIYANAMUNDRA')
) a_1
                  WHERE cast(a_1.ARRIVAL_DATE as date) >=
                        date(cast(EXTRACT(YEAR from CURRENT_DATE)as int)-1, 4, 1)
                        AND cast(a_1.ARRIVAL_DATE as date)< CURRENT_DATE
                        AND upper(LOCATION_NAME) not in ('PATLI','KISHAN GARH','KILA RAIPUR','MALUR','NAGPUR','TALOJA','LONI','VALWADA','VIROCHANNAGAR')
                  GROUP BY (EXTRACT(YEAR from a_1.ARRIVAL_DATE)), (EXTRACT(MONTH from a_1.ARRIVAL_DATE)), a_1.LOCATION_NAME) a
             JOIN ( SELECT year,
                    month,
                    terminal,
                    cost_type,
                    amount,
                    remark,
                    businessunit
                   FROM `apsez-svc-prod-datalake.logistics_semantic.layer4_all_terminal_cost_vw`
                  WHERE remark = 'tv'
                  ) b ON a.yr = b.year AND a.mnth = b.month AND upper(a.LOCATION_NAME) = upper(b.terminal)
 
UNION DISTINCT
 
SELECT b.year,
            b.month,
            a.LOCATION_NAME,
            b.amount,
            a.volume,
            b.cost_type,
            (b.amount / a.volume) AS terminal_cost
           FROM ( SELECT EXTRACT(YEAR from a_1.ARRIVAL_DATE) AS yr,
                    EXTRACT(MONTH from a_1.ARRIVAL_DATE) AS mnth,
                    a_1.LOCATION_NAME,
                    count(a_1.CONT_NO) AS volume
                   FROM ( SELECT LOCATION_NAME,
                            ARRIVAL_DATE,
                            RAKE_NAME,
                            TRAIN_NO,
                            BOOKING_NO,
                            CATEGORY,
                            BOOKING_TYPE,
                            BOOKING_PARTY,
                            LINE,
                            IN_ACC_OF,
                            CONT_NO,
                            CONT_SIZE,
                            CONT_STATUS,
                            TEUS,
                            FROM_LOC,
                            TO_LOC,
                            MODE
                           FROM `apsez-svc-prod-datalake.logistics_semantic.layer4_cfsmag_bt_all_terminal_volume_vw`
                          WHERE upper(LOCATION_NAME) <> 'MUNDRA' AND business_unit = 'ALL'
                        UNION DISTINCT
                         SELECT LOCATION_NAME,
                            ARRIVAL_DATE,
                            RAKE_NAME,
                            TRAIN_NO,
                            BOOKING_NO,
                            CATEGORY,
                            BOOKING_TYPE,
                            BOOKING_PARTY,
                            LINE,
                            IN_ACC_OF,
                            CONT_NO,
                            CONT_SIZE,
                            CONT_STATUS,
                            TEUS,
                            FROM_LOC,
                            TO_LOC,
                            MODE
                           FROM `apsez-svc-prod-datalake.logistics_semantic.layer4_cfsmag_bt_all_terminal_volume_vw`
                          WHERE upper(LOCATION_NAME) = 'MUNDRA' AND business_unit = 'ALL' AND CATEGORY = 'DOMESTIC' and CONCAT(UPPER(FROM_LOC),UPPER(TO_LOC)) NOT IN('MUNDRAMALIYA MIYANA','MALIYA MIYANAMUNDRA')
) a_1
                  WHERE cast(a_1.ARRIVAL_DATE as date) >=
                        date(cast(EXTRACT(YEAR from CURRENT_DATE)as int)-1, 4, 1)
                        AND cast(a_1.ARRIVAL_DATE as date)< '2022-04-01'
                        AND upper(LOCATION_NAME) in ('PATLI','KISHAN GARH','KILA RAIPUR','MALUR','NAGPUR','TALOJA','LONI','VALWADA','VIROCHANNAGAR')
                  GROUP BY (EXTRACT(YEAR from a_1.ARRIVAL_DATE)), (EXTRACT(MONTH from a_1.ARRIVAL_DATE)), a_1.LOCATION_NAME) a
             JOIN ( SELECT year,
                    month,
                    terminal,
                    cost_type,
                    amount,
                    remark,
                    businessunit
                   FROM `apsez-svc-prod-datalake.logistics_semantic.layer4_all_terminal_cost_vw`
                  WHERE remark = 'tv'
                  ) b ON a.yr = b.year AND a.mnth = b.month AND upper(a.LOCATION_NAME) = upper(b.terminal)) e ON d.mnth = e.month AND d.yr = e.year AND upper(d.LOCATION_NAME) = upper(e.LOCATION_NAME)
  GROUP BY d.LOCATION_NAME, d.BOOKING_NO, d.CONT_NO, d.TEUS, e.cost_type,d.yr,d.mnth
 UNION ALL
  SELECT d.LOCATION_NAME,
    d.BOOKING_NO,
    d.CONT_NO,
    d.TEUS,
    b.cost_type,
    d.yr,
    d.mnth,
    d.TEUS*sum(b.amount) AS amount from (SELECT d_1.LOCATION_NAME,
            d_1.BOOKING_NO,
            d_1.CONT_NO,
            d_1.TEUS,
            EXTRACT(YEAR from d_1.ARRIVAL_DATE) AS yr,
            EXTRACT(MONTH from d_1.ARRIVAL_DATE) AS mnth
           FROM ( SELECT LOCATION_NAME,
                    ARRIVAL_DATE,
                    RAKE_NAME,
                    TRAIN_NO,
                    BOOKING_NO,
                    CATEGORY,
                    BOOKING_TYPE,
                    BOOKING_PARTY,
                    LINE,
                    IN_ACC_OF,
                    CONT_NO,
                    CONT_SIZE,
                    CONT_STATUS,
                    TEUS,
                    FROM_LOC,
                    TO_LOC,
                    MODE
                   FROM `apsez-svc-prod-datalake.logistics_semantic.layer4_cfsmag_bt_all_terminal_volume_vw`
                  WHERE upper(LOCATION_NAME) <> 'MUNDRA' AND business_unit = 'ALL'
                UNION DISTINCT
                 SELECT LOCATION_NAME,
                    ARRIVAL_DATE,
                    RAKE_NAME,
                    TRAIN_NO,
                    BOOKING_NO,
                    CATEGORY,
                    BOOKING_TYPE,
                    BOOKING_PARTY,
                    LINE,
                    IN_ACC_OF,
                    CONT_NO,
                    CONT_SIZE,
                    CONT_STATUS,
                    TEUS,
                    FROM_LOC,
                    TO_LOC,
                    MODE
                   FROM `apsez-svc-prod-datalake.logistics_semantic.layer4_cfsmag_bt_all_terminal_volume_vw`
                  WHERE upper(LOCATION_NAME) = 'MUNDRA' AND CATEGORY = 'DOMESTIC' AND business_unit = 'ALL') d_1
                            Where cast(d_1.ARRIVAL_DATE as date) >= '2022-04-01')d
 
                  JOIN
                  (
                    SELECT year,
                    month,
                    terminal,
                    cost_type,
                    amount,
                    remark,
                    businessunit
                   FROM `apsez-svc-prod-datalake.logistics_semantic.layer4_all_terminal_cost_vw`
                  WHERE remark = 'tv'
                  AND upper(terminal) in ('PATLI','KISHAN GARH','KILA RAIPUR','MALUR','NAGPUR','TALOJA','LONI','VALWADA','VIROCHANNAGAR')
                  ) b
                  ON
                  d.yr = b.year AND d.mnth = b.month AND upper(d.LOCATION_NAME) = upper(b.terminal)
                  Group by d.LOCATION_NAME,
    d.BOOKING_NO,
    d.CONT_NO,
    d.TEUS,
    b.cost_type,d.yr,d.mnth) group by 1,2,3"""