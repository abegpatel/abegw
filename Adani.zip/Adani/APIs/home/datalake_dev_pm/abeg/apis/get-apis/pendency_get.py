from google.cloud import bigquery
from pandas_gbq import read_gbq
import json
import requests

 
project_id = 'apsez-svc-prod-datalake'
extraction_query = """SELECT Movement_Type,
status,
cont_no,
cont_size,
booking_no,
booking_ref_code,
customer,
booking_location,
current_location,
to_terminal,
to_terminal_code,
CASE WHEN UPPER(booking_location_code) = 'KISHANGARH' THEN 'ALIK' ELSE booking_location_code END AS booking_location_code,
route,
aging_in_hrs,
container_status_start_date,
book_date,
train_no,
rake_name,
transport_by,
monthyear,
bu,
mov_type,
load_date,
location,
movement_types,
Driven_BU,
all_empty_flag,
  CASE
    WHEN cont_size = 20 AND movement_types = 'EMPTY' AND status = 'AWAITING RAILMENT' AND all_empty_flag = 0 AND bu = 'ALL' THEN 'ALL EMPTY'
    WHEN cont_size = 40 AND movement_types = 'EMPTY' AND status = 'AWAITING RAILMENT' AND all_empty_flag = 0 AND bu = 'ALL' THEN 'ALL EMPTY'
    WHEN cont_size = 20 AND movement_types = 'EMPTY' AND status = 'AWAITING RAILMENT' THEN 'EMPTY'
    WHEN cont_size = 40 AND movement_types = 'EMPTY' AND status = 'AWAITING RAILMENT' THEN 'EMPTY'
    WHEN cont_size = 20 AND movement_types = 'EMPTY' AND status = 'INTRANSIT HUB PENDENCY' THEN 'EMPTY (HUB)'
    WHEN cont_size = 40 AND movement_types = 'EMPTY' AND status = 'INTRANSIT HUB PENDENCY' THEN 'EMPTY (HUB)'
    WHEN cont_size = 20 AND movement_types = 'LOADED' AND status = 'AWAITING RAILMENT' THEN 'LOADED'
    WHEN cont_size = 40 AND movement_types = 'LOADED' AND status = 'AWAITING RAILMENT' THEN 'LOADED'
    WHEN cont_size = 20 AND movement_types = 'LOADED' AND status = 'INTRANSIT HUB PENDENCY' THEN 'LOADED (HUB)'
    WHEN cont_size = 40 AND movement_types = 'LOADED' AND status = 'INTRANSIT HUB PENDENCY' THEN 'LOADED (HUB)'
    WHEN cont_size = 20 AND movement_types = 'HOLD' AND status = 'AWAITING RAILMENT' THEN 'ON HOLD'
    WHEN cont_size = 40 AND movement_types = 'LOADED' AND status = 'AWAITING RAILMENT' THEN 'ON HOLD'
    ELSE 'OTHERS'
  END AS pendency_type
FROM (
  SELECT
    Movement_Type,
    status,
    cont_no,
    cont_size,
    booking_no,
    booking_ref_code,
    customer,
    booking_location,
    current_location,
    to_terminal,
    COALESCE(fois, to_terminal_code) AS to_terminal_code,
    --bk.bk_fois AS booking_location_code,
    COALESCE(bk.bk_fois, booking_location_code) AS booking_location_code,
    route,
    aging_in_hrs,
    container_status_start_date,
    book_date,
    train_no,
    rake_name,
    transport_by,
    monthyear,
    bu,
    mov_type,
    load_date,
    location,
    movement_types,
    Driven_BU,
    0 AS all_empty_flag
  FROM (
    SELECT
      Movement_Type,
      UPPER(status) AS status,
      cont_no,
      cont_size,
      booking_no,
      booking_ref_code,
      customer,
      booking_location,
      current_location,
      to_terminal,
      to_terminal_code,
      booking_location_code,
      route,
      aging_in_hrs,
      container_status_start_date,
      book_date,
      train_no,
      rake_name,
      transport_by,
      monthyear,
      bu,
      mov_type,
      load_date,
      location,
      CASE
        WHEN Movement_Type = 'Empty' THEN 'EMPTY'
        WHEN Movement_Type = 'Hold' THEN 'HOLD'
        ELSE 'LOADED'
      END AS movement_types,
      CASE
        WHEN UPPER(booking_location_code) IN (
          SELECT terminal_code
          FROM apsez-svc-prod-datalake.logistics_cleansed.layer2_gpwis_terminal_mst
        ) OR UPPER(to_terminal_code) IN (
          SELECT terminal_code
          FROM apsez-svc-prod-datalake.logistics_cleansed.layer2_gpwis_terminal_mst
        ) THEN 'GPWIS'
        ELSE 'ALL+ALSPL'
      END AS Driven_BU,
      0 AS all_empty_flag
    FROM apsez-svc-prod-datalake.logistics_semantic.layer4_rt_rail_pendency_mv a
    WHERE load_date = (
      SELECT MAX(load_date)
      FROM apsez-svc-prod-datalake.logistics_semantic.layer4_rt_rail_pendency_mv
    )
    AND booking_location <> to_terminal
    AND book_date >= '2021-04-01'
    AND customer LIKE '%ADANI LOGISTICS LTD.%'
    AND Movement_Type = 'Empty'
    UNION DISTINCT
    SELECT
      Movement_Type,
      UPPER(status) AS status,
      cont_no,
      cont_size,
      booking_no,
      booking_ref_code,
      customer,
      booking_location,
      current_location,
      to_terminal,
      to_terminal_code,
      CASE WHEN status = 'Intransit Hub Pendency' THEN current_location ELSE booking_location_code END,
      route,
      aging_in_hrs,
      container_status_start_date,
      book_date,
      train_no,
      rake_name,
      transport_by,
      monthyear,
      bu,
      mov_type,
      load_date,
      location,
      CASE
        WHEN Movement_Type = 'Empty' THEN 'EMPTY'
        WHEN Movement_Type = 'Hold' THEN 'HOLD'
        ELSE 'LOADED'
      END AS movement_types,
      CASE
        WHEN UPPER(booking_location_code) IN (
          SELECT terminal_code
          FROM apsez-svc-prod-datalake.logistics_cleansed.layer2_gpwis_terminal_mst
        ) OR UPPER(to_terminal_code) IN (
          SELECT terminal_code
          FROM apsez-svc-prod-datalake.logistics_cleansed.layer2_gpwis_terminal_mst
        ) THEN 'GPWIS'
        ELSE 'ALL+ALSPL'
      END AS Driven_BU,
      1 AS all_empty_flag
    FROM apsez-svc-prod-datalake.logistics_semantic.layer4_rt_rail_pendency_mv b
    WHERE load_date = (
      SELECT MAX(load_date)
      FROM apsez-svc-prod-datalake.logistics_semantic.layer4_rt_rail_pendency_mv
    )
    AND booking_location <> to_terminal
    AND book_date >= '2021-04-01'
    AND customer NOT LIKE '%ADANI LOGISTICS'
  ) x
  LEFT JOIN (
    SELECT *
    FROM (
      SELECT
        terminal_code,
        fois,
        ROW_NUMBER() OVER (PARTITION BY terminal_code) AS rnk
      FROM apsez-svc-prod-datalake.logistics_cleansed.layer2_terminal_master
    ) x
    WHERE rnk = 1
  ) tm ON x.to_terminal_code = tm.terminal_code
  LEFT JOIN (
    SELECT *
    FROM (
      SELECT
        terminal_code as bk_tcode,
        fois as bk_fois,
        terminal_name,
        ROW_NUMBER() OVER (PARTITION BY terminal_code) AS rnk
      FROM apsez-svc-prod-datalake.logistics_cleansed.layer2_terminal_master
    ) x
    WHERE rnk = 1
  ) bk ON 
  --CASE WHEN x.booking_location_code <> bk.bk_tcode THEN (UPPER(x.booking_location_code) = UPPER(bk.terminal_name)) ELSE 
  x.booking_location_code = bk.bk_tcode 
  --END 
)
"""

# Read from Bigquery
pendency_df = read_gbq(extraction_query,project_id = project_id)

result = pendency_df.to_dict('records')
result = json.dumps(result)
print(result)

# auth_token = ''
headers_post = {
      'Content-Type': 'application/json',
      'authToken': auth_token
}
 
response = requests.get('https://apsez.adani.com/api/pendency',headers=headers_post,data=result)
 
if response.status_code == 200:
    print(response.text)
    print("Data posted successfully")
else:
    print(response.text)
    print(response.status_code)
