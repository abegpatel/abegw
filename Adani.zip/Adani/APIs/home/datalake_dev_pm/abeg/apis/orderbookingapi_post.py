from google.cloud import bigquery
import pandas as pd
from pandas_gbq import read_gbq
import json
import requests
from datetime import date,datetime,time
import numpy as np


project_id = 'apsez-svc-prod-datalake'
extraction_query = """SELECT
  DISTINCT CAST(date AS string) date,
  customer_name,
  customer_code,
  order_no,
  delivery_mode,
  container_number,
  CAST(container_size AS INT64) container_size,
  from_terminal,
  to_terminal,
  eway_bill_file,
  line,
  consignee,
  consignee_address,
  consignor,
  consignor_address,
  importer,
  contact_no,
  empty_drop_loc,
  transport_by,
  SUBSTRING(CAST(trailer_required_date AS string),1,LENGTH(CAST(trailer_required_date AS string))-3) trailer_required_date,
  factory_address,
  factory,
  bill_to,
  CAST(bu_id AS INT64) bu_id,
  boe_no,
  CAST(ccrp_no AS integer) AS ccrp_no,
  SUBSTRING(CAST(ccrp_date AS string),1,LENGTH(CAST(ccrp_date AS string))-3) ccrp_date,
  factory_ref_code
FROM
  apsez-svc-prod-datalake.logistics_semantic.layer4_customer_portal_bt_order_booking_details_mv
WHERE
  DATE(date) >='2024-01-01'AND DATE(date) <='2024-02-01' LIMIT 1;"""

# Read from Bigquery
df = read_gbq(extraction_query,project_id = project_id)



# pre-processing of data

#df[['eway_bill_file','consignee','consignee_address','consignor','consignor_address','importer','contact_no','empty_drop_loc','transport_by','factory_address','factory','bill_to','factory_ref_code']]=df[['eway_bill_file','consignee','consignee_address','consignor','consignor_address','importer','contact_no','empty_drop_loc','transport_by','factory_address','factory','bill_to','factory_ref_code']]


df[['customer_code','boe_no','ccrp_no','bu_id']]=df[['customer_code','boe_no','ccrp_no','bu_id']].fillna(0)



date_cols=['trailer_required_date','ccrp_date']
for col in date_cols:
    df[col] = pd.to_datetime(df[col])
    df[col] = df[col].dt.strftime('%d-%m-%Y %H:%M:%S')
    df[col] = df[col].apply(lambda x: '01-01-1900 00:00:00' if str(x) == 'nan' else x)

df = df.applymap(lambda x:None if pd.isna(x) else x)

result = df.to_dict('records')
result = json.dumps(result)
print(result)

json_file_path = 'orderbooking_res.json'
with open(json_file_path,'w') as file:
  json.dump(result,file)

url = "http://15.207.129.235:8181/api/orderbooking-api-json"

payload = {}
files=[
  ('file',('orderbooking_res.json',open('/home/datalake_dev_pm/abeg/apis/orderbooking_res.json','rb'),'application/json'))
]
headers = {
  'Accept': 'application/json',
  'Authorization': 'Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJhdWQiOiI3IiwianRpIjoiYjYxNWZiZWYxMmE1ZTg0YzUyMzg3ZDA4MGUyOTg3MTc0NDNmNzQwNjUxZGRkMGQyM2YxNzhjMGU3OWE0YTFhNTk3MmQ4MThkZjRkNTNjZWIiLCJpYXQiOjE3MTg4ODI3ODYuODAwMDEyLCJuYmYiOjE3MTg4ODI3ODYuODAwMDE4LCJleHAiOjE3NTA0MTg3ODYuNzcwMDMyLCJzdWIiOiIxIiwic2NvcGVzIjpbXX0.osdWV6s1F0hbYuZPtqtH1tgJwB8DFUKg4cZGyfGARz2no8A6vsPGOlrASy1ZIE3VzTuWWh7OcUKrLht1jkbXgjFI2hBxI4bvjdRU6KIXStSBMlU9Opm0acvvlYe5EB_osbvFuYYuiZYl5bFLedUzcucnVduRlmaZByHGrvfYG3z3MaVk_w8U-76M23oojB31plWWl0IsII-7XaywvkEU5IsR1N3FNIHxZzOTuLSOMVJsU7pmGh2VJ-TPyZ_3afcs96wMCGJ4fREJc8mputGDH98ohr3wR5vI3dAPLnFFNYRt1hrh_8HoGCj7hp3bTkFwFz2krTz3vcB6p3-XhS7KAiGn5r2YLEdEyls1cTo73Vztad5O_xH_cWk-gaOKmX6DfaTZ9i4FktOsGU2moCc03g83-Ci6frde4Kab-mXafZ4jgE2QgzFjgB9P-NPTEga3TPHZRk75lwa6HU9sK1fwwauPOcGnf9uedoh_SHftyoGpdKBlLaxkU9o7IQIhZ6D_t-JmTidq8f9bMZrfpv31MxK3Fi1QOFtEaKt0_NCtUDRqhNojD2bnA14PNmFiCh0lt123LYvp3IJ1R_bGaGqfMYeJhxAHb0lwakIS8IufJf5BfsBElLibP7SbVjKoQOwgp9HxeoAChyCDs4xLAUOrBSAvdKxTn69qlOvNbNiThcM'
}

response = requests.request("POST", url, headers=headers, data=payload, files=files)

print(response.text)

 
