import requests
from requests.auth import HTTPBasicAuth


url = 'http://15.207.129.235:8181/api/api-login'
user_name = 'AdaniCustomerAPI2024'
password = 'YAGOgipfFsvzbs0'
headers_post = {
      'Content-Type': 'application/json'
}
response = requests.post(url,auth=HTTPBasicAuth(user_name,password),headers=headers_post)

print(response.text)
print(response.status_code)
 
if (response.status_code == 200):
    token = response.json().get('token')
    print(token)
else:
    print(respo.status_code,response.text)