import psycopg2
import psycopg2.extras
import time
import json
import boto3
from datetime import datetime, timedelta

def lambda_handler(event, context):
    # cntr_nos = tuple(event['request_from_portal']['cntr_nos'].split(','))
    # print(cntr_nos)
    # cntr_nos = cntr_nos[:25]
    # print(cntr_nos)
    
    # From = tuple(event['request_from_portal']['From'])
    # print("from ")
    # print(From)
    print(event['params']['querystring'])
    
    From = str(event['params']['querystring']['From'])
    print('From' , From)
    To = str(event['params']['querystring']['To'])
    print('To' , To)
    
    
    # Define database connection parameters
    hostname = 'apsez-as1-analytics-prod-rds.cpjhdhjkpglj.ap-south-1.rds.amazonaws.com'
    username = 'pgadmin'
    password = 'Adani$#390'
    database = 'analytics'
    

    query ="""select distinct date::text, customer_name,customer_code, order_no, 
delivery_mode, container_number,container_size,from_terminal,
to_terminal, eway_bill_file, line, consignee, consignee_address, 
consignor, consignor_address, importer, contact_no, 
empty_drop_loc, transport_by, 
trailer_required_date::text, 
factory_address, factory, bill_to ,bu_id,boe_no,ccrp_no,ccrp_date::text,factory_ref_code,cha,cha_ref_code,exporter_name,exporter_ref_code,agent_name,agent_ref_code,book_by_party
from logistics_prod.riddhi_order_booking_details 
where date::timestamp >='{0}'
    and date::timestamp <='{1}';""".format(From,To)
    
    print(query)
    conn = psycopg2.connect(dbname=database, host=hostname, port=5432, user=username, password=password, sslmode='require')
    cur_pg = conn.cursor(cursor_factory = psycopg2.extras.RealDictCursor)
    # print(query%cntr_nos)
    try:
        cur_pg.execute(query)
        result = cur_pg.fetchall()
        print(result)
        print('*' * 100)
        # Convert Python to JSON  
        json_object = json.dumps(result, indent = 4).encode('utf-8')
        
        print(datetime.now())
        now_timestamp = datetime.now()
        print("*" * 10)
        print( now_timestamp + timedelta(minutes=330))
        
        ind_time = (now_timestamp + timedelta(minutes=330)).strftime("%Y-%m-%d %H:%M:%S")
        aws_file = "logistics/"+datetime.today().strftime("%Y/%b/%Y-%m-%d/")+'order_booking_details/order_booking_details_'+str(ind_time)+'.json'
        aws_file = aws_file.replace(" ","_")
        print("aws_file : ",aws_file)
        bucket_name = 'apsez-apigee-apicall-audit'
        
        # Method 2: Client.put_object()
        client = boto3.client('s3')
        client.put_object(Body=json_object, Bucket=bucket_name, Key=aws_file)
        
    
        print("json uploaded to AWS as ",aws_file)
        print("Query Executed Successfully")
        
        # Print JSON object
        print(json_object) 
        #print(dict(cur_pg.fetchall()))
        print(len(result))
        print(type(json_object))
        print("query Executed Successfully")
        return json_object
    except Exception as e:
        print("Error: {0}".format(e))
        raise Exception('"ExecutionError": "Please contact API Developer"')
