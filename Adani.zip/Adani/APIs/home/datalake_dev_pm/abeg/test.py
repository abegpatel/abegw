from google.cloud import bigquery 
import pandas as pd
from pandas_gbq import read_gbq
import numpy as np
import json
import requests
from datetime import date,datetime,time

project_id = 'apsez-svc-prod-datalake'
query = """WITH
   lr_tjo
    as
    (
    select distinct lr_no,CONTAINER_NO ,MODIFIED_ON
    from `apsez-svc-prod-datalake.gg_replica.layer1_cfsmag_et_lr_tjo_details`
    ),
      p2 AS (
      SELECT
      p2.LR_NO,
        p2.LR_DATE,
        p2.VEHICLE_NO,
       p2.CUSTOMER,
        FROM_LOC,
        Factory AS to_location,
        p2.TJO_No,
        p2.GROSS_WT,
        COMMODITY,
        COMMODITY_1,
       p2. Container_No,
        p2.Container_Size,
        tr.truck_reg_number,
       p2.TRANSPORTER,
        fm.FACTORY_REF_CODE AS factory_code,
        p2.TRANSPORT_BY AS Business_Unit,
        EMPTY_PICKUP_LOC_NAME,
        EMPTY_DROP_LOC_NAME,
        p2.location,
        lr_tjo.MODIFIED_ON,
        p2.Transaction_Type,
        p2.BOOKING_NO
      FROM
        `apsez-svc-prod-datalake.logistics_semantic.layer4_rt_all_road_operations_p2_mv` p2
      LEFT JOIN
        apsez-svc-prod-datalake.logistics_cleansed.layer2_cfsmag_all_truck_master tr
      ON
        p2.vehicle_no=tr.truck_reg_number
      left join  lr_tjo
      on p2.LR_NO = cast(lr_tjo.LR_NO as numeric) and p2.Container_No=lr_tjo.container_no
      LEFT JOIN
        `gg_replica.layer1_cfsmag_et_factory_master` fm
      ON
        fm.FACTORY_ID = p2.FACTORY_ID
      WHERE
        p2.TRANSPORT_BY IN ('ALL',
          'ALSPL')
      )
    SELECT
      DISTINCT CAST(LR_NO AS INT64) LR_NO,
      substring(cast(LR_DATE as string),1,length(cast(LR_DATE as string))-3) lr_date,
      VEHICLE_NO,
      CUSTOMER,
      FROM_LOC AS FromLocation,
      to_location AS ToLocation,
      TJO_No,
      Container_No,
      CAST(Container_Size AS INT64) Container_Size,
      ROUND(CAST(GROSS_WT AS FLOAT64),2) GROSS_WT,
      COMMODITY,
      TRANSPORTER,
      Factory_Code,
      Business_Unit,
      EMPTY_PICKUP_LOC_NAME,
      EMPTY_DROP_LOC_NAME,
      location,
      substring(cast(MODIFIED_ON as string),1,length(cast(MODIFIED_ON as string))-3) MODIFIED_ON,
      Transaction_Type,
      BOOKING_NO as order_no
    FROM p2 
    where GROSS_WT IS NOT NULL AND date(LR_DATE) >= current_date('Asia/Kolkata')-30
    ORDER BY lr_date DESC"""
# Read from Bigquery 
df = read_gbq(query,project_id = project_id)

print(df.GROSS_WT.loc[[0,1,2,3,4]])

"""# Convert nan and NAT TO Serializable
df.replace({np.nan: None,np.datetime64('Nat'): None}, inplace=True)
print(df.head())
print(df.dtypes)

# Convert datetime64[ns, UTC] TO Serializable
for column in df.select_dtypes(include=['datetime64[ns]','datetime64[ns, UTC]','datetime','dbdate']):
    df[column] = df[column].apply(lambda x: x.isoformat() if pd.notnull(x) else None)

# Convert Decimal object to seriazable float
df.tare_weight = df.tare_weight.astype(float)
df.stuff_weight = df.stuff_weight.astype(float)
df.on_account = df.on_account.astype(float).round(2)
df.rr_paid_by = df.rr_paid_by.astype(float).round(2)
df.discharge_teus = df.discharge_teus.astype(float).round(2)
df.load_teus = df.load_teus.astype(float).round(2)



bq_dict = df.to_dict()
bq_keys_list= [i.lower().replace("_","") for i in bq_dict.keys()]

# Read Json data
json_data = '{"TrainType": "LEASE","IBTrainNo": "AFAS-JNPT240418806","OBTrainNo": "JNPT-AFAS24046011","OBDischargePort": "AFAS","VisitPort": "JPY","DepartureRoute": "JPY-AFAS","RakeName": "TXBT-12","SlotSharing": "","AllotedLine": "01","EstDeptDateAndTime": "30-05-2024 12:45","ThirdPartyName": "ThirdPartyName","HUBSpokeStatus": "HUBSpokeStatus","PlanDate": "30-05-2024 12:45","ContainerNo": "SEGU5614079","ContainerSize": 40,"ContainerType": "DRY","TareWeight": "4.5","StuffWeight": "4.5","WagonNo": "62300803019","HSRoute": "HSRoute","OnAccount": "ADANI LOGISTICS LTD.","Position": "L","PostingType": "PostingType","LoadingStartDateAndTime": "30-05-2024 12:45","LoadingCompleteDateAndTime": "30-05-2024 12:45","RemovalDateAndTime": "30-05-2024 12:45","FinalDepartureDate": "30-05-2024 12:45","FNRNo": "24043026041","LoadTeus": 90,"DischargeTeus": 90,"FinalRemarks": "Final FinalRemarks","LoadingRemarks": "Loading Remarks","RRNo": "262054887","RRDate": "30-05-2024 12:45","RRInvoiceNo": "9924042710410597","RRInvoiceDate": "30-05-2024 12:45","IMEINo": "862095058917870","RRPaidBy": "ADANI LOGISTICS LTD.","Arrival_source": "Virochan","Plancement_Date": "29-05-2024 23:45","TXRStartDate": "30-05-2024 12:45","TXREndDate": "30-05-2024 13:45","StableStartDate": "30-05-2024 13:45","StableEnddate": "30-05-2024 13:45"}'
json_dict = json.loads(json_data)
json_dict_keys_list = [i.lower().replace("_","") for i in json_dict.keys()]

# Match and Unmatch from Json Payload
matching = [name for name in json_dict_keys_list if name in bq_keys_list]
unmatching = [name for name in json_dict_keys_list if name not in bq_keys_list]

if(len(matching)==len(json_dict_keys_list)):
    print("Validaion is Successful! All columns are matching")
else:
    print("numatching columns are",unmatching)

def convert_serializable(val):
    if isinstance(val,(datetime,date,time)):
        return val.isoformat()
    else:
        return val

df_serializable = df.applymap(convert_serializable)

print(df.dtypes)
print(df.iloc[1])
# Post the serialized data to Endpoint 



tbq_dict = df.to_dict()
bq_trans_dict = {i.lower().replace("_",""):j for i,j in tbq_dict.items()}
df = pd.DataFrame.from_dict(bq_trans_dict)
df.rename(columns={'plancementdate':'Plancement_Date','arrivalsource':'Arrival_source'},inplace=True)
json_data = df.to_dict('records')

result = json.dumps(json_data)
print(result)
headers_post = {
      'Content-Type': 'application/json'
}
 
response = requests.post('https://trackeruat.adani.com/trackerRail/api/Adani/SaveOBData',headers=headers_post,data=result)
 
if response.status_code == 200:
    print(response.text)
    print("Data posted successfully")
else:
    print(response.text)
    print(response.status_code)

"""



