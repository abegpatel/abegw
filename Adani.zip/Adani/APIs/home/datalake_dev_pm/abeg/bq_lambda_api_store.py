from google.cloud import bigquery
import pandas as pd
from pandas_gbq import read_gbq

project_id = 'apsez-svc-prod-datalake'
From = '2024-05-13 00:00:00'
To = '2024-05-14 00:00:00'

query = """select distinct customer_name, code, mobile_no, email, address_first, address_second, postcode, gst_no, pan_no, cast(credit_limit as string) as credit_limit,created_on 
from logistics_cleansed.layer2_customer_portal_bt_customer_master
where created_on >='{0}'
and created_on <='{1}';""".format(From,To)


df = read_gbq(query,project_id = project_id)
print(df.head())

