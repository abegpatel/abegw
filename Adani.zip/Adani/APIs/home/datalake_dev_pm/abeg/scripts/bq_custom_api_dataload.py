from google.cloud import bigquery
import pandas as pd
import zipfile
import os 
filenames = [
            'Customer_Portal_Order_Booking_Details',
            'Customer_Portal_Invoice_Details',
            'Track_Your_Container_Details'
             ]

queries = [
"""select distinct substring(cast(date as string),1,length(cast(date as string))-3) date, customer_name,customer_code, order_no, delivery_mode, container_number,container_size,from_terminal,to_terminal, eway_bill_file, line, consignee, consignee_address, consignor, consignor_address, importer, contact_no,
empty_drop_loc, transport_by, substring(cast(trailer_required_date as string),1,length(cast(trailer_required_date as string))-3) trailer_required_date, factory_address, factory, bill_to,bu_id,boe_no,substring(cast(timestamp as string),1,length(cast(timestamp as string))-3) timestamp,seal_no_1,seal_no_2,cast(ccrp_no as integer) as ccrp_no,cast(ccrp_date as string) ccrp_date,factory_ref_code 
from apsez-svc-prod-datalake.logistics_semantic.layer4_customer_portal_bt_order_booking_details_mv
where date(date)  >='2024-01-01'
and date(date) <='2024-06-10';""",
"""Select a.* from (Select invoice_no,booking_ref_code as order_no,cont_no as container_number, substring(cast(inv_gen_date as string),1,length(cast(inv_gen_date as string))-3) invoice_date,bill_item_description, customer_name,round(sum(bill_amount),2) as total_amount
from `apsez-svc-prod-datalake.logistics_semantic.layer4_bt_all_invoice_details_vw`
where source_system='CFSMAG'
    group by 1,2,3,4,5,6
) a
left join `apsez-svc-prod-datalake.logistics_semantic.layer4_bt_all_invoice_summary_vw` b
on a.invoice_no = b.invoice_no
where b.invoice_type='APPROVED' and a.order_no is not null
and date(a.invoice_date) >='2024-01-01'
and date(a.invoice_date) <='2024-06-10';""",
"""SELECT cont_no,cont_size,booking_ref_code as booking_no,train_no_vehicle_no,origin,destination,current_status,last_updated_time,current_location,latitude,longitude,seq,book_cat_calc as booking_category,
eta FROM `apsez-svc-prod-datalake.logistics_semantic.layer4_rt_trackyourcont_container_tracking_v2_mv`  qualify row_number() over(partition by cont_no,current_status) = 1"""
]

def generate_save_files(queries,filenames):
    try:
        file_list=[]
        for i,(query,filename) in enumerate(zip(queries,filenames)):
            client = bigquery.Client()
            query_job = client.query(query)
            df = query_job.result().to_dataframe()
            print(filename + ".xslx genrated")
            df.to_excel(f"{filename}.xlsx",index=False)
            file_list.append(f"{filename}.xlsx")
        zip_filename= "ApisData1.zip"
        with zipfile.ZipFile(zip_filename,'w') as zip_file:
            for file in file_list:
                zip_file.write(file)
    except Exception as e:
        print(e)
  
print(generate_save_files(queries,filenames))