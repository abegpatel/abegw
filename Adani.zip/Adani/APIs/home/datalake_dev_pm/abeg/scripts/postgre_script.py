import psycopg2
import sqlalchemy as sql
import pandas as pd
import logging
from openpyxl import load_workbook

cloud_sql_pg_prod="postgresql+psycopg2://ANALYTICS.USER1:ANALYTICSUSER1@10.81.164.61:5432/datalake_postgres_rt?sslmode=require"
def PG_CONN(task='',obj='',query='',tgt_connection_string='',table='',schema='logistics_cleansed',how=''):

    engine = sql.create_engine(tgt_connection_string)
    logging.info(f"Connection with CLOUD SQL POSTGRESQL Database established successfully!!\n")
    
    with engine.begin() as conn:
        if task == 'call':
            call_query = f"""call {obj}();"""
            call = conn.execute(call_query)
        # elif task == 'refresh':
            # refresh_query = f"""REFRESH MATERIALIZED VIEW {obj};"""
            # refresh = conn.execute(refresh_query)
        elif task=='dataframe':
            df = pd.DataFrame()
            for chunk in pd.read_sql(sql=query,con=conn,chunksize=50000):
                df = pd.concat([df,chunk])
            return df
        elif task=='query':
            conn.execute(query)
        else:
            obj.to_sql(name=table,schema=schema,con=conn,if_exists=how)
            
    conn.close()
    engine.dispose()
    



rake_running_status_mv = """select accountid,vehicleid,groupid,vehiclenumber,vehiclename,vehiclemake,vehiclemodel,fueltype,vehicleyear,drivername,speed,totalfuelconsumption,totalodometer,
    status,latitude,longitude,lastupdatedat,laststatustime,mileage,lastaccon,durationengineon,currentstatus,address,driverid,deviceid,eta,distance,vehicletypevalue,
    providercode,loadtimestamp
from logistics_cleansed.layer2_rt_fleetx_icd_patli_vehicles_live
where date(loadtimestamp) >= current_date-7"""
df = PG_CONN(task='dataframe',query=rake_running_status_mv,tgt_connection_string=cloud_sql_pg_prod)
#df.to_excel('rt_fleetx_icd_patli_vehicles_live.xlsx',index=False)
#print("file is generated")
file_path = 'CustomerPortalDetails.xlsx'
book = load_workbook(file_path)
with pd.ExcelWriter(file_path,engine='openpyxl') as writer:
    writer.book = book
    df.to_excel(writer,sheet_name='Fleetx_Icd_Patli_Vehicles_Live')
    writer.save()
print("Sheet has been added successfully")

