import os
import zipfile

zip_filename = 'myzipfile.zip'
current_dir = os.getcwd()

with zipfile.ZipFile(zip_filename,"w") as zipf:
    for filename in os.listdir(current_dir):
        if filename.endswith('.xslx'):
            zipf.write(filename)
    


