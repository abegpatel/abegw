import pandas as pd
from google.cloud import bigquery
import sqlalchemy as sql
import psycopg2 
from datetime import date, datetime, timedelta, time

def order_booking_details():
    bq_client = bigquery.Client()
    extraction_query = """SELECT
  date,
  customer_name,
  customer_code,
  order_no,
  delivery_mode,
  container_number,
  container_size,
  from_terminal,
  to_terminal,
  eway_bill_file,
  line,
  consignee,
  consignee_address,
  consignor,
  consignor_address,
  importer,
  contact_no,
  empty_drop_loc,
  transport_by,
  trailer_required_date,
  factory_address,
  factory,
  bill_to,
  timestamp,
  customer_code,
  bu_id,
  boe_no,
  seal_no_1,
  seal_no_2,
  ccrp_no,
  ccrp_date,
  factory_ref_code,
  Book_By_Party book_by_party,
  CHA cha,
  CHA_REF_Code cha_ref_code,
  exporter_name,
  exporter_ref_code,
  agent_name,
  agent_ref_code,
  DO_date do_date,
  DO_Number do_number,
  importer_name,
  importer_ref_code,
  importer_address,
  OOC_No occ_no,
  OUT_OF_CHARGE_DATE out_of_charge_date
FROM
  `apsez-svc-prod-datalake.logistics_semantic.layer4_customer_portal_bt_order_booking_details_mv` where date(date) >= current_date-454"""
    
    query_job = bq_client.query(extraction_query)
    data_df = query_job.result().to_dataframe()
    
    conn_strg = "postgresql+psycopg2://pgadmin:Adani$#390@10.90.96.14:5432/analytics?sslmode=require"
    
    engine = sql.create_engine(conn_strg)
    
    #conn = engine.raw_connection()
    del_query = """delete from logistics_prod.riddhi_order_booking_details where date(date) >= current_date-454"""
    with engine.connect() as conn:
        conn.execute(del_query)
        print("Data Deleted")
        conn.close()
    data_df['load_ts']=datetime.now()
    data_df.columns=data_df.columns.str.lower()
    print("RDS connected")
    data_df.to_sql('riddhi_order_booking_details',engine,schema='logistics_prod',if_exists='append', index=False)
    print('Rows inserted',data_df.shape[0])
    engine.dispose()
    

order_booking_details()