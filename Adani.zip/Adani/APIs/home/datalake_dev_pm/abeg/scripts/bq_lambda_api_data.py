from google.cloud import bigquery
import pandas as pd
sheetnames = ['Customer_Portal_Commodity_Master',
            'Customer_Portal_Customer_Master',
            'Customer_Portal_Factory_Details',
            'Customer_Portal_Invoice_Details',
            'customer_portal_Order_Booking_Details',
            'Customer_Portal_Vendor_Trucks_Details_Cancelled',
            'Customer_Portal_Vendor_Truck_Lr_Details',
            'Track_Your_Container_Details'
             ]
From = '2024-05-14 00:00:00'
To = '2024-06-14 00:00:00'


queries = [
"""select distinct commodity_name,substring(cast(created_on as string),1,length(cast(created_on as string))-3) created_on
from apsez-svc-prod-datalake.logistics_cleansed.layer2_customer_portal_bt_commodity_master 
where created_on >='{0}'
and created_on <='{1}';""".format(From,To),
"""select distinct customer_name, code, mobile_no, email, address_first, address_second, postcode, gst_no, pan_no, cast(credit_limit as string) as credit_limit,substring(cast(created_on as string),1,length(cast(created_on as string))-3) created_on 
from apsez-svc-prod-datalake.logistics_cleansed.layer2_customer_portal_bt_customer_master
where created_on >='{0}'
and created_on <='{1}';""".format(From,To),
"""select distinct customer_name, latitude, longitude, plant_manager_name, CAST(plant_manager_phone_no AS INT64) plant_manager_phone_no, address,substring(cast(changed_on as string),1,length(cast(changed_on as string))-3) changed_on,substring(cast(timestamp as string),1,length(cast(timestamp as string))-3) timestamp 
from apsez-svc-prod-datalake.logistics_cleansed.layer2_customer_portal_bt_factory_details
where changed_on >='{0}'
and changed_on <='{1}';""".format(From,To),
"""Select a.* from (Select invoice_no,booking_ref_code as order_no,cont_no as container_number, substring(cast(inv_gen_date as string),1,length(cast(inv_gen_date as string))-3) invoice_date,bill_item_description, customer_name,round(sum(bill_amount),2) as total_amount
from `apsez-svc-prod-datalake.logistics_semantic.layer4_bt_all_invoice_details_vw`
where source_system='CFSMAG'
    group by 1,2,3,4,5,6
) a
left join `apsez-svc-prod-datalake.logistics_semantic.layer4_bt_all_invoice_summary_vw` b
on a.invoice_no = b.invoice_no
where b.invoice_type='APPROVED' and a.order_no is not null
and a.invoice_date >='{0}'
and a.invoice_date <='{1}';""".format(From,To),
"""select distinct substring(cast(date as string),1,length(cast(date as string))-3) date, customer_name,customer_code, order_no, delivery_mode, container_number,container_size,from_terminal,to_terminal, eway_bill_file, line, consignee, consignee_address, consignor, consignor_address, importer, contact_no,
empty_drop_loc, transport_by, substring(cast(trailer_required_date as string),1,length(cast(trailer_required_date as string))-3) trailer_required_date, factory_address, factory, bill_to,bu_id,boe_no,substring(cast(timestamp as string),1,length(cast(timestamp as string))-3) timestamp,seal_no_1,seal_no_2,cast(ccrp_no as integer) as ccrp_no,cast(ccrp_date as string) ccrp_date,factory_ref_code 
from apsez-svc-prod-datalake.logistics_semantic.layer4_customer_portal_bt_order_booking_details_mv
where date  >='{0}'
and date <='{1}';""".format(From,To),
"""select substring(cast(modified_on as string),1,length(cast(modified_on as string))-3) modified_on, lr_no from apsez-svc-prod-datalake.logistics_semantic.layer4_customer_portal_lr_tjo_details_cancelled_vw
where modified_on>='{0}'
and modified_on<='{1}';""".format(From,To),
"""WITH
   lr_tjo
    as
    (
    select distinct lr_no,CONTAINER_NO ,MODIFIED_ON
    from `apsez-svc-prod-datalake.gg_replica.layer1_cfsmag_et_lr_tjo_details`
    ),
      p2 AS (
      SELECT
      p2.LR_NO,
        p2.LR_DATE,
        p2.VEHICLE_NO,
       p2.CUSTOMER,
        FROM_LOC,
        Factory AS to_location,
        p2.TJO_No,
        p2.GROSS_WT,
        COMMODITY,
        COMMODITY_1,
       p2. Container_No,
        p2.Container_Size,
        tr.truck_reg_number,
       p2.TRANSPORTER,
        fm.FACTORY_REF_CODE AS factory_code,
        p2.TRANSPORT_BY AS Business_Unit,
        EMPTY_PICKUP_LOC_NAME,
        EMPTY_DROP_LOC_NAME,
        p2.location,
        lr_tjo.MODIFIED_ON,
        p2.Transaction_Type,
        p2.BOOKING_NO
      FROM
        `apsez-svc-prod-datalake.logistics_semantic.layer4_rt_all_road_operations_p2_mv` p2
      LEFT JOIN
        apsez-svc-prod-datalake.logistics_cleansed.layer2_cfsmag_all_truck_master tr
      ON
        p2.vehicle_no=tr.truck_reg_number
      left join  lr_tjo
      on p2.LR_NO = cast(lr_tjo.LR_NO as numeric) and p2.Container_No=lr_tjo.container_no
      LEFT JOIN
        `gg_replica.layer1_cfsmag_et_factory_master` fm
      ON
        fm.FACTORY_ID = p2.FACTORY_ID
      WHERE
        p2.TRANSPORT_BY IN ('ALL',
          'ALSPL')
      )
    SELECT
      DISTINCT CAST(LR_NO AS INT64) LR_NO,
      substring(cast(LR_DATE as string),1,length(cast(LR_DATE as string))-3) lr_date,
      VEHICLE_NO,
      CUSTOMER,
      FROM_LOC AS FromLocation,
      to_location AS ToLocation,
      TJO_No,
      Container_No,
      CAST(Container_Size AS INT64) Container_Size,
      CAST(GROSS_WT AS INT64) GROSS_WT,
      COMMODITY,
      TRANSPORTER,
      Factory_Code,
      Business_Unit,
      EMPTY_PICKUP_LOC_NAME,
      EMPTY_DROP_LOC_NAME,
      location,
      substring(cast(MODIFIED_ON as string),1,length(cast(MODIFIED_ON as string))-3) MODIFIED_ON,
      Transaction_Type,
      BOOKING_NO AS order_no
    FROM p2
    where LR_DATE >='{0}' and LR_DATE <='{1}'
    ORDER BY
      lr_date DESC""".format(From,To),
"""SELECT cont_no,cont_size,booking_ref_code as booking_no,train_no_vehicle_no,origin,destination,current_status,last_updated_time,current_location,latitude,longitude,seq,book_cat_calc as booking_category,eta
FROM `apsez-svc-prod-datalake.logistics_semantic.layer4_rt_trackyourcont_container_tracking_v2_mv` 
where length(cont_no)>=11 qualify row_number() over(partition by cont_no,current_status) = 1 and
book_date >= '{0}' and book_date <= '{1}';""".format(From,To)
]


def generate_save_files(queries,sheetnames):
  try:
    df_dict = {}
    for i,(query,sheetname) in enumerate(zip(queries,sheetnames)):
        client = bigquery.Client()
        query_job = client.query(query)
        df = query_job.result().to_dataframe()
        df_dict[sheetname]=df
    with pd.ExcelWriter('CustomerPortalDetails.xlsx',engine='openpyxl') as writer:
      for sheetname,df in df_dict.items():
        df.to_excel(writer,sheet_name=sheetname,index=False)
    print("All sheets have been created successfully")
  except Exception as e:
    print(e)
  
print(generate_save_files(queries,sheetnames))
