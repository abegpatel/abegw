import pymssql
server = '10.112.88.74:1433'
database = 'trackerUAT'
username = 'trackerach'
password = 'Tr@cker@22'

conn = pymssql.connect(
    server=server,
    user=username,
    password=password,
    database=database)

print("Connection is Successful")
cursor = conn.cursor()
cursor.execute("SELECT * FROM dbo.AlphaCodes")
rows=cursor.fetchall()
for row in rows:
    print(row)

conn.close()
