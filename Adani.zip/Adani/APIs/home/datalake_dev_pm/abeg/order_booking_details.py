import pandas as pd
from google.cloud import bigquery
import sqlalchemy as sql
import psycopg2 
from datetime import date, datetime, timedelta, time

def order_booking_details():
    bq_client = bigquery.Client()
    extraction_query = """select distinct date, cp.customer_name,customer_code, order_no, delivery_mode, container_number,container_size,cp.from_terminal,cp.to_terminal, eway_bill_file, line, consignee, cp.consignee_address, consignor, consignor_address, importer, contact_no,
 empty_drop_loc, transport_by, substring(cast(trailer_required_date as string),1,length(cast(trailer_required_date as string))-3) trailer_required_date, factory_address, factory, bill_to,cp.bu_id,cp.boe_no,--timestamp,
 cp.seal_no_1,cp.seal_no_2,cast(ccrp_no as integer) as ccrp_no,ccrp_date,factory_ref_code,cmas.customer_name as cha,cmas.customer_ref_code as cha_ref_code,cmass.CUSTOMER_NAME AS exporter_name,cmass.Customer_ref_code as exporter_ref_code,AID.customer_name as agent_name,AID.customer_ref_code as agent_ref_code,
  CASE
        WHEN b.book_by_id IN (
            SELECT customer_id
            FROM gg_replica.layer1_cfsmag_et_customer_master
            WHERE customer_name NOT IN (
                SELECT DISTINCT Customer_NAME
                FROM gg_replica.layer1_cfsmag_et_customer_master
                WHERE CUSTOMER_ID IN (SELECT DISTINCT line_id FROM gg_replica.layer1_cfsmag_et_booking)
            )
        ) THEN cm.customer_name
        WHEN b.cha_id IN (
            SELECT customer_id
            FROM gg_replica.layer1_cfsmag_et_customer_master
            WHERE customer_name IN (
                SELECT DISTINCT Customer_NAME
                FROM gg_replica.layer1_cfsmag_et_customer_master
                WHERE CUSTOMER_ID IN (SELECT DISTINCT line_id FROM gg_replica.layer1_cfsmag_et_booking)
            )
        ) AND b.exporter_id IN (
            SELECT customer_id
            FROM gg_replica.layer1_cfsmag_et_customer_master
            WHERE customer_name IN (
                SELECT DISTINCT Customer_NAME
                FROM gg_replica.layer1_cfsmag_et_customer_master
                WHERE CUSTOMER_ID IN (SELECT DISTINCT line_id FROM gg_replica.layer1_cfsmag_et_booking)
            )
        ) THEN cmas.customer_name
        ELSE cmass.customer_name
    END AS book_by_party
  from logistics_semantic.layer4_customer_portal_bt_order_booking_details_mv cp
  INNER JOIN
    gg_replica.layer1_cfsmag_et_mty_container_details E
    ON E.BOOKING_NO = CP.order_no
INNER JOIN
    gg_replica.layer1_cfsmag_et_booking B
    ON E.BOOKING_ID = B.BOOKING_NO
    AND CASE E.BU_ID WHEN 1 THEN 1 END = CASE B.BU_ID WHEN 1 THEN 1 END
    left join gg_replica.layer1_cfsmag_et_customer_master cmas
     on cmas.customer_id = b.cha_id
     left join gg_replica.layer1_cfsmag_et_customer_master cmass
     on cmass.customer_id = b.exporter_id
    INNER JOIN gg_replica.layer1_cfsmag_et_customer_master CM
         ON B.BOOK_BY_ID = CM.CUSTOMER_ID AND case CM.BU_ID when 1 then 1 end  = case B.BU_ID when 1 then 1 end
         left join gg_replica.layer1_cfsmag_et_customer_master AID
    on AID.customer_id = B.agent_id
 where date(date) >= current_date('Asia/Kolkata')-452"""
    
    query_job = bq_client.query(extraction_query)
    data_df = query_job.result().to_dataframe()
    
    conn_strg = "postgresql+psycopg2://pgadmin:Adani$#390@10.90.96.14:5432/analytics?sslmode=require"
    
    engine = sql.create_engine(conn_strg)
    
    #conn = engine.raw_connection()
    del_query = """delete from logistics_prod.riddhi_order_booking_details where date(date) >= current_date-452"""
    with engine.connect() as conn:
        conn.execute(del_query)
        print("Data Deleted")
        conn.close()
    data_df['load_ts']=datetime.now()
    data_df.columns=data_df.columns.str.lower()
    print("RDS connected")
    data_df.to_sql('riddhi_order_booking_details',engine,schema='logistics_prod',if_exists='append', index=False)
    print('Rows inserted',data_df.shape[0])
    engine.dispose()
    

order_booking_details()