from flask import Flask
import functions_framework


app = Flask(__name__)

@functions_framework.http
def main(request):
    return app(request)

@app.route('/')
def hello_world():
    return "Hello I'm in"

if __name__ == '__main__':
    app.run(debug=True)

"""result = df.to_dict('records')
result = json.dumps(result)
payload_string = result.encode("utf-8")
print(payload_string)"""