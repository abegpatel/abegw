import requests
from requests.auth import HTTPBasicAuth


"""print("abeg")
print(requests.__version__)
url = 'http://15.207.129.235:8181/api/api-login'
username = 'AdaniCustomerAPI2024'
password = 'YAGOgipfFsvzbs0'
response = requests.post(url,auth=HTTPBaiscAuth(username,password))

if (response.status_code == 200):
    token = response.json().get('token')
    print(token)
else:
    print(respo.status_code,response.text)"""