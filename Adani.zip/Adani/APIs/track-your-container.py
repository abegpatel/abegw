import functions_framework
import pandas_gbq as pd
import json
from urllib.parse import unquote
from datetime import datetime, timedelta
from google.cloud import storage
from pytz import timezone
import numpy as np

storage_client = storage.Client()


@functions_framework.http
def tyc_end_to_end(request, context=None):
    print('request:',request)
    try:
        if ',' in str(request):
            cntr_nos= tuple(str(request).split('?')[1].split(' ')[0].split('=')[1].replace("'","").split(','))
            print('cont no.:',cntr_nos)
            cntr_nos = cntr_nos[:25]
            print('container numbers:',cntr_nos)
            query ="""
            --**Riddhi Corp - Customer Portal - Track Your Container**--
            SELECT cont_no,cont_size,booking_ref_code as booking_no,train_no_vehicle_no,origin,destination,current_status,last_updated_time,current_location,latitude,longitude,seq,book_cat_calc as booking_category,eta FROM `apsez-svc-prod-datalake.logistics_semantic.layer4_rt_trackyourcont_container_tracking_v2_mv` where cont_no in {} and length(cont_no)>=11 qualify row_number() over(partition by cont_no,current_status) = 1""".format(cntr_nos)
            print(query)
   

        else:
        
            cntr_nos= str(request).split('?')[1].split(' ')[0].split('=')[1].replace("'","")
            print('cont no.:',cntr_nos) 
            cntr_nos = cntr_nos[:25]
            print('container numbers:',cntr_nos) 
            query ="""
            --**Riddhi Corp - Customer Portal - Track Your Container**--
            SELECT cont_no,cont_size,booking_ref_code as booking_no,train_no_vehicle_no,origin,destination,current_status,last_updated_time,current_location,latitude,longitude,seq,book_cat_calc as booking_category,
            eta FROM `apsez-svc-prod-datalake.logistics_semantic.layer4_rt_trackyourcont_container_tracking_v2_mv` where cont_no = '{}' and length(cont_no)>=11 qualify row_number() over(partition by cont_no,current_status) = 1""".format(cntr_nos)
            print(query)
     
            #cntr_nos= tuple(str(request).split('&')[1].split(' ')[0].split('=')[1].split(',').replace("'",""))

        #print('cont no.:',cntr_nos)
    except Exception as e:
        print("Error: {0}".format(e))
        raise Exception('"Please enter a valid query parameter"')
    
    
    #query ="""select * from apsez-svc-prod-datalake.logistics_semantic.layer4_rt_trackyourcont_container_tracking_vw where cont_no in {}""".format(cntr_nos)
    #print(query)
    #Declaring Variables for Pandas GBQ
    project='apsez-svc-prod-datalake'
    
    try:
        intermediate_result = pd.read_gbq(query, project_id = project)
        intermediate_result[['latitude','longitude']] = intermediate_result[['latitude','longitude']].astype(str)
        intermediate_result[['latitude','longitude']] = intermediate_result[['latitude','longitude']].replace("nan","")
        intermediate_result[['latitude','longitude']] = intermediate_result[['latitude','longitude']].replace("NaN","")
        result = intermediate_result.to_dict('records')
        result = json.dumps(result)
        payload_byte_string = result.encode("utf-8")
        ind_time = datetime.now(timezone("Asia/Kolkata")).strftime("%Y-%m-%d %H:%M:%S")
        gcs_file = "logistics/"+datetime.today().strftime("%Y/%b/%Y-%m-%d/")+'track_your_container/track_your_container_'+str(ind_time)+'.json'
        gcs_file = gcs_file.replace(" ","_")
        print("gcs file : ",gcs_file)
        bucket_name = 'apsez-apigee-apicall-audit' 
        bucket = storage_client.get_bucket(bucket_name)
        blob=bucket.blob(gcs_file)
        blob.upload_from_string(payload_byte_string)
        print("json uploaded to GCS as ",gcs_file)
        print('bq result: ',result)
        print("Query Executed Successfully")
        return result
    except Exception as e:
        print("Error: {0}".format(e))
        raise Exception('"ExecutionError": "Please contact API Developer"')
