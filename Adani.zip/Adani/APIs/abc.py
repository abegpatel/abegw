from google.cloud import bigquery
import pandas as pd
import numpy as np
import json
import requests
from datetime import date,datetime,time
 
project_id = 'apsez-svc-prod-datalake'
extraction_query = """
SELECT CASE WHEN rm.RAKE_TYPE='L' THEN 'LEASED'     WHEN rm.RAKE_TYPE='O' THEN 'OWNED'   ELSE   'THIRD-PARTY' END   AS train_type,   arp.ib_train_no,   arp.ob_train_no,  arp.ob_discharge_port,   arp.visit_port,   arp.visit_port||'-'||arp.ob_discharge_port departure_route,   rm.rake_name,   NULL slot_sharing,   arp.railway_line_id alloted_line,   arp.Actual_departure_date Est_Dept_DateAndTime,   NULL AS third_party_name,   NULL AS hub_spoke_status,   timestamp(NULL) plan_date,   rr.cont_no container_no,   rr.cont_size container_size,   rr.cont_type container_type,   ccdtl.conttare tare_weight,   (CAST(ccdtl.groswght AS FLOAT64) - CAST(ccdtl.conttare AS FLOAT64)) stuff_weight,   ccdtl.wgonnumb wagon_no,   NULL hs_route,   arp.rr_paid_by on_account,   rr.position,   NULL posting_type,   arp.LOAD_START_DATE loading_start_dateandtime,   arp.LOAD_COMPLETE_DATE loading_complete_dateandtime,   arp.removal_date removal_dateandtime,   arp.Actual_departure_date final_departure_date,   arp.frn_no fnr_no,   arp.load_plan_teus load_teus,   arp.discharge_plan_teus discharge_teus,   NULL final_remarks,   NULL loading_remarks,   arp.rr_no,   arp.rr_date,   chdr.taxinvcid rrinvoiceno,   chdr.invcdate rrinvoicedate,   arp.IMEI_NO,   arp.rr_paid_by,   arp.visit_port arrival_source,   arp.placement_date plancement_date,   ARP.TXR_START_DATE,   ARP.TXR_COMPLETE_DATE txr_end_date,   arp.STABLE_START_DATE,   arp.STABLE_COMPLETE_DATE stable_end_date
FROM   `gg_replica.layer1_cfsmag_et_train_visit` arp
LEFT JOIN   `logistics_semantic.layer4_rt_rail_report_mv` rr ON   arp.train_visit_no = rr.train_visit_no
LEFT JOIN   `gg_replica.layer1_cfsmag_et_rake_master` rm ON   arp.rake_id = rm.rake_id
LEFT JOIN   `gg_replica.layer1_cris_api_headerdetails_staging` chdr ON   chdr.fnr = arp.frn_no
LEFT JOIN   `gg_replica.layer1_cris_api_containerdtls_staging` ccdtl ON   TRIM(ccdtl.invcid) = TRIM(chdr.invoiceid)   AND rr.cont_no = ccdtl.contid
LEFT JOIN   `gg_replica.layer1_cfsmag_et_route_master` rom ON   rom.route_id = arp.ob_route_code
WHERE   chdr.fnr IS NOT NULL   AND ccdtl.contid IS NOT NULL   AND arp.ob_discharge_port IN ('AFAS','TUMB','NTSJ') and arp.timestamp >= timestamp(current_datetime('Asia/Kolkata')) - interval 1 DAY
"""
# Read from Bigquery
try:
    client = bigquery.Client()
    query_job = client.query(extraction_query)
    df = query_job.result().to_dataframe()
    client.close()
   
except Exception as E:
    print('ERROR:Query Error-',E)

df[['slot_sharing','third_party_name','hub_spoke_status','plan_date','hs_route','on_account','posting_type','load_teus','discharge_teus','final_remarks','loading_remarks','rr_paid_by']] = df[['slot_sharing','third_party_name','hub_spoke_status','plan_date','hs_route','on_account','posting_type','load_teus','discharge_teus','final_remarks','loading_remarks','rr_paid_by']].fillna(0)
df[['slot_sharing','third_party_name','hub_spoke_status','plan_date','hs_route','on_account','posting_type','load_teus','discharge_teus','final_remarks','loading_remarks','rr_paid_by']] = df[['slot_sharing','third_party_name','hub_spoke_status','plan_date','hs_route','on_account','posting_type','load_teus','discharge_teus','final_remarks','loading_remarks','rr_paid_by']].astype(int)
 
 
datetime_cols = ['Est_Dept_DateAndTime', 'loading_start_dateandtime', 'loading_complete_dateandtime', 'removal_dateandtime', 'final_departure_date', 'rr_date', 'plancement_date', 'TXR_START_DATE', 'txr_end_date', 'STABLE_START_DATE', 'stable_end_date']
 
for col in datetime_cols:
    df[col] = df[col].dt.tz_localize(None)
    df[col] = df[col].dt.strftime('%d-%m-%Y %H:%M')
    df[col] = df[col].apply(lambda x: '01-01-1900 00:00' if str(x) == 'nan' else x)
 
print(df.dtypes)
df['stuff_weight'] = df['stuff_weight'].astype(float)
df['rrinvoicedate'] = pd.to_datetime(df['rrinvoicedate']).dt.strftime('%d-%m-%Y %H:%M')
print(df.dtypes)
df.columns = df.columns.str.replace("_","")
df.rename(columns={'plancementdate':'Plancement_Date','arrivalsource':'Arrival_source'},inplace=True)
result = df.to_dict('records')
result = json.dumps(result)

headers_post = {
      'Content-Type': 'application/json'
}
 
response = requests.post('https://trackeruat.adani.com/trackerRail/api/Adani/SaveOBData',headers=headers_post,data=result)
 
if response.status_code == 200:
    print(response.text)
    print("Data posted successfully")
else:
    print(response.text)
    print(response.status_code)