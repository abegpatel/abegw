import psycopg2 
import ssl 

connection = psycopg2.connect(  host = '10.79.164.3',  port = 5432,  user = 'test_user',  password = 'test_user',  sslmode = 'require', 
 sslrootcert = 'server-ca.pem',sslcert = 'client-cert.pem', sslkey = 'client-key.pem', database = 'test_db')
print(connection)
cursor = connection.cursor() 
df=cursor.execute("select * from detail")
df2=df.fetchall()
print(df2)
connection.commit()


# print('start..')
# query_pattern = 'select * from months'
# engine = sql.create_engine('postgresql+psycopg2://test_user:test_user@10.79.164.3:5432/test_db')
# conn = engine.connect()
# results = conn.execute(query_pattern).fetchall()
# df = pd.DataFrame(results,index=None)
# df2 = df.to_dict('records')    
# print(df2)
