import argparse
import pandas as pd
import json
import logging
import os
import datetime
import sqlalchemy as sql


print('start..')
query_pattern = 'select * from months'
engine = sql.create_engine('postgresql+pg8000://test_user:test_user@10.79.164.3:5432/test_db')
conn = engine.connect()
results = conn.execute(query_pattern).fetchall()
df = pd.DataFrame(results,index=None)
df2 = df.to_dict('records')    
print(df2)