import os
import logging
from datetime import timedelta, datetime
from airflow import models
from airflow import DAG
from airflow.providers.apache.beam.operators.beam import (
    BeamRunJavaPipelineOperator,
    BeamRunPythonPipelineOperator,
)

DEFAULT_ARGS = {
    'depends_on_past': False,
    'start_date': datetime.today() - timedelta(1),
    'catchup': False,
    'email_on_failure': True,
    'email': 'Akash.Yadav1@adani.com',
    'retries': 3,
    'retry_delay': timedelta(minutes=1)
}

dag = DAG(
    'dataflow_test_dag',
    schedule_interval=None,
    default_args=DEFAULT_ARGS
)

GCS_PYTHON = 'gs://apsez_dataflow_test/dataflow-composer-test-code/sample_pipeline.py'

start_python_job_async = BeamRunPythonPipelineOperator(
    task_id="start-python-job-async",
    runner="DataflowRunner",
    py_file=GCS_PYTHON,
    # py_options=[],
    # pipeline_options={},
    py_requirements=['apache-beam[gcp]==2.25.0'],
    default_pipeline_options={
        "project": 'apsez-svc-dev-datalake',
        # "region": 'asia-south1',
        "zone": 'asia-south1-c',
        "tempLocation": 'gs://test_adanisez/tmp/',
        "network": "apsez-host-vpc",
        "subnetwork": "https://www.googleapis.com/compute/v1/projects/apsez-host-prj/regions/asia-south1/subnetworks/apsez-subnet-datalake-dev",
        # "ipConfiguration": "WORKER_IP_PRIVATE",
        "serviceAccountEmail": "apsez-datalake-d-iam-sa5@apsez-svc-dev-datalake.iam.gserviceaccount.com",
        "no_use_public_ips":None,
        },
    py_interpreter='python3',
    py_system_site_packages=False,
    dataflow_config={
        "job_name": "start-python-job-async",
        "location": 'asia-south1',
        "wait_until_finished": True,
        # "no_use_public_ips",
    },
    dag=dag
)