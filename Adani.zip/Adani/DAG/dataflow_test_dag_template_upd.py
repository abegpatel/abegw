import os
import logging
from datetime import timedelta, datetime
from airflow import models
from airflow import DAG
from airflow.contrib.operators.dataflow_operator import DataflowTemplateOperator


DEFAULT_ARGS = {
    'depends_on_past': False,
    'start_date': datetime.today() - timedelta(1),
    'catchup': False,
    'email_on_failure': True,
    'email': 'Akash.Yadav1@adani.com',
    'retries': 3,
    'retry_delay': timedelta(minutes=1),
    'dataflow_default_options': {
        "project": 'apsez-svc-dev-datalake',
        # "region": 'asia-south1',
        "zone": 'asia-south1-c',
        "tempLocation": 'gs://test_adanisez/tmp/',
        "network": "apsez-host-vpc",
        "subnetwork": "https://www.googleapis.com/compute/v1/projects/apsez-host-prj/regions/asia-south1/subnetworks/apsez-subnet-datalake-dev",
        "ipConfiguration": "WORKER_IP_PRIVATE",
        "serviceAccountEmail": "apsez-datalake-d-iam-sa5@apsez-svc-dev-datalake.iam.gserviceaccount.com"
    },
}

dag = DAG(
    'dataflow_test_dag_template',
    schedule_interval=None,
    default_args=DEFAULT_ARGS
)

# GCS_PYTHON = 'gs://apsez_dataflow_test/dataflow-composer-test-code/sample_pipeline.py'

start_template_job = DataflowTemplateOperator(
    task_id="start-template-job",
    template='gs://dataflow-templates/latest/Word_Count',
    parameters={'inputFile': "gs://test_adanisez/test.txt", 'output': "gs://test_adanisez/output/test.txt"},
    location= 'asia-south1',
    dag=dag
)