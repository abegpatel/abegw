import os
import logging
from datetime import timedelta, datetime
from airflow import models
from airflow import DAG
from airflow.contrib.operators import gcs_to_bq


DEFAULT_ARGS = {
    'depends_on_past': False,
    'start_date': datetime.today() - timedelta(1),
    'catchup': False,
    'email_on_failure': True,
    'email': 'Akash.Yadav1@adani.com',
    'retries': 3,
    'retry_delay': timedelta(minutes=1),
}

dag = DAG(
    'test_dag',
    schedule_interval=None,
    default_args=DEFAULT_ARGS
)


task_ggind_config_template_1 = gcs_to_bq.GoogleCloudStorageToBigQueryOperator(
    task_id='GCS_TO_BQ',
    bucket='apsez_dataflow_test',
    source_objects=['*.csv'],
    destination_project_dataset_table= 'apsez-svc-dev-datalake.Test_Dev.test_table',
    skip_leading_rows=1,
    write_disposition='WRITE_TRUNCATE',
    autodetect = True,
    email_on_failure = True,
    dag=dag)
