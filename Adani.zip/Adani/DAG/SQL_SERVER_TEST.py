from datetime import timedelta,datetime
from airflow import models
from airflow import DAG
from airflow.contrib.operators.bigquery_operator import BigQueryOperator
from airflow.operators.bash import BashOperator
from airflow.operators.dagrun_operator import TriggerDagRunOperator
from google.cloud import bigquery

BQ_PROJECT = "apsez-svc-dev-datalake"
BQ_stored_proc_dataset = "STORED_PROCEDURE"


DEFAULT_ARGS = {  
    'depends_on_past': False,
    'start_date': datetime(2022,5,13,4,8),
    'catchup': False,
    'email_on_failure': False,
    'email_on_retry': False,
    'email': ['kpmg0008@adani.com'],
    'retries': 3,
    'retry_delay': timedelta(minutes=1),
}


dag = DAG(
    'SQL_SERVER_TEST',
    schedule_interval = '*/3 * * * *',
    default_args = DEFAULT_ARGS
)

SQL_SERVER_TEST = BashOperator(
     task_id='SQL_SERVER_TEST',
     #bash_command='ping 10.81.162.22',
	 bash_command='python /home/airflow/gcs/dags/sqlservertest.py',
     dag=dag
)



SQL_SERVER_TEST