import pymssql
import pandas as pd
import pandas_gbq as pdq

username='analytics_user'
passs='analytics$user'
hostname='10.81.162.22'
database_name='MercuryDB'

mydb = pymssql.connect(
host=hostname,
user=username,
password=passs,
database=database_name
)

query_pattern = "select * from dbo.ALL_Rail_Volume"

sql_query = pd.read_sql(query_pattern, mydb)
df = pd.DataFrame(sql_query,columns=['DATE','Strategic_Alliance','Network','Existing','New','Other','ALS','WW'],index=None)
#df2 = df.to_dict('records')

print(df)

BIGQUERY_TABLE = 'apsez-svc-dev-datalake.Test_Dev.sqlserver_test'

bigquery_schema=[{'name':'DATE','type':'date'},{'name':'Strategic_Alliance','type':'float'},{'name':'Network','type':'float'},{'name':'Existing','type':'float'},{'name':'New','type':'float'},{'name':'Other','type':'float'},{'name':'ALS','type':'float'},{'name':'WW','type':'float'}]

pdq.to_gbq(df,BIGQUERY_TABLE,if_exists='append',table_schema=bigquery_schema,api_method="load_csv")