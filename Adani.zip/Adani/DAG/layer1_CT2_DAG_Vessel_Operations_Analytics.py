from datetime import timedelta,datetime
from airflow import models
from airflow import DAG
from airflow.contrib.operators.bigquery_operator import BigQueryOperator
from airflow.operators.dagrun_operator import TriggerDagRunOperator
from google.cloud import bigquery

BQ_PROJECT = "apsez-svc-dev-datalake"
BQ_stored_proc_dataset = "STORED_PROCEDURE"


DEFAULT_ARGS = {  
    'depends_on_past': False,
    'start_date': datetime(2022,4,27,13,16),
    'catchup': False,
    'email_on_failure': False,
    'email_on_retry': False,
    'email': ['kpmg0009@adani.com','kpmg0008@adani.com','kpmg0010@adani.com'],
    'retries': 3,
    'retry_delay': timedelta(minutes=1),
}


dag = DAG(
    'layer1_CT2_DAG_Vessel_Operations_Analytics',
    schedule_interval = '*/3 * * * *',
    default_args = DEFAULT_ARGS
)



layer2_sp_BT_CT2_CTRMovement = BigQueryOperator(
     task_id='layer2_sp_BT_CT2_CTRMovement',
     sql='''CALL `{0}.{1}.{2}`()'''.format(BQ_PROJECT, BQ_stored_proc_dataset,"layer2_sp_BT_CT2_CTRMovement"),
     allow_large_results=True, 
     bigquery_conn_id= 'bigquery_default',
     create_disposition='CREATE_IF_NEEDED',
     use_legacy_sql=False, 
     email_on_failure = True,
     dag=dag
)

layer3_sp_BT_CT2_ports_tbl_ctrmovement = BigQueryOperator(
     task_id='layer3_sp_BT_CT2_ports_tbl_ctrmovement',
     sql='''CALL `{0}.{1}.{2}`()'''.format(BQ_PROJECT, BQ_stored_proc_dataset,"layer3_sp_BT_CT2_ports_tbl_ctrmovement"),
     allow_large_results=True, 
     bigquery_conn_id= 'bigquery_default',
     create_disposition='CREATE_IF_NEEDED',
     use_legacy_sql=False, 
     email_on_failure = True,
     dag=dag
)




layer2_sp_BT_CT2_expected_vessel_details = BigQueryOperator(
     task_id='layer2_sp_BT_CT2_expected_vessel_details',
     sql='''CALL `{0}.{1}.{2}`()'''.format(BQ_PROJECT, BQ_stored_proc_dataset,"layer2_sp_BT_CT2_expected_vessel_details"),
     allow_large_results=True, 
     bigquery_conn_id= 'bigquery_default',
     create_disposition='CREATE_IF_NEEDED',
     use_legacy_sql=False, 
     email_on_failure = True,
     dag=dag
)

layer3_sp_BT_CT2_ports_tbl_expected_vessel_details = BigQueryOperator(
     task_id='layer3_sp_BT_CT2_ports_tbl_expected_vessel_details',
     sql='''CALL `{0}.{1}.{2}`()'''.format(BQ_PROJECT, BQ_stored_proc_dataset,"layer3_sp_BT_CT2_ports_tbl_expected_vessel_details"),
     allow_large_results=True, 
     bigquery_conn_id= 'bigquery_default',
     create_disposition='CREATE_IF_NEEDED',
     use_legacy_sql=False, 
     email_on_failure = True,
     dag=dag
)



layer2_sp_BT_CT2_TDR_VesselDetails = BigQueryOperator(
     task_id='layer2_sp_BT_CT2_TDR_VesselDetails',
     sql='''CALL `{0}.{1}.{2}`()'''.format(BQ_PROJECT, BQ_stored_proc_dataset,"layer2_sp_BT_CT2_TDR_VesselDetails"),
     allow_large_results=True, 
     bigquery_conn_id= 'bigquery_default',
     create_disposition='CREATE_IF_NEEDED',
     use_legacy_sql=False, 
     email_on_failure = True,
     dag=dag
)

layer3_sp_BT_CT2_ports_tbl_tdr_vesseldetails = BigQueryOperator(
     task_id='layer3_sp_BT_CT2_ports_tbl_tdr_vesseldetails',
     sql='''CALL `{0}.{1}.{2}`()'''.format(BQ_PROJECT, BQ_stored_proc_dataset,"layer3_sp_BT_CT2_ports_tbl_tdr_vesseldetails"),
     allow_large_results=True, 
     bigquery_conn_id= 'bigquery_default',
     create_disposition='CREATE_IF_NEEDED',
     use_legacy_sql=False, 
     email_on_failure = True,
     dag=dag
)


layer2_sp_BT_CT2_TPR_VesselDelays = BigQueryOperator(
     task_id='layer2_sp_BT_CT2_TPR_VesselDelays',
     sql='''CALL `{0}.{1}.{2}`()'''.format(BQ_PROJECT, BQ_stored_proc_dataset,"layer2_sp_BT_CT2_TPR_VesselDelays"),
     allow_large_results=True, 
     bigquery_conn_id= 'bigquery_default',
     create_disposition='CREATE_IF_NEEDED',
     use_legacy_sql=False, 
     email_on_failure = True,
     dag=dag
)

layer3_sp_BT_CT2_ports_tbl_tpr_vesseldelays = BigQueryOperator(
     task_id='layer3_sp_BT_CT2_ports_tbl_tpr_vesseldelays',
     sql='''CALL `{0}.{1}.{2}`()'''.format(BQ_PROJECT, BQ_stored_proc_dataset,"layer3_sp_BT_CT2_ports_tbl_tpr_vesseldelays"),
     allow_large_results=True, 
     bigquery_conn_id= 'bigquery_default',
     create_disposition='CREATE_IF_NEEDED',
     use_legacy_sql=False, 
     email_on_failure = True,
     dag=dag
)

layer2_sp_BT_CT2_TPR_VesselSummary = BigQueryOperator(
     task_id='layer2_sp_BT_CT2_TPR_VesselSummary',
     sql='''CALL `{0}.{1}.{2}`()'''.format(BQ_PROJECT, BQ_stored_proc_dataset,"layer2_sp_BT_CT2_TPR_VesselSummary"),
     allow_large_results=True, 
     bigquery_conn_id= 'bigquery_default',
     create_disposition='CREATE_IF_NEEDED',
     use_legacy_sql=False, 
     email_on_failure = True,
     dag=dag
)

layer3_sp_BT_CT2_ports_tbl_tpr_vesselsummary = BigQueryOperator(
     task_id='layer3_sp_BT_CT2_ports_tbl_tpr_vesselsummary',
     sql='''CALL `{0}.{1}.{2}`()'''.format(BQ_PROJECT, BQ_stored_proc_dataset,"layer3_sp_BT_CT2_ports_tbl_tpr_vesselsummary"),
     allow_large_results=True, 
     bigquery_conn_id= 'bigquery_default',
     create_disposition='CREATE_IF_NEEDED',
     use_legacy_sql=False, 
     email_on_failure = True,
     dag=dag
)




layer2_sp_BT_CT2_CTRMovement >> layer3_sp_BT_CT2_ports_tbl_ctrmovement
layer2_sp_BT_CT2_expected_vessel_details >> layer3_sp_BT_CT2_ports_tbl_expected_vessel_details
layer2_sp_BT_CT2_TDR_VesselDetails >> layer3_sp_BT_CT2_ports_tbl_tdr_vesseldetails
layer2_sp_BT_CT2_TPR_VesselDelays >> layer3_sp_BT_CT2_ports_tbl_tpr_vesseldelays
layer2_sp_BT_CT2_TPR_VesselSummary >> layer3_sp_BT_CT2_ports_tbl_tpr_vesselsummary