from datetime import timedelta,datetime
from airflow import models
from airflow import DAG
from airflow.contrib.operators.bigquery_operator import BigQueryOperator
from airflow.operators.dagrun_operator import TriggerDagRunOperator
from google.cloud import bigquery

BQ_PROJECT = "apsez-svc-dev-datalake"
BQ_stored_proc_dataset = "STORED_PROCEDURE"


DEFAULT_ARGS = {  
    'depends_on_past': False,
    'start_date': datetime(2022,5,11,6,22),
    'catchup': False,
    'email_on_failure': False,
    'email_on_retry': False,
    'email': ['kpmg0009@adani.com','kpmg0008@adani.com','kpmg0010@adani.com'],
    'retries': 3,
    'retry_delay': timedelta(minutes=1),
}


dag = DAG(
    'layer1_CT2_DAG_ITV_Movement_Tracker_Analytics',
    schedule_interval = '*/3 * * * *',
    default_args = DEFAULT_ARGS
)

layer3_sp_BT_CT2_ports_tbl_ctrmovement_tat = BigQueryOperator(
     task_id='layer3_sp_BT_CT2_ports_tbl_ctrmovement_tat',
     sql='''CALL `{0}.{1}.{2}`()'''.format(BQ_PROJECT, BQ_stored_proc_dataset,"layer3_sp_BT_CT2_ports_tbl_ctrmovement_tat"),
     allow_large_results=True, 
     bigquery_conn_id= 'bigquery_default',
     create_disposition='CREATE_IF_NEEDED',
     use_legacy_sql=False, 
     email_on_failure = True,
     dag=dag
)