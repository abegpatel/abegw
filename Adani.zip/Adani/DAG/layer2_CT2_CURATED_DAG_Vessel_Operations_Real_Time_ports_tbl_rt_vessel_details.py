from datetime import timedelta,datetime
from airflow import models
from airflow import DAG
from airflow.contrib.operators.bigquery_operator import BigQueryOperator
from google.cloud import bigquery

BQ_PROJECT = "apsez-svc-dev-datalake"
BQ_stored_proc_dataset = "STORED_PROCEDURE"


DEFAULT_ARGS = {  
    'depends_on_past': False,
    'start_date': datetime.today() - timedelta(1),
    'catchup': False,
    'email_on_failure': False,
    'email_on_retry': False,
    'email': ['kpmg0009@adani.com','kpmg0008@adani.com','kpmg0010@adani.com'],
    'retries': 3,
    'retry_delay': timedelta(minutes=1),
}


dag = DAG(
    'layer2_CT2_CURATED_DAG_Vessel_Operations_Real_Time_ports_tbl_rt_vessel_details',
    schedule_interval = None,
    default_args = DEFAULT_ARGS
)

layer3_CT2_ports_tbl_ctrmovement = BigQueryOperator(
     task_id='layer3_CT2_ports_tbl_ctrmovement',
     # write_disposition='WRITE_TRUNCATE',
     sql='''CALL `{0}.{1}.{2}`()'''.format(BQ_PROJECT, BQ_stored_proc_dataset,"layer3_sp_CT2_ports_tbl_ctrmovement"),
     allow_large_results=True, 
     bigquery_conn_id= 'bigquery_default',
     create_disposition='CREATE_IF_NEEDED',
     use_legacy_sql=False, 
     email_on_failure = True,
     dag=dag
)

layer3_CT2_ports_tbl_rt_vessel_details = BigQueryOperator(
     task_id='layer3_CT2_ports_tbl_rt_vessel_details',
     # write_disposition='WRITE_TRUNCATE',
     sql='''CALL `{0}.{1}.{2}`()'''.format(BQ_PROJECT, BQ_stored_proc_dataset,"layer3_sp_CT2_ports_tbl_rt_vessel_details"),
     allow_large_results=True, 
     bigquery_conn_id= 'bigquery_default',
     create_disposition='CREATE_IF_NEEDED',
     use_legacy_sql=False, 
     email_on_failure = True,
     dag=dag
)

layer3_CT2_ports_tbl_ctrmovement_qc_working_time = BigQueryOperator(
     task_id='layer3_CT2_ports_tbl_ctrmovement_qc_working_time',
     # write_disposition='WRITE_TRUNCATE',
     sql='''CALL `{0}.{1}.{2}`()'''.format(BQ_PROJECT, BQ_stored_proc_dataset,"layer3_sp_CT2_ports_tbl_ctrmovement_qc_working_time"),
     allow_large_results=True, 
     bigquery_conn_id= 'bigquery_default',
     create_disposition='CREATE_IF_NEEDED',
     use_legacy_sql=False, 
     email_on_failure = True,
     dag=dag
)

layer3_CT2_ports_tbl_ctrmovement >> [layer3_CT2_ports_tbl_rt_vessel_details,layer3_CT2_ports_tbl_ctrmovement_qc_working_time]