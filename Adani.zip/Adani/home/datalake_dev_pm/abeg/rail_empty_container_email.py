from datetime import date, datetime, timedelta
from dateutil.relativedelta import *
import pandas as pd
import traceback
import time
from google.cloud import storage
from google.cloud import bigquery
import google.cloud.bigquery.dbapi
import os
from email.mime.text import MIMEText
from email.mime.application import MIMEApplication
from email.mime.multipart import MIMEMultipart
import smtplib
import sys
import pytz
from airflow import models
from airflow import DAG
from airflow.operators.python_operator import PythonOperator
from airflow.models import Variable
from airflow.utils.dates import days_ago
from styleframe import StyleFrame, Styler, utils
import xlsxwriter
import openpyxl
from openpyxl.styles import Alignment, PatternFill

storage_client = storage.Client()
file_path = "/home/airflow/gcs/dags/scripts/"
sql_dir="/home/airflow/gcs/dags/scripts/SQL"

DEFAULT_ARGS = {
    'depends_on_past': False,
    'start_date': days_ago(1),
    'catchup': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=1)
}

dag = DAG(
    'rail_empty_container_email',
    schedule_interval = '15,45 3,14 * * *',
    tags = ["logistics","rail","line","BA:Chintamani","BA:Vikash","DE:Kunal","mty","email"],
    default_args=DEFAULT_ARGS,
    max_active_runs=1
)

def devMain(extraction_query,target_table=''):
    extraction_query = extraction_query
        
    try:
        client = bigquery.Client()
        query_job = client.query(extraction_query)
        df_data = query_job.result().to_dataframe()
        #print("df_data = ",df_data.sample())
        client.close()
        
    except Exception as E:
        print('ERROR:Query Error-',E)
        sys.exit(1)
        
    if target_table == 'Rail_Empty_Cont_Data':
        df_data['In Date'] = pd.to_datetime(df_data['In Date']).dt.tz_localize(None)

    print("Read Successful, file has {0} rows".format(df_data.shape[0]))
    if df_data.shape[0] == 0 :
        raise Exception('QUERY IS EMPTY')
        sys.exit(1)

    # Pre-process CSV File
    if 'Unnamed: 0' in  df_data.columns:
        df_data = df_data.drop(columns = ['Unnamed: 0'])
        print("Unnamed columns removed")
    print("Date formats verified")
    print("~"*50,df_data.shape)
    return df_data

def write_to_cloud(file_name,flag):
    now = datetime.now()
    year = now.year
    month = now.strftime('%b').upper()
    day = datetime.now().date()
    gcs_file = f"Rail_Orphan_Empty_Dispatched/{year}/{month}/{day}/{flag}_{str(now)}.csv"
    client = storage.Client('apsez-svc-prod-datalake')
    bucket = client.get_bucket('sftp_apsez_archival_bucket_prod')
    blob = bucket.blob(gcs_file)
    blob.upload_from_filename(file_name)
    print(file_name," uploaded to GCS as ",gcs_file)

def mailer(df,shipping_line,file_name,vendor_mail_to=[],vendor_mail_CC=[],vendor_mail_BCC=[]):
  #vendor_mail_to = ['Laxmikant.limbani@adani.com','Sanjay.Gangajadiya@adani.com','Hiren.Modha@adani.com','Amitosh.kumar@adani.com','icd.ct@adani.com']
  #vendor_mail_CC = ['siddheshwari.sawant@adani.com','singh.vikash@adani.com','chintamani.taral@adani.com','kunal.panjwani@adani.com']
  vendor_mail_BCC = ['amitosh.kumar@adani.com','siddheshwari.sawant@adani.com','kunal.panjwani@adani.com','singh.vikash@adani.com','chintamani.taral@adani.com','icd.ct@adani.com']
  #vendor_mail_to = ['singh.vikash@adani.com','chintamani.taral@adani.com','kunal.panjwani@adani.com']
  msg_body = ""
  msg="""{0}""".format(df.to_html(index=False)).replace("<th>","<th style='background-color:#64D1D1'>").replace('<table border="1" class="dataframe">',
    "<table style='background-color:#ECECEB;border-collapse: collapse;'border='3'>").replace('<tr style="text-align: right;">',
    "<tr style='text-align: center;'>").replace("<td>","<td style='text-align: center;'>")
  msg_body = msg_body + msg
  msg = MIMEMultipart()
  todays_date_dmY = datetime.now(pytz.timezone('Asia/Kolkata')).date().strftime('%d.%m.%Y')
  msg['Subject'] = f"By Rail empty units arrived for CFS at SPRH of {shipping_line} on {todays_date_dmY}" ###########
  msg['From'] = 'noreply@adani.com'
  msg['To'] = ','.join(vendor_mail_to)
  msg['Cc'] = ','.join(vendor_mail_CC)
  msg['Bcc'] = ','.join(vendor_mail_BCC)
  html = f"""<h4 style="font-weight:normal; color: #000000" align='left'>Dear {shipping_line} & CFS,</h4>
  <h4 style="font-weight:normal; color: #000000" align='left'>Please find the attached file for empty containers arrived by rail and lying at SPRH. <b>Please provide the Custom Permission for below containers</b>.</h4>
  """ + msg_body + """
  <h4 style="font-weight:normal; color: #000000;" align='left'>Thanks and Regards,</h4>
  <h4 style="font-weight:normal; color: #000000;" align='left'>APSEZ Analytics Team</h4>
  <h5 style="font-weight:normal; color: #000000" align='left'><i>**This is auto-generated email. Please do not reply.</i></h5>"""
    
  part1 = MIMEText(html, 'html')
  msg.attach(part1)
  attachment_name = f"{shipping_line}_CFS MTY units arrived at SPRH {todays_date_dmY}.xlsx"
  att_part = MIMEApplication(open(file_name,'rb').read())
  att_part.add_header('Content-Disposition','attachment', filename=attachment_name) 
  msg.attach(att_part)
  
  email_list_final = vendor_mail_to + vendor_mail_CC + vendor_mail_BCC
  
  #logging.info(msg)
  smtpObj = smtplib.SMTP('smtp.adani.com',25)
  
  smtpObj.sendmail(msg['From'], email_list_final, msg.as_string())
  print("*************Email Sent******")
  
  smtpObj.quit()
  
def rail_mty_data(sql_file_name):
  #path = 'rail_line_empty_cont.txt'
  path = f'{sql_file_name}.txt'
  with open(os.path.join(sql_dir,path)) as f:
    extraction_query = f.read().strip()
    f.close()
    
  df_rail_empty_cont_dump = devMain(extraction_query,'Rail_Empty_Cont_Data')
  print("***************Rail Empty Containers************")
  print(df_rail_empty_cont_dump.sample(2))
  
  file_name_rail_mty = file_path+"rail_mty_dump.csv"
  df_rail_empty_cont_dump.to_csv(file_name_rail_mty,index=False)
  write_to_cloud(file_name_rail_mty,'empty_cont_dump')
  
  
  unique_rail_cus = df_rail_empty_cont_dump['Shipping Line'].unique()
  rail_line_mail_ids_master = devMain("""select name,`to` from logistics_master.layer2_rail_line_mail_ids""")
  rail_cfs_mail_ids_master = devMain("""select name,cc from logistics_master.layer2_rail_cfs_mail_ids""")

  rail_line_mail_ids_master['to_list'] = rail_line_mail_ids_master['to'].str.split(";")
  rail_cfs_mail_ids_master['cc_list'] = rail_cfs_mail_ids_master['cc'].str.split(";")
  
  for i in unique_rail_cus:
    #if i in tuple(rail_line_mail_ids_master['name']):
    if i in tuple(df_rail_empty_cont_dump['Shipping Line']):
      print("sending mail for",i)
      vendor_df = df_rail_empty_cont_dump[df_rail_empty_cont_dump['Shipping Line']==i]
      unique_rail_cfs = vendor_df['CFS'].unique()
      vendor_df = vendor_df.sort_values(by=['In Date'],ascending=[True])
      vendor_df.insert(0,'Sr No',range(1,len(vendor_df)+1))
      vendor_df['In Date'] = vendor_df['In Date'].dt.strftime('%d-%m-%Y %H:%M')
      style_writer = StyleFrame.ExcelWriter(file_path+i+".xlsx")
      default_style = Styler(font_size=10)
      vendor_sf = StyleFrame(vendor_df,styler_obj=default_style)
      vendor_sf.set_column_width_dict(col_width_dict={str(col):max(vendor_sf[col].astype(str).map(len).max()+7, len(col)+7) for col in vendor_sf.columns})
      vendor_sf.apply_headers_style(styler_obj=Styler(bold=False,bg_color=utils.colors.grey,border_type=utils.borders.medium,font_size=10))
      vendor_sf.to_excel(excel_writer = style_writer,index=False)
      style_writer.save()
      print("vendor DF:",vendor_sf)
      try:
        to_mty = ["'"+email+"'" for email in rail_line_mail_ids_master.loc[rail_line_mail_ids_master["name"] == i,"to_list"].iloc[0]]
      except:
        print(i,f"is not present in the Matser Database:skipping - {i}")
        continue
      for j in unique_rail_cfs:
        if j in tuple(rail_cfs_mail_ids_master['name']):      
          cc_mty = ["'"+email+"'" for email in rail_cfs_mail_ids_master.loc[rail_cfs_mail_ids_master["name"] == j,"cc_list"].iloc[0]]
      to_mty = [x.replace("'","") for x in to_mty]
      cc_mty = [x.replace("'","") for x in cc_mty]
      try:  
        mailer(df = vendor_df,shipping_line = i, file_name = file_path+i+".xlsx",vendor_mail_to=to_mty,vendor_mail_CC=cc_mty)
        print("MAILER CALLED")
        
      except:
        print("MAILER FAILED AND SKIPPED FOR Empty Cont : ",i,"*"*20)

def send_mail(**context):
  if context['ts_nodash'].split('T')[1][:4]=='1415':
     print("sending at 8:15 pm")
     rail_mty_data('rail_line_empty_cont_evening')
  elif context['ts_nodash'].split('T')[1][:4]=='1445':
     print("sending at 8:45 am")
     rail_mty_data('rail_line_empty_cont_morning')
  else:
     print("skipping")
  

line_mty_mailer = PythonOperator(
    task_id='line_mty_mailer',
    python_callable= send_mail,
    dag=dag,
)




  
    

  

