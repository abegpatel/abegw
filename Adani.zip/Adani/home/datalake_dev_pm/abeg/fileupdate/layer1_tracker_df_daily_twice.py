from datetime import timedelta
from airflow import DAG
from airflow.operators.bash_operator import BashOperator

from airflow.models import Variable
from airflow.utils.dates import days_ago

"""
This dag is part of Tracker NICD ingestion and 
loads data from Tracker (10.112.88.71:1433) to BQ.
The schema file is in the location gs://asia-south1-apsez-prod-auto-3c810704-bucket/dags/dataflow_support_scripts/.
The dataflow runner python file in the composer bucket (dags folder).
Please use 'loadstrategy' option to load history or incremental load for given Ndays of look back period.
loadstrategy = "FullLoad" for complete history dump. "N" for incremental run
"""


email_list = Variable.get("failure_email_list",deserialize_json = True)

table_list = Variable.get("tracker_nicd_table_list_daily_twice").replace(" ",'').replace("'",'').split(",")
schema_file = Variable.get("tracker_schema")


DEFAULT_ARGS = {
    'depends_on_past': False,
    'start_date':days_ago(1),
    'catchup': False,
    'email_on_failure': True,
    'email': email_list["logistics"],
    'retries': 0,
    'retry_delay': timedelta(minutes=1),
    'max_active_runs': 1
}

dag = DAG(
    'layer1_tracker_df_daily_twice',
    schedule_interval='0 */2 * * *',
    default_args=DEFAULT_ARGS
)



for source_table in table_list:
    source_table=source_table
    job=source_table.lower().replace("_","-")
    machine="n1-standard-16"
    chunk=20000
    
    tracker_nicd_dataflow_task=BashOperator(
            task_id=source_table.lower()+"_dataflow_job",
            bash_command='''python3 /home/airflow/gcs/dags/dataflow_support_scripts/tracker_nicd_tables_dataflow.py --runner DataflowRunner --project apsez-svc-prod-datalake --region asia-south1 --temp_location gs://tmp_apsez_dataflow/tmp/ --network apsez-host-vpc --subnetwork https://www.googleapis.com/compute/v1/projects/apsez-host-prj/regions/asia-south1/subnetworks/apsez-datalake-prod-subnet01 --no_use_public_ips --max_num_workers 5 --job_name {0} --worker_machine_type {1}  --setup_file /home/airflow/gcs/dags/scripts/setup.py  --schemaFile {2} --chunk {3} --table {4}'''.format(job,machine,schema_file,chunk,source_table),
            dag=dag)
        
tracker_nicd_dataflow_task
