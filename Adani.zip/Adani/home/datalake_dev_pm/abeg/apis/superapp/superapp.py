from google.cloud import bigquery
import pandas as pd
from pandas_gbq import read_gbq
import json
import requests
from datetime import date,datetime,time
import numpy as np
import os

# URL Args
uri = "https://superapp.ezrdu.com"
url = f"{uri}/api/scheduleinfo/ibob"


# Utility
def get_token():
  key = 'b3fa7386b9a51cc7c10aa268e0d892fd763232327632323276323232769192583a011d842f039168e9c2c40e90'
  url = f"{uri}/api/auth/{key}"
  payload = {}
  headers = {}
  try:
    response = requests.request("GET", url, headers=headers, data=payload)
    if (response.status_code == 200):
      token = response.text
  except Exception as E:
    print('ERROR:-',E)
    print(response.status_code,response.text)

token = get_token()
headers = {
  'Accept': 'application/json',
  'Authorization': f'Bearer {token}'
}

# Project Args
project_id = 'apsez-svc-prod-datalake'


# Query 
extraction_query = """SELECT * FROM
(
SELECT
TRAIN_VISIT_NO,
OB_TRAIN_NO,
WAGON_NO,
CONT_NO,
POSITION,
CONT_SIZE,
CONT_STATUS,
TEUS, 
'Non_EF' AS WAGON_STATUS,
'INBOUND' AS IB_OB
FROM `apsez-svc-prod-datalake.logistics_semantic.layer4_rt_rail_report_mv`
 
UNION ALL
 
SELECT
    a.TRAIN_VISIT_NO,
    OB_TRAIN_NO,
    c.wagon_no,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL, 
    'EF' AS WAGON_STATUS,
    'INBOUND' AS IB_OB
  FROM
    gg_replica.layer1_cfsmag_et_empty_wagon_mapping a
    LEFT JOIN `apsez-svc-prod-datalake.logistics_semantic.layer4_rt_all_rail_performance_mv` b on 
    a.train_visit_no = b.train_visit_no 
    LEFT JOIN (
  SELECT
    DISTINCT(WAGON_NO) WAGON_NO,
    WAGON_ID
  FROM
    `apsez-svc-prod-datalake.gg_replica.layer1_cfsmag_et_wagon_master` ) c  ON c.wagon_id = a.wagon_id    
 WHERE wagon_no IS NOT NULL
)"""

# Read from Bigquery
def read_bq():
  try:
    df = read_gbq(extraction_query,project_id = project_id)
  except Exception as E:
    print('ERROR:-',E)
  return df

df = read_bq()



# Data Cleaning
df[['TRAIN_VISIT_NO','CONT_SIZE']]=df[['TRAIN_VISIT_NO','CONT_SIZE']].fillna(0)
df[['TRAIN_VISIT_NO','CONT_SIZE']]=df[['TRAIN_VISIT_NO','CONT_SIZE']].astype(int)

df = df.applymap(lambda x:str(None) if pd.isna(x) else x)
print(df.head())
result_dict = df.to_dict('records')
result_json = json.dumps(result_dict)


# Post data To Endpoint
try:
    response = requests.request("POST", url, headers=headers, data=result_json)
    if(response.status_code==200):
        print(f'inbound_wagonjson is successfully posted')
        print(response.status_code)
except Exception as E:
    print('ERROR:-',E)
    print(responsestatus_code)
    print(response.text)

"""# Delete files Workspace
for i in range(1,chunk+1):
  if os.path.exists(f'inbound_wagon{i}.json'):
    os.remove(f'inbound_wagon{i}.json')
print("Workspace Cleaned Successfully")"""











