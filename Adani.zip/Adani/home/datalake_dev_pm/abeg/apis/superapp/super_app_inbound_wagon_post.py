from google.cloud import bigquery
import pandas as pd
from pandas_gbq import read_gbq
import json
import requests
from datetime import date,datetime,time
import numpy as np
import os

# URL Args
uri = "https://superapp.ezrdu.com"
url = f"{uri}/api/scheduleinfo/ibob"


# Utility
def get_token():
  key = 'b3fa7386b9a51cc7c10aa268e0d892fd763232327632323276323232769192583a011d842f039168e9c2c40e90'
  url = f"{uri}/api/auth/{key}"
  payload = {}
  headers = {}
  try:
    response = requests.request("GET", url, headers=headers, data=payload)
    if (response.status_code == 200):
      token = response.text
      return token
  except Exception as E:
    print('ERROR:-',E)
    print(response.status_code,response.text)

token = get_token()
headers = {
  'Accept': 'application/json',
  'Authorization': f'Bearer {token}'
}

# Project Args
project_id = 'apsez-svc-prod-datalake'
chunk = 1 # datasize kb//3500 kb

def get_chunks(data):
    data =  json.loads(data)
    total_items = len(data)
    cs = total_items//chunk
    for i in range(chunk):
      globals()[f'p{i+1}']=data[i*cs:(i+1)*cs]
    print(p15)
    for i in range(1,int(chunk)+1):
      with open(f'tracking/tracking{i}.json','w') as f:
        json.dump(globals()[f'p{i}'],f)

# Query 
extraction_query = """SELECT * FROM
(
SELECT
TRAIN_VISIT_NO,
OB_TRAIN_NO,
WAGON_NO,
CONT_NO,
POSITION,
CONT_SIZE,
CONT_STATUS,
TEUS, 
'Non_EF' AS WAGON_STATUS,
'INBOUND' AS IB_OB
FROM `apsez-svc-prod-datalake.logistics_semantic.layer4_rt_rail_report_mv`
 
UNION ALL
 
SELECT
    a.TRAIN_VISIT_NO,
    OB_TRAIN_NO,
    c.wagon_no,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL, 
    'EF' AS WAGON_STATUS,
    'INBOUND' AS IB_OB
  FROM
    gg_replica.layer1_cfsmag_et_empty_wagon_mapping a
    LEFT JOIN `apsez-svc-prod-datalake.logistics_semantic.layer4_rt_all_rail_performance_mv` b on 
    a.train_visit_no = b.train_visit_no 
    LEFT JOIN (
  SELECT
    DISTINCT(WAGON_NO) WAGON_NO,
    WAGON_ID
  FROM
    `apsez-svc-prod-datalake.gg_replica.layer1_cfsmag_et_wagon_master` ) c  ON c.wagon_id = a.wagon_id    
 WHERE wagon_no IS NOT NULL
)"""

# Read from Bigquery
def read_bq():
  try:
    df = read_gbq(extraction_query,project_id = project_id)
  except Exception as E:
    print('ERROR:-',E)
  return df

df = read_bq()



# Data Cleaning
df[['TRAIN_VISIT_NO','CONT_SIZE']]=df[['TRAIN_VISIT_NO','CONT_SIZE']].fillna(0)
df[['TRAIN_VISIT_NO','CONT_SIZE']]=df[['TRAIN_VISIT_NO','CONT_SIZE']].astype(int)

df = df.applymap(lambda x:str(None) if pd.isna(x) else x)
print(df.head())
result_dict = df.to_dict('records')
result_json = json.dumps(result_dict)
get_chunks(result_json)

# Post data To Endpoint
for i in range(1,chunk+1):
  with open(f'iboundwagon{i}.json','rb') as f:
    try:
      globals()[f"response{i}"] = requests.request("POST", url, headers=headers, files={'file':f})
      print(f'inbound_wagon{i}.json is successfully posted')
      print(globals()[f"response{i}"].status_code)
      except Exception as msg:
        print('ERROR:-',E)
        mailer(E)
        print(globals()[f"response{i}"].status_code)
        print(globals()[f"response{i}"].text)

"""# Delete files Workspace
for i in range(1,chunk+1):
  if os.path.exists(f'inbound_wagon{i}.json'):
    os.remove(f'inbound_wagon{i}.json')
print("Workspace Cleaned Successfully")"""











