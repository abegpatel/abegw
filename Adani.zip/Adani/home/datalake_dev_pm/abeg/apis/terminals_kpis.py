from google.cloud import bigquery
import pandas as pd
from pandas_gbq import read_gbq
import json
import requests
from datetime import date,datetime,time
import numpy as np
import os
import psycopg2
import sqlalchemy as sql
import logging

# URL Args
uri = "https://superapp.ezrdu.com"
url = f"{uri}/api/terminals/kpis"

# Utility
def get_token():
  key = 'b3fa7386b9a51cc7c10aa268e0d892fd763232327632323276323232769192583a011d842f039168e9c2c40e90'
  url = f"{uri}/api/auth/{key}"
  payload = {}
  headers = {}
  try:
    response = requests.request("GET", url, headers=headers, data=payload)
    if (response.status_code == 200):
      token = response.text
      return token
  except Exception as E:
    print('ERROR:-',E)
    print(response.status_code,response.text)

token = get_token()
headers = {
  'Content-Type': 'application/json',
  'Authorization': f'Bearer {token}'
}

cloud_sql_pg_prod="postgresql+psycopg2://ANALYTICS.USER1:ANALYTICSUSER1@10.81.164.61:5432/datalake_postgres_rt?sslmode=require"
def PG_CONN(task='',obj='',query='',tgt_connection_string='',table='',schema='logistics_cleansed',how=''):

    engine = sql.create_engine(tgt_connection_string)
    logging.info(f"Connection with CLOUD SQL POSTGRESQL Database established successfully!!\n")
    
    with engine.begin() as conn:
        if task == 'call':
            call_query = f"""call {obj}();"""
            call = conn.execute(call_query)
        # elif task == 'refresh':
            # refresh_query = f"""REFRESH MATERIALIZED VIEW {obj};"""
            # refresh = conn.execute(refresh_query)
        elif task=='dataframe':
            df = pd.DataFrame()
            for chunk in pd.read_sql(sql=query,con=conn,chunksize=50000):
                df = pd.concat([df,chunk])
            return df
        elif task=='query':
            conn.execute(query)
        else:
            obj.to_sql(name=table,schema=schema,con=conn,if_exists=how)
            
    conn.close()
    engine.dispose()
    

pg_query = """SELECT 
	A.STTNFROM AS "Terminal",
	COUNT(DISTINCT(A.RAKE_NAME)) AS "Total Dispatched", 
	( SUM(COALESCE(B.DISCHARGE_PLAN_TEUS, 0)) + SUM(COALESCE(B.LOAD_PLAN_TEUS, 0)) ) AS "Total Received"
FROM logistics_semantic.layer4_rake_running_status_mv A
LEFT JOIN logistics_semantic.layer4_cfsmag_latest_rake_status_mv B
ON A.IB_TRAIN_NO = B.IB_TRAIN_NO
WHERE A.BU IN ('ALL','ALSPL') 
	AND UPPER(A.STATUS) IN ('UNDER OPERATION','AWAITING DEPARTURE')
	AND STTNFROM IN ('AFAS', 'ALGV', 'ALIK', 'ICAK', 'LONI', 'MAAM', 'PALB', 'PATP', 'PDLL')
GROUP BY A.STTNFROM
ORDER BY 1"""
df_pg = PG_CONN(task='dataframe',query=pg_query,tgt_connection_string=cloud_sql_pg_prod)
print(df_pg.columns)


# Project Args
project_id = 'apsez-svc-prod-datalake'
bq_query = """WITH rail_report AS (
  SELECT *,
    AVG(OPERATION_TAT) OVER (PARTITION BY FISCAL_YEAR, VISIT_PORT) AS YTD_TAT,
    AVG(OPERATION_TAT) OVER (PARTITION BY MONTH_YR, VISIT_PORT) AS MTD_TAT
  FROM (
    SELECT
      COALESCE(b.FOIS, a.VISIT_PORT) AS VISIT_PORT,
      IB_TRAIN_NO,
      REMOVAL_DATE,
      DEPARTURE_SOURCE,
      IF (
        EXTRACT(MONTH FROM REMOVAL_DATE) > 3,
        CONCAT('FY', CAST(EXTRACT(YEAR FROM REMOVAL_DATE) AS STRING), '-', CAST((EXTRACT(YEAR FROM REMOVAL_DATE) + 1) AS STRING)),
        CONCAT('FY', CAST((EXTRACT(YEAR FROM REMOVAL_DATE) - 1) AS STRING), '-', CAST(EXTRACT(YEAR FROM REMOVAL_DATE) AS STRING))
      ) AS FISCAL_YEAR,
      FORMAT_TIMESTAMP('%b-%Y', REMOVAL_DATE) AS MONTH_YR,
      DISCHARGE_PLAN_TEUS,
      LOAD_PLAN_TEUS,
      ROUND(TIMESTAMP_DIFF(REMOVAL_DATE, PLACEMENT_DATE, SECOND)/3600, 2) AS OPERATION_TAT,
      CASE
        WHEN VISIT_PORT IN ( 'FL', 'SBT', 'CP', 'TNPM', 'MB', 'SGWF', 'TKD', 'UMB', 'KOTA', 'SMP', 'HAPA', 'LLH', 'NHYD', 'CEBD', 'SREW', 'BFTL' ) THEN 'MAINTENANCE'
        WHEN OB_DISCHARGE_PORT IN ( 'FL', 'SBT', 'CP', 'TNPM', 'MB', 'SGWF', 'TKD', 'UMB', 'KOTA', 'SMP', 'HAPA', 'LLH', 'NHYD', 'CEBD', 'SREW', 'BFTL' ) THEN 'MAINTENANCE'
        WHEN UPPER(RR_PAID_BY) = 'INDIAN RAILWAY' THEN 'MAINTENANCE'
        ELSE 'RUN'
      END AS MAINTENANCE
    FROM
      `logistics_semantic.layer4_rt_all_rail_performance_mv` a
    LEFT JOIN `apsez-svc-prod-datalake.logistics_cleansed.layer2_terminal_master` b
      ON a.VISIT_PORT = COALESCE(b.terminal_code, b.fois, b.fios_terminal_id)
  )
  WHERE MAINTENANCE = 'RUN'
    AND VISIT_PORT IN ('AFAS', 'ALGV', 'ALIK', 'ICAK', 'LONI', 'MAAM', 'PALB', 'PATP', 'PDLL')
    AND DATE(REMOVAL_DATE) >= '2024-04-01'
  QUALIFY ROW_NUMBER() OVER (PARTITION BY IB_TRAIN_NO) = 1
),
 
INCOMING AS (
  SELECT
    STTNTO AS PORT,
    COUNT(OB_TRAIN_NO) AS INCOMING_RAKES,
    SUM(LOAD_PLAN_TEUS) AS `Incoming Teus`
  FROM
  (
    SELECT
      DISTINCT(RS.OB_TRAIN_NO) OB_TRAIN_NO,
      RS.STTNTO,
      ARP.LOAD_PLAN_TEUS
    FROM `logistics_cleansed.layer2_bt_rake_running_status_hourly` RS
    LEFT JOIN `logistics_cleansed.layer2_cfsmag_et_rt_all_rail_performance` ARP
      ON ARP.OB_TRAIN_NO = RS.IB_TRAIN_NO
    WHERE RS.BU IN ('ALL','ALSPL')
      AND RS.STTNTO IN ('AFAS', 'ALGV', 'ALIK', 'ICAK', 'LONI', 'MAAM', 'PALB', 'PATP', 'PDLL')  
  )
  GROUP BY STTNTO
),
 
PLANNED AS (
  SELECT
    COALESCE(b.FOIS, a.VISIT_PORT) AS PORT,
    SUM(LOAD_PLAN_TEUS) AS PLANNED_DISPATCH
  FROM `logistics_semantic.layer4_rt_all_rail_performance_mv` a
  LEFT JOIN `apsez-svc-prod-datalake.logistics_cleansed.layer2_terminal_master` b
    ON a.VISIT_PORT = COALESCE(b.terminal_code, b.fois, b.fios_terminal_id)
  WHERE VISIT_PORT IN ('AFAS', 'ALGV', 'ALIK', 'ICAK', 'LONI', 'MAAM', 'PALB', 'PATP', 'PDLL')
    AND DEPARTURE_SOURCE IS NULL
    AND DATE(ARRIVAL_SOURCE) >= DATE_SUB(CURRENT_DATE(), INTERVAL 7 DAY)
    AND DATE(ARRIVAL_SOURCE) <= CURRENT_DATE()
  GROUP BY COALESCE(b.FOIS, a.VISIT_PORT)
),
 
TAT AS (
  SELECT
    VISIT_PORT,
    MTD_TAT,
    YTD_TAT
  FROM
  (
    SELECT
      VISIT_PORT,
      FISCAL_YEAR,
      MONTH_YR,
      ROUND(AVG(OPERATION_TAT) OVER (PARTITION BY FISCAL_YEAR, VISIT_PORT), 2) AS YTD_TAT,
      ROUND(AVG(OPERATION_TAT) OVER (PARTITION BY MONTH_YR, VISIT_PORT), 2) AS MTD_TAT
    FROM RAIL_REPORT
  )
  WHERE MONTH_YR = FORMAT_TIMESTAMP('%b-%Y', CURRENT_DATE())
  QUALIFY ROW_NUMBER() OVER (PARTITION BY VISIT_PORT) = 1
),
 
ICD AS (
  SELECT 'AFAS' AS TERMINAL
  UNION ALL
  SELECT 'ALGV' AS TERMINAL
  UNION ALL
  SELECT 'ALIK' AS TERMINAL
  UNION ALL
  SELECT 'ICAK' AS TERMINAL
  UNION ALL
  SELECT 'LONI' AS TERMINAL
  UNION ALL
  SELECT 'MAAM' AS TERMINAL
  UNION ALL
  SELECT 'PALB' AS TERMINAL
  UNION ALL
  SELECT 'PATP' AS TERMINAL
  UNION ALL
  SELECT 'PDLL' AS TERMINAL
)
 
SELECT *
FROM (
  SELECT
    ICD.TERMINAL AS `Terminal`,
    RR.RAKES AS `Total Rakes Handled`,
    RR.LOADED + RR.UNLOADED AS `Teus Handled`,
    INCOMING.INCOMING_RAKES AS `Incoming Rakes`,
    INCOMING.`Incoming Teus` AS `Incoming Teus`,
    PLANNED.PLANNED_DISPATCH AS `Planned Dispatch`,
    RR.AVG_TAT AS `Avg Operation TAT FTD`,
    TAT.MTD_TAT AS `Avg Operation TAT MTD`,
    TAT.YTD_TAT AS `Avg Operation TAT YTD`
  FROM
    ICD
  LEFT JOIN
  (
    SELECT
      VISIT_PORT,
      COUNT(DISTINCT(IB_TRAIN_NO)) OVER (PARTITION BY VISIT_PORT) AS RAKES,
      SUM(DISCHARGE_PLAN_TEUS) OVER (PARTITION BY VISIT_PORT) AS UNLOADED,
      SUM(LOAD_PLAN_TEUS) OVER (PARTITION BY VISIT_PORT) AS LOADED,
      ROUND(AVG(OPERATION_TAT) OVER (PARTITION BY VISIT_PORT), 2) AS AVG_TAT
    FROM RAIL_REPORT
    WHERE DATE(REMOVAL_DATE) = CURRENT_DATE()
      AND VISIT_PORT IN ('AFAS', 'ALGV', 'ALIK', 'ICAK', 'LONI', 'MAAM', 'PALB', 'PATP', 'PDLL')
      AND DATE(DEPARTURE_SOURCE) IS NOT NULL
    QUALIFY ROW_NUMBER() OVER (PARTITION BY VISIT_PORT ORDER BY REMOVAL_DATE DESC) = 1
  ) RR
  ON ICD.TERMINAL = RR.VISIT_PORT
  LEFT JOIN INCOMING ON ICD.TERMINAL = INCOMING.PORT
  LEFT JOIN PLANNED ON ICD.TERMINAL = PLANNED.PORT
  LEFT JOIN TAT ON ICD.TERMINAL = TAT.VISIT_PORT
) X
ORDER BY 1"""

# Read from Bigquery
df_bq = read_gbq(bq_query,project_id = project_id)
final_df = df_pg.merge(df_bq,how = "left",left_on='Terminal',right_on='Terminal')

for i in final_df.columns:
  final_df.rename(columns={i:i.lower().replace(" ","_")},inplace=True)
final_df = final_df[['terminal','total_rakes_handled',
        'incoming_rakes','teus_handled','total_dispatched','total_received',
        'incoming_teus','planned_dispatch',
       'avg_operation_tat_ftd', 'avg_operation_tat_mtd',
       'avg_operation_tat_ytd']]
final_df.rename(columns={'avg_operation_tat_mtd':'operation_tat_mtd','avg_operation_tat_ytd':'operation_tat_ytd'},inplace=True)
final_df = final_df[['terminal','total_rakes_handled',
        'incoming_rakes','teus_handled','total_dispatched','total_received',
        'incoming_teus','planned_dispatch',
       'avg_operation_tat_ftd', 'operation_tat_mtd',
       'operation_tat_ytd']]= final_df[['terminal','total_rakes_handled',
        'incoming_rakes','teus_handled','total_dispatched','total_received',
        'incoming_teus','planned_dispatch',
       'avg_operation_tat_ftd', 'operation_tat_mtd',
       'operation_tat_ytd']].fillna(0)
final_df[['teus_handled','total_received','incoming_teus','planned_dispatch','avg_operation_tat_ftd']]=final_df[['teus_handled','total_received','incoming_teus','planned_dispatch','avg_operation_tat_ftd']].astype(int)
result = final_df.to_dict('records')
result = json.dumps(result)
result = json.loads(result)
m_dict = {}
m_dict['kpis']=result
result = json.dumps(m_dict)
print(result)

# Post data To Endpoint

response = requests.request("POST", url, headers=headers, data=result)
print(response.text)
print(response.status_code)


