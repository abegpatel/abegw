from google.cloud import bigquery
import pandas as pd
from pandas_gbq import read_gbq
import json
import requests
from datetime import date,datetime,timedelta
from airflow import DAG
from airflow.operators.python_operator import PythonOperator

DEFAULT_ARGS = {
    'depends_on_past': False,
    # 'start_date': datetime.combine(date.today() - timedelta(days=1),time(hour=3, minute=45)),
    'start_date': datetime.today()-timedelta(minutes=60),
    'catchup': False,
    'retries': 4,
    'retry_delay': timedelta(minutes=1),
    'max_active_runs':1
}

dag = DAG(
    'tracking_post_api',
    # schedule_interval = '@once',
    schedule_interval = '*/30 * * * *',
    tags = ["logistics","api","BA:Vikash","DE:Abeg","tracking"],
    max_active_runs=1,
    default_args=DEFAULT_ARGS
)

# Args
project_id = 'apsez-svc-prod-datalake'
uri = "https://veracityapi.riddhigroup.in/"
url = f"{uri}api/tracking-api-json"

def get_token():
  url = f"{uri}api/api-login"
  payload = {'user_name': 'AdaniCustomerAPI24','password': 'LtAOqZiNGvVEuTY'}
  headers = {'Accept': 'application/json'}
  try:
    response = requests.request("POST", url, headers=headers, data=payload)
    if (response.status_code == 200):
      token = response.json().get('authorization_key')
      return token
  except Exception as Message:
    print(Message)


token = get_token()
headers = {
  'Accept': 'application/json',
  'Authorization': f'{token}'
}

# Read from Bigquery
def read_bq(extraction_query):
  try:
    df = read_gbq(extraction_query,project_id = project_id)
  except Exception as E:
    print('ERROR:-',E)
  return df

def post_tracking_data():
  extraction_query = '''SELECT cont_no,cont_size,booking_ref_code as booking_no,train_no_vehicle_no,origin,destination,current_status,last_updated_time,current_location,latitude,longitude,seq,book_cat_calc as booking_category,eta FROM `apsez-svc-prod-datalake.logistics_semantic.layer4_rt_trackyourcont_container_tracking_v2_mv` where length(cont_no)>=11 qualify row_number() over(partition by cont_no,current_status) = 1'''
  df = read_bq(extraction_query)

  # Data Preprocessing
  df[['latitude','longitude']]=df[['latitude','longitude']].fillna(0.0)
  date_cols=['eta']
  for col in date_cols:
      df[col] = pd.to_datetime(df[col])
      df[col] = df[col].dt.strftime('%d-%m-%Y %H:%M:%S')
      df[col] = df[col].apply(lambda x: '01-01-1900 00:00:00' if str(x) == 'nan' else x)
  result = df.to_dict('records')

  with open('tracking.json','w') as f:
      json.dump(result,f)

  # Post data To Endpoint
  with open('tracking.json','rb') as f:
      try:
        response = requests.request("POST", url, headers=headers, files={'file':f})
        print(response.text)
        print(response.status_code)
      except Exception as E:
        print('ERROR:-',E)
        print(response.text)
        print(response.status_code)
        
post_tracking_data = PythonOperator(
    task_id = 'post_tracking_data',
    python_callable = post_tracking_data,
    dag=dag
)
  


