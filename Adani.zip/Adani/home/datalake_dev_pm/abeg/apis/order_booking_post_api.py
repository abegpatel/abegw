from google.cloud import bigquery
from google.cloud import storage
import pandas as pd
from pandas_gbq import read_gbq
import json
import requests
from datetime import date,datetime,timedelta
import io
import aiohttp
import asyncio
from airflow import DAG
from airflow.operators.python_operator import PythonOperator

DEFAULT_ARGS = {
    'depends_on_past': False,
    # 'start_date': datetime.combine(date.today() - timedelta(days=1),time(hour=3, minute=45)),
    'start_date': datetime.today()-timedelta(minutes=60),
    'catchup': False,
    'retries': 4,
    'retry_delay': timedelta(minutes=1),
    'max_active_runs':1
}

dag = DAG(
    'order_booking_post_api',
    # schedule_interval = '@once',
    schedule_interval = '0 * * * *',
    tags = ["logistics","api","BA:Vikash","DE:Abeg","Orderbooking"],
    max_active_runs=1,
    default_args=DEFAULT_ARGS
)


# Arguments
project_id = 'apsez-svc-prod-datalake'
uri = "https://veracityapi.riddhigroup.in/"
chunk = 10
file_path = "/home/airflow/gcs/dags/scripts/"

# Get Token
def get_token():
  url = f"{uri}api/api-login"
  payload = {'user_name': 'AdaniCustomerAPI24','password': 'LtAOqZiNGvVEuTY'}
  headers = {'Accept': 'application/json'}
  try:
    response = requests.request("POST", url, headers=headers, data=payload)
    if (response.status_code == 200):
      token = response.json().get('authorization_key')
      return token
  except Exception as Message:
    print(Message)
    print(response.status_code,response.text)

# Post data To Endpoint
url = f"{uri}api/orderbooking-api-json"
token = get_token()
headers = {
  'Accept': 'application/json',
  'Authorization': f'{token}'
}

# Get Chunks
def get_chunks(data):
    data =  json.loads(data)
    total_items = len(data)
    cs = total_items//chunk
    for i in range(chunk):
      globals()[f'p{i+1}']=data[i*cs:(i+1)*cs]
    for i in range(1,int(chunk)+1):
      file_name_exp = file_path+f'orderbooking{i}.json'
      globals()[f'json_data{i}'] = json.dumps(globals()[f'p{i}'])
      write_to_cloud(globals()[f'json_data{i}'],f'orderbooking{i}')
# Write To GCS
def write_to_cloud(json_data,flag):
    gcs_file = f"OrderBooking/{flag}.json"
    client = storage.Client('apsez-svc-prod-datalake')
    bucket = client.get_bucket('sftp_apsez_archival_bucket_prod')
    blob = bucket.blob(gcs_file)
    blob.upload_from_string(json_data,content_type='application/json')
    print("Json file is uploaded -> ",gcs_file)
# Read From GCS
async def read_from_cloud(flag):
    gcs_file = f"OrderBooking/{flag}.json"
    client = storage.Client('apsez-svc-prod-datalake')
    bucket = client.get_bucket('sftp_apsez_archival_bucket_prod')
    blob = bucket.blob(gcs_file)
    file_content = blob.download_as_text()
    file_object = io.StringIO(file_content)
    return file_object
async def post_order_booking_data():
  extraction_query = """SELECT
    DISTINCT CAST(date AS string) date,
    customer_name,
    customer_code,
    order_no,
    delivery_mode,
    container_number,
    CAST(container_size AS INT64) container_size,
    from_terminal,
    to_terminal,
    eway_bill_file,
    line,
    consignee,
    consignee_address,
    consignor,
    consignor_address,
    importer,
    contact_no,
    empty_drop_loc,
    transport_by,
    SUBSTRING(CAST(trailer_required_date AS string),1,LENGTH(CAST(trailer_required_date AS string))-3) trailer_required_date,
    factory_address,
    factory,
    bill_to,
    CAST(bu_id AS INT64) bu_id,
    boe_no,
    CAST(ccrp_no AS integer) AS ccrp_no,
    SUBSTRING(CAST(ccrp_date AS string),1,LENGTH(CAST(ccrp_date AS string))-3) ccrp_date,
    factory_ref_code,
    Book_By_Party book_by_party,
    CHA cha,
    CHA_REF_Code cha_ref_code,
    exporter_name,
    exporter_ref_code,
    agent_name,
    agent_ref_code,
    SUBSTRING(CAST(DO_date AS string),1,LENGTH(CAST(DO_date AS string))-3) do_date,
    DO_Number do_number,
    importer_name,
    importer_ref_code,
    importer_address,
    OOC_No ooc_no,
    SUBSTRING(CAST(OUT_OF_CHARGE_DATE AS string),1,LENGTH(CAST(OUT_OF_CHARGE_DATE AS string))-3) out_of_charge_date
  FROM
    `apsez-svc-prod-datalake.logistics_semantic.layer4_customer_portal_bt_order_booking_details_mv` where date(date) >= current_date-30"""

  # Read from Bigquery
  def read_bq():
    try:
      df = read_gbq(extraction_query,project_id = project_id)
    except Exception as E:
      print('Error -> is ',E)
    return df

  df = read_bq()

  # Data Cleaning
  df[['customer_code','boe_no','ccrp_no','bu_id','do_number','ooc_no']]=df[['customer_code','boe_no','ccrp_no','bu_id','do_number','ooc_no']].fillna(0)
  date_cols=['trailer_required_date','ccrp_date','do_date','out_of_charge_date']
  for col in date_cols:
    df[col] = pd.to_datetime(df[col])
    df[col] = df[col].dt.strftime('%d-%m-%Y %H:%M:%S')
    df[col] = df[col].apply(lambda x: '01-01-1900 00:00:00' if str(x) == 'nan' else x)

  df = df.applymap(lambda x:str(None) if pd.isna(x) else x)
  result_dict = df.to_dict('records')
  result = json.dumps(result_dict)
  get_chunks(result)

  async with aiohttp.ClientSession() as session:
    for i in range(1,chunk+1):
      try:
        async with session.post(url, headers=headers, data={'file':read_from_cloud(f'orderbooking{i}')}) as globals()[f"response{i}"]:
          print(f'orderbooking{i}.json is successfully posted')
          #print(await globals()[f"response{i}"].status_code())
          print(await globals()[f"response{i}"].text())
      except Exception as E:
        print('Error -> is ',E)
        print(await globals()[f"response{i}"].text())
        #print(await globals()[f"response{i}"].status_code())

def async_post_order_booking_data():
  return asyncio.run(post_order_booking_data())

async_post_order_booking_data = PythonOperator(
    task_id = 'async_post_order_booking_data',
    python_callable = async_post_order_booking_data,
    dag=dag
)   

async_post_order_booking_data




