from google.cloud import bigquery
from google.cloud import storage
import pandas as pd
from pandas_gbq import read_gbq
import json
import requests
from datetime import date,datetime,timedelta
import io

# Arguments
project_id = 'apsez-svc-prod-datalake'
uri = "https://veracityapi.riddhigroup.in/"
file_path = "/home/airflow/gcs/dags/scripts/"

# Get Token
def get_token():
  url = f"{uri}api/api-login"
  payload = {'user_name': 'AdaniCustomerAPI24','password': 'LtAOqZiNGvVEuTY'}
  headers = {'Accept': 'application/json'}
  try:
    response = requests.request("POST", url, headers=headers, data=payload)
    if (response.status_code == 200):
      token = response.json().get('authorization_key')
      return token
  except Exception as Message:
    print(Message)
    print(response.status_code,response.text)

# Post data To Endpoint
url = f"{uri}api/orderbooking-api-json"
token = get_token()
headers = {
  'Accept': 'application/json',
  'Authorization': f'{token}'
}
def post_order_booking_data():
  extraction_query = """SELECT
    DISTINCT CAST(date AS string) date,
    customer_name,
    customer_code,
    order_no,
    delivery_mode,
    container_number,
    CAST(container_size AS INT64) container_size,
    from_terminal,
    to_terminal,
    eway_bill_file,
    line,
    consignee,
    consignee_address,
    consignor,
    consignor_address,
    importer,
    contact_no,
    empty_drop_loc,
    transport_by,
    SUBSTRING(CAST(trailer_required_date AS string),1,LENGTH(CAST(trailer_required_date AS string))-3) trailer_required_date,
    factory_address,
    factory,
    bill_to,
    CAST(bu_id AS INT64) bu_id,
    boe_no,
    CAST(ccrp_no AS integer) AS ccrp_no,
    SUBSTRING(CAST(ccrp_date AS string),1,LENGTH(CAST(ccrp_date AS string))-3) ccrp_date,
    factory_ref_code,
    Book_By_Party book_by_party,
    CHA cha,
    CHA_REF_Code cha_ref_code,
    exporter_name,
    exporter_ref_code,
    agent_name,
    agent_ref_code,
    SUBSTRING(CAST(DO_date AS string),1,LENGTH(CAST(DO_date AS string))-3) do_date,
    DO_Number do_number,
    importer_name,
    importer_ref_code,
    importer_address,
    OOC_No ooc_no,
    SUBSTRING(CAST(OUT_OF_CHARGE_DATE AS string),1,LENGTH(CAST(OUT_OF_CHARGE_DATE AS string))-3) out_of_charge_date
  FROM
    `apsez-svc-prod-datalake.logistics_semantic.layer4_customer_portal_bt_order_booking_details_mv` where date(date) >= current_date-30"""

  # Read from Bigquery
  def read_bq():
    try:
      df = read_gbq(extraction_query,project_id = project_id)
    except Exception as E:
      print('Error -> is ',E)
    return df

  df = read_bq()

  # Data Cleaning
  df[['customer_code','boe_no','ccrp_no','bu_id','do_number','ooc_no']]=df[['customer_code','boe_no','ccrp_no','bu_id','do_number','ooc_no']].fillna(0)
  date_cols=['trailer_required_date','ccrp_date','do_date','out_of_charge_date']
  for col in date_cols:
    df[col] = pd.to_datetime(df[col].fillna(str(None)), errors='coerce').dt.strftime('%d-%m-%Y %H:%M:%S')

  """for col in date_cols:
    df[col] = pd.to_datetime(df[col])
    df[col] = df[col].dt.strftime('%d-%m-%Y %H:%M:%S')
    df[col] = df[col].apply(lambda x: str(None) if str(x) == 'nan' else str(x))"""


  df = df.applymap(lambda x:str(None) if pd.isna(x) else x)
  result_dict = df.to_dict('records')
  #result = json.dumps(result_dict)
  print(len(result_dict))

  with open('orderbooking.json','w') as f:
      json.dump(result_dict,f)
  # Post data To Endpoint
  with open('orderbooking.json','rb') as f:
    try:
      response = requests.request("POST", url, headers=headers, files={'file':f})
      #print(f'tracking.json is successfully posted')
      print(response.status_code)
      print(response.text)
    except Exception as E:
      print('ERROR:-',E)
      print(response.status_code)
      print(response.text)

post_order_booking_data()






