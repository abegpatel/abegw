from google.cloud import bigquery
import pandas as pd
from pandas_gbq import read_gbq
import json
import requests
from datetime import date,datetime,time
import numpy as np
import os

# URL Args
uri = "https://veracityapi.riddhigroup.in/"
url = f"{uri}api/tracking-api-json"


# Project Args
chunk = 15 # datasize kb//3500 kb
project_id = 'apsez-svc-prod-datalake'

# Utility
def get_token():
  url = f"{uri}api/api-login"
  payload = {'user_name': 'AdaniCustomerAPI24','password': 'LtAOqZiNGvVEuTY'}
  headers = {'Accept': 'application/json'}
  try:
    response = requests.request("POST", url, headers=headers, data=payload)
    if (response.status_code == 200):
      token = response.json().get('authorization_key')
      return token
  except Exception as E:
    print('ERROR:-',E)
    print(response.status_code,response.text)

token = get_token()
headers = {
  'Accept': 'application/json',
  'Authorization': f'{token}'
}

def get_chunks(data):
    data =  json.loads(data)
    total_items = len(data)
    cs = total_items//chunk
    for i in range(chunk):
      globals()[f'p{i+1}']=data[i*cs:(i+1)*cs]
    print(p15)
    for i in range(1,int(chunk)+1):
      with open(f'tracking/tracking{i}.json','w') as f:
        json.dump(globals()[f'p{i}'],f)

extraction_query = """SELECT cont_no,cont_size,booking_ref_code as booking_no,train_no_vehicle_no,origin,destination,current_status,last_updated_time,current_location,latitude,longitude,seq,book_cat_calc as booking_category,eta FROM `apsez-svc-prod-datalake.logistics_semantic.layer4_rt_trackyourcont_container_tracking_v2_mv` where length(cont_no)>=11 qualify row_number() over(partition by cont_no,current_status) = 1"""

# Read from Bigquery
def read_bq():
  try:
    df = read_gbq(extraction_query,project_id = project_id)
  except Exception as msg:
    print('ERROR:-',E)
  return df

df = read_bq()
print(df.head())

# Data Cleaning
df[['latitude','longitude']]=df[['latitude','longitude']].fillna(0.0)
date_cols=['eta']
for col in date_cols:
    df[col] = pd.to_datetime(df[col])
    df[col] = df[col].dt.strftime('%d-%m-%Y %H:%M:%S')
    df[col] = df[col].apply(lambda x: '01-01-1900 00:00:00' if str(x) == 'nan' else x)

result_dict = df.to_dict('records')
result = json.dumps(result_dict)
get_chunks(result)

# Post data To Endpoint
for i in range(1,chunk+1):
  with open(f'tracking{i}.json','rb') as f:
    try:
      globals()[f"response{i}"] = requests.request("POST", url, headers=headers, files={'file':f})
      print(f'tracking{i}.json is successfully posted')
      print(globals()[f"response{i}"].status_code)
      except Exception as E:
        print('ERROR:-',E)
        print(globals()[f"response{i}"].status_code)
        print(globals()[f"response{i}"].text)

"""# Delete files Workspace
for i in range(1,chunk+1):
  if os.path.exists(f'tracking{i}.json'):
    os.remove(f'tracking{i}.json')
print("Workspace Cleaned Successfully")"""






