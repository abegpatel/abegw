from google.cloud import bigquery
import pandas as pd
from pandas_gbq import read_gbq
import numpy as np
import json
import requests
from datetime import date,datetime,time
 
project_id = 'apsez-svc-prod-datalake'
extraction_query = """
SELECT 1 SR,  'IMPORT' AS `Event Name`,coalesce(COUNT (AssessNo ),0)AS `No of Record`,  
coalesce(Sum(NetTotal),0) `Net Amount`,  
coalesce(Sum(sgst+cgst+igst),0) GST,    
coalesce(SUM (GrandTotal),0)AS Amount from `tracker_replica.layer1_nicd_import_assessm`  where date(assessdate) between current_date-11  and current_date-10   and IsCancel =0        
UNION ALL         
SELECT 2 SR, 'EXPORT' AS`Event Name`,coalesce(COUNT (AssessNo ),0)AS `No of Record`,round(coalesce(Sum(NetTotal),0),0) `Net Amount`,     
round(coalesce(Sum(sgst+cgst+igst),0),0) GST,    
round(coalesce(SUM (GrandTotal),0),0) AS Amount from `tracker_replica.layer1_nicd_exp_assessm`  where date(assessdate) between current_date-11  and   current_date-10 and IsCancel =0        
UNION ALL        
SELECT 3 SR, 'OTHER' AS`Event Name`, coalesce(COUNT (AssessNo ),0)AS `No of Record`,coalesce(Sum(NetTotal),0) `Net Amount`,     
coalesce(Sum(sgst+cgst+igst),0) GST,    
coalesce(SUM (GrandTotal),0)AS Amount from `tracker_replica.layer1_nicd_other_assessm`  where date(assessdate) between current_date-11  and current_date-10   and IsCancel =0        
UNION ALL         
SELECT 4 SR, 'BOND' AS`Event Name`,coalesce(COUNT (AssessNo ),0)AS `No of Record`,coalesce(Sum(NetTotal),0) `Net Amount`,     
coalesce(Sum(sgst+cgst+igst),0) GST,    
coalesce(SUM (GrandTotal),0)AS Amount from `tracker_replica.layer1_nicd_bond_assessm`  where date(assessdate) between current_date-11  and current_date-10   and IsCancel =0        
UNION ALL         
SELECT 5 SR, 'MNR' AS`Event Name`,coalesce(COUNT (AssessNo ),0)AS `No of Record`,coalesce(Sum(NetTotal),0) `Net Amount`,     
coalesce(Sum(sgst+cgst+igst),0) GST,    
coalesce(SUM (GrandTotal),0)AS Amount from `tracker_replica.layer1_nicd_eyard_assessm`  where date(assessdate) between current_date-11  and current_date-10   and IsCancel =0        
UNION ALL         
SELECT 6 SR, 'DOMESTIC' AS`Event Name`,coalesce(COUNT (AssessNo ),0)AS `No of Record`,round(coalesce(Sum(NetTotal),0),0) `Net Amount`,     
round(coalesce(Sum(sgst+cgst+igst),0),0) GST,    
round(coalesce(SUM (GrandTotal),0),0) AS Amount from `tracker_replica.layer1_nicd_domestic_assessm`  where date(assessdate) between current_date-11  and current_date-10   and IsCancel =0  
  
UNION ALL         
SELECT 6 SR, 'EDI' AS`Event Name`,coalesce(COUNT (AssessNo ),0)AS `No of Record`,Round(coalesce(Sum(NetTotal),0),0) `Net Amount`,     
Round(coalesce(Sum(sgst+cgst+igst),0),0) GST,    
round(coalesce(SUM (GrandTotal),0),0) AS Amount from `tracker_replica.layer1_nicd_edi_assessm`  where date(assessdate) between current_date-11  and current_date-10   and IsCancel =0  
"""

df = read_gbq(extraction_query,project_id = project_id)
result = df.to_dict('records')
result = json.dumps(result)
print(result)
