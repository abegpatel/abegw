import pandas as pd
from pandas_gbq import read_gbq
import numpy as np
import json
 
project_id = 'apsez-svc-prod-datalake'
extraction_query = """
with filtered_p2 as  (

  select * from (
    select * ,  RANK() OVER(partition by container_no	 , LR_NO ORDER BY LR_DATE DESC) AS rank_ 

from 

apsez-svc-prod-datalake.logistics_semantic.layer4_rt_all_road_operations_p2_mv
 where cast(LR_DATE as date) >= current_date - 45 
  )where rank_ = 1

)

select

'Rail' as operation ,
visit_port as location_or_visit_port ,
ob_discharge_port ,
placement_destination ,
cont_no as container_no	,
cast(cont_size as int) as  container_size ,
null as container_type,
train_no_vehicle_no,
 origin,
null as factory	,
  destination,
	null as  gate_out_date ,
 null as gate_in_date	,
 null as  reported_at_site_date	,
 null as release_from_site_date	,
  booking_ref_code as booking_no	,
   null as booking_date	,
 null as  ccrp_date	,
  null as issue_flag,
  null as customer	,
  null as customer_type	,
  null as transport_by	,
  null as transaction_type ,
    book_date ,
    	null as lr_date ,

      null as line ,
      null as trailer_req_date,
            null as latitude ,
      null as logitude ,
           null as factory_lat ,
      null as factory_longh


from 
 `logistics_semantic.layer4_rt_trackyourcont_container_tracking_v2_mv` 
where cont_no = '{0}'

union all

select 'Road' as operation ,

location as location_or_visit_port ,
null as ob_discharge_port ,
null as placement_destination ,
container_no	,
cast(container_size as int) as  container_size ,
container_type,
      vehicle_no as train_no_vehicle_no,
from_loc	as origin,
factory	,
final_loc as destination,
	gate_out_date ,
  gate_in_date	,
  reported_at_site_date	,
  release_from_site_date	,
  booking_no	,
  booking_date	,
  ccrp_date	,
  issue_flag,
  customer	,
  customer_type	,
  transport_by	,
  transaction_type ,
    book_date ,
    	lr_date ,

      line ,
      trailer_req_date ,
      null as latitude ,
      null as logitude ,
      null as factory_lat ,
      null as factory_longh

 from  
filtered_p2
where container_no  = '{1}'
order by LR_DATE desc
""".format('CAIU4703831','CMAU1165247')

df = read_gbq(extraction_query,project_id = project_id)
df = df.applymap(lambda x:str(None) if pd.isna(x) else x)
result = df.to_dict('records')
result = json.dumps(result)
print(result)

