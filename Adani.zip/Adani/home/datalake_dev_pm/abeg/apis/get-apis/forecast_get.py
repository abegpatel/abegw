from google.cloud import bigquery
import pandas as pd
from pandas_gbq import read_gbq
import numpy as np
import json
import requests
from datetime import date,datetime,time
 
project_id = 'apsez-svc-prod-datalake'
extraction_query = """
SELECT * FROM logistics_cleansed.layer2_locc_manual_forecast
"""

# Read from Bigquery

df = read_gbq(extraction_query,project_id = project_id)
print(df.dtypes)

   

result = df.to_dict('records')
result = json.dumps(result)
print(result)

"""headers_get = {
      'Content-Type': 'application/json'
}
 
response = requests.get('https://apsez.adani.com/forecast_locc',headers=headers_get,data=result)
 
if response.status_code == 200:
    print(response.text)
    print("Data posted successfully")
else:
    print(response.text)
    print(response.status_code)
"""
