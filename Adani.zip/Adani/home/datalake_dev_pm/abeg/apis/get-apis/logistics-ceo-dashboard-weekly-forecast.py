from google.cloud import bigquery
import pandas as pd
from pandas_gbq import read_gbq
import numpy as np
import json
import requests
from datetime import date,datetime,time
 
project_id = 'apsez-svc-prod-datalake'
extraction_query = """Select *, concat(from_date,' to ',to_date) as week_date_range  from (Select BUSiNESS,FROM_DATE,TO_DATE,SUM(FORECAST) AS weekly_forecast from apsez-svc-prod-datalake.logistics_master.layer2_sales_volume_route_forecast
group by 1,2,3 order by from_date)"""

df = read_gbq(extraction_query,project_id = project_id)
print(df.head())
"""
datetime_cols = ['FROM_DATE','TO_DATE']
for col in datetime_cols:
    df[col] = df[col].apply(lambda x: '01-01-1900 00:00:00' if str(x) == 'nan' else x)
"""
df = df.applymap(lambda x:str(None) if pd.isna(x) else str(x))
result = df.to_dict('records')
print(result)
result = json.dumps(result)
print(result)
