

from google.cloud import bigquery
import pandas as pd
from pandas_gbq import read_gbq
import json
import requests
from datetime import date,datetime,time
import numpy as np
import os
import psycopg2
import sqlalchemy as sql
import logging
import duckdb

# URL Args
uri = "https://superapp.ezrdu.com"
url = f"{uri}/api/scheduleinfo/ibob"

# Utility
def get_token():
  key = 'b3fa7386b9a51cc7c10aa268e0d892fd763232327632323276323232769192583a011d842f039168e9c2c40e90'
  url = f"{uri}/api/auth/{key}"
  payload = {}
  headers = {}
  try:
    response = requests.request("GET", url, headers=headers, data=payload)
    if (response.status_code == 200):
      token = response.text
      return token
  except Exception as E:
    print('ERROR:-',E)
    print(response.status_code,response.text)

token = get_token()
print(token)
headers = {
  'Accept': 'application/json',
  'Authorization': f'Bearer {token}'
}

# Project Args
project_id = 'apsez-svc-prod-datalake'


# Query 
ib_wagon_query = """SELECT * FROM
(
SELECT
TRAIN_VISIT_NO,
OB_TRAIN_NO,
WAGON_NO,
CONT_NO,
POSITION,
CONT_SIZE,
CONT_STATUS,
TEUS, 
'Non_EF' AS WAGON_STATUS,
'INBOUND' AS IB_OB
FROM `apsez-svc-prod-datalake.logistics_semantic.layer4_rt_rail_report_mv`
 
UNION ALL
 
SELECT
    a.TRAIN_VISIT_NO,
    OB_TRAIN_NO,
    c.wagon_no,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL, 
    'EF' AS WAGON_STATUS,
    'INBOUND' AS IB_OB
  FROM
    gg_replica.layer1_cfsmag_et_empty_wagon_mapping a
    LEFT JOIN `apsez-svc-prod-datalake.logistics_semantic.layer4_rt_all_rail_performance_mv` b on 
    a.train_visit_no = b.train_visit_no 
    LEFT JOIN (
  SELECT
    DISTINCT(WAGON_NO) WAGON_NO,
    WAGON_ID
  FROM
    `apsez-svc-prod-datalake.gg_replica.layer1_cfsmag_et_wagon_master` ) c  ON c.wagon_id = a.wagon_id    
 WHERE wagon_no IS NOT NULL
)"""




cloud_sql_pg_prod="postgresql+psycopg2://ANALYTICS.USER1:ANALYTICSUSER1@10.81.164.61:5432/datalake_postgres_rt?sslmode=require"
def PG_CONN(task='',obj='',query='',tgt_connection_string='',table='',schema='logistics_cleansed',how=''):

    engine = sql.create_engine(tgt_connection_string)
    logging.info(f"Connection with CLOUD SQL POSTGRESQL Database established successfully!!\n")
    
    with engine.begin() as conn:
        if task == 'call':
            call_query = f"""call {obj}();"""
            call = conn.execute(call_query)
        # elif task == 'refresh':
            # refresh_query = f"""REFRESH MATERIALIZED VIEW {obj};"""
            # refresh = conn.execute(refresh_query)
        elif task=='dataframe':
            df = pd.DataFrame()
            for chunk in pd.read_sql(sql=query,con=conn,chunksize=50000):
                df = pd.concat([df,chunk])
            return df
        elif task=='query':
            conn.execute(query)
        else:
            obj.to_sql(name=table,schema=schema,con=conn,if_exists=how)
            
    conn.close()
    engine.dispose()
    

terminal_query = """SELECT 
actual_arrval_date,
arrival_to_now,
arrival_to_placement,
base_depot_1,
base_depot_code,
bpc_valid_to,
business_unit,
event,
load_complete_date,
load_plan_teus,
load_start_date,
ob_discharge_port,
placement_date,
placement_to_release,
railway_line_id,
rake_name,
remaining_dist,
removal_date,
removal_to_now,
stable_complete_date,
stable_start_date,
status_hours,
total_travelled,
train_visit_no,
txr_complete_date,
txr_start_date,
unload_complete_date,
unload_start_date,
visit_port,
ib_train_no,
ob_train_no
FROM
(SELECT coalesce(to_char(actual_arrval_date, 'DD-Mon-YY HH24:MI'), '-') AS actual_arrval_date
	,coalesce(arrival_to_now, '-') AS arrival_to_now
	,coalesce(arrival_to_placement, '-') AS arrival_to_placement
	,coalesce(base_depot_1, '-') AS base_depot_1
	,coalesce(base_depot_code, '-') AS base_depot_code
	,bpc_valid_to
	,coalesce(business_unit, '-') AS business_unit
	,coalesce(event, '-') AS event
	,coalesce(to_char(load_complete_date, 'DD-Mon-YY HH24:MI'), '-') AS load_complete_date
	,coalesce(load_plan_teus::TEXT, '-') AS load_plan_teus
	,coalesce(to_char(load_start_date, 'DD-Mon-YY HH24:MI'), '-') AS load_start_date
	,coalesce(ob_discharge_port, '-') AS ob_discharge_port
	,coalesce(to_char(placement_date, 'DD-Mon-YY HH24:MI'), '-') AS placement_date
	,coalesce(placement_to_release, '-') AS placement_to_release
	,coalesce(railway_line_id, '-') AS railway_line_id
	,coalesce(rake_name, '-') AS rake_name
	,remaining_dist
	,coalesce(to_char(removal_date, 'DD-Mon-YY HH24:MI'), '-') AS removal_date
	,coalesce(removal_to_now, '-') AS removal_to_now
	,coalesce(to_char(stable_complete_date, 'DD-Mon-YY HH24:MI'), '-') AS stable_complete_date
	,coalesce(to_char(stable_start_date, 'DD-Mon-YY HH24:MI'), '-') AS stable_start_date
	,coalesce(status_hours, '-') AS status_hours
	,total_travelled
	,coalesce(train_visit_no::TEXT, '-') AS train_visit_no
	,coalesce(to_char(txr_complete_date, 'DD-Mon-YY HH24:MI'), '-') AS txr_complete_date
	,coalesce(to_char(txr_start_date, 'DD-Mon-YY HH24:MI'), '-') AS txr_start_date
	,coalesce(to_char(unload_complete_date, 'DD-Mon-YY HH24:MI'), '-') AS unload_complete_date
	,coalesce(to_char(unload_start_date, 'DD-Mon-YY HH24:MI'), '-') AS unload_start_date
	,coalesce(visit_port, '-') AS visit_port
	,ib_train_no
	,ob_train_no
FROM (
	SELECT x.*
		,UPPER(rm.base_depot_1) AS base_depot_1
		,DATE (y.bpc_valid_to::TIMESTAMP) AS bpc_valid_to
		,round(y.total_travelled, 0) AS total_travelled
		,CASE 
			WHEN y.remaining_dist = 'NA'
				THEN NULL
			WHEN y.remaining_dist = '-'
				THEN NULL
			WHEN y.remaining_dist = 'END TO END'
				THEN NULL
			ELSE (y.remaining_dist::NUMERIC)
			END AS remaining_dist
	FROM (
		SELECT train_visit_no
			,rake_name
			,business_unit
			,event
			,status_hours
			,railway_line_id
			,visit_port
			,ob_discharge_port
			,load_plan_teus
			,actual_arrval_date
			,placement_date
			,unload_start_date
			,unload_complete_date
			,stable_start_date
			,stable_complete_date
			,txr_start_date
			,txr_complete_date
			,load_start_date
			,load_complete_date
			,removal_date
			,(arrival_to_now * INTERVAL '1 hour')::TEXT AS arrival_to_now
			,(arrvtoplac * INTERVAL '1 hour')::TEXT AS arrival_to_placement
			,(placetorele * INTERVAL '1 hour')::TEXT AS placement_to_release
			,(extract(epoch FROM now() - removal_date) * INTERVAL '1 hour')::TEXT AS removal_to_now
			,base_depot_code
			,ib_train_no
			,ob_train_no
		FROM (
			SELECT abc.*
				,xyz.t_tat_sla
				,ROUND(CASE 
						WHEN removal_date IS NULL
							THEN (date_part('epoch', NOW() + '05:30:00'::interval - placement_date::TIMESTAMP WITH TIME zone) / 3600::DOUBLE PRECISION)::NUMERIC
						ELSE (date_part('epoch', removal_date::TIMESTAMP WITH TIME zone - placement_date::TIMESTAMP WITH TIME zone) / 3600::DOUBLE PRECISION)::NUMERIC
						END, 2) AS t_tat
			FROM (
				SELECT *
					,CASE 
						WHEN mv.STATUS = 'AWAITING DEPARTURE'
							THEN CASE 
									WHEN (EXTRACT(EPOCH FROM (CURRENT_TIMESTAMP - mv.REMOVAL_DATE)) / 3600) <= 72
										THEN CONCAT (
												'Awaiting departure for '
												,TO_CHAR((EXTRACT(EPOCH FROM (CURRENT_TIMESTAMP - mv.REMOVAL_DATE)) / 3600)::INT, 'FM00')
												,':'
												,TO_CHAR(MOD((EXTRACT(EPOCH FROM (CURRENT_TIMESTAMP - mv.REMOVAL_DATE)) / 60)::INT, 60), 'FM00')
												,' hrs'
												)
									ELSE CONCAT (
											'Awaiting departure for '
											,EXTRACT(DAY FROM (CURRENT_TIMESTAMP - mv.REMOVAL_DATE))
											,' Days '
											,TO_CHAR(EXTRACT(HOUR FROM (CURRENT_TIMESTAMP - mv.REMOVAL_DATE))::INT, 'FM00')
											,':'
											,TO_CHAR(EXTRACT(MINUTE FROM (CURRENT_TIMESTAMP - mv.REMOVAL_DATE))::INT, 'FM00')
											,' hrs'
											)
									END
						WHEN mv.STATUS = 'UNDER MAINTENANCE'
							THEN CASE 
									WHEN (EXTRACT(EPOCH FROM (CURRENT_TIMESTAMP - mv.TXR_START_DATE)) / 3600) <= 72
										THEN CONCAT (
												'Under maintenance for '
												,TO_CHAR((EXTRACT(EPOCH FROM (CURRENT_TIMESTAMP - mv.TXR_START_DATE)) / 3600)::INT, 'FM00')
												,':'
												,TO_CHAR(MOD((EXTRACT(EPOCH FROM (CURRENT_TIMESTAMP - mv.TXR_START_DATE)) / 60)::INT, 60), 'FM00')
												,' hrs'
												)
									ELSE CONCAT (
											'Under maintenance for '
											,EXTRACT(DAY FROM (CURRENT_TIMESTAMP - mv.TXR_START_DATE))
											,' Days'
											,TO_CHAR(EXTRACT(HOUR FROM (CURRENT_TIMESTAMP - mv.TXR_START_DATE))::INT, 'FM00')
											,' Hours'
											,TO_CHAR(EXTRACT(MINUTE FROM (CURRENT_TIMESTAMP - mv.TXR_START_DATE))::INT, 'FM00')
											,' Mins'
											)
									END
						WHEN mv.STATUS = 'PARKED'
							THEN CASE 
									WHEN (EXTRACT(EPOCH FROM (CURRENT_TIMESTAMP - mv.STABLE_START_DATE)) / 3600) < 72
										THEN CONCAT (
												'Parked for '
												,TO_CHAR((EXTRACT(EPOCH FROM (CURRENT_TIMESTAMP - mv.STABLE_START_DATE)) / 3600)::INT, 'FM00')
												,':'
												,TO_CHAR(MOD((EXTRACT(EPOCH FROM (CURRENT_TIMESTAMP - mv.STABLE_START_DATE)) / 60)::INT, 60), 'FM00')
												,' hrs'
												)
									ELSE CONCAT (
											'Parked for '
											,EXTRACT(DAY FROM (CURRENT_TIMESTAMP - mv.STABLE_START_DATE))
											,' Days '
											,TO_CHAR(EXTRACT(HOUR FROM (CURRENT_TIMESTAMP - mv.STABLE_START_DATE))::INT, 'FM00')
											,':'
											,TO_CHAR(EXTRACT(MINUTE FROM (CURRENT_TIMESTAMP - mv.STABLE_START_DATE))::INT, 'FM00')
											,' hrs'
											)
									END
						WHEN mv.STATUS = 'UNDER OPERATION'
							THEN CASE 
									WHEN (EXTRACT(EPOCH FROM (CURRENT_TIMESTAMP - mv.PLACEMENT_DATE)) / 3600) < 72
										THEN CONCAT (
												'Under operation for '
												,TO_CHAR((EXTRACT(EPOCH FROM (CURRENT_TIMESTAMP - mv.PLACEMENT_DATE)) / 3600)::INT, 'FM00')
												,':'
												,TO_CHAR(MOD((EXTRACT(EPOCH FROM (CURRENT_TIMESTAMP - mv.PLACEMENT_DATE)) / 60)::INT, 60), 'FM00')
												,' hrs'
												)
									ELSE CONCAT (
											'Under operation for '
											,EXTRACT(DAY FROM (CURRENT_TIMESTAMP - mv.PLACEMENT_DATE))
											,' Days '
											,TO_CHAR(EXTRACT(HOUR FROM (CURRENT_TIMESTAMP - mv.PLACEMENT_DATE))::INT, 'FM00')
											,':'
											,TO_CHAR(EXTRACT(MINUTE FROM (CURRENT_TIMESTAMP - mv.PLACEMENT_DATE))::INT, 'FM00')
											,' hrs'
											)
									END
						WHEN mv.STATUS = 'OTHERS'
							THEN NULL
						ELSE NULL
						END AS status_hours
					,ROUND((date_part('epoch', NOW() + '05:30:00'::interval - actual_arrval_date::TIMESTAMP WITH TIME zone) / 3600::DOUBLE PRECISION)::NUMERIC, 2) AS arrival_to_now
					,ROUND((date_part('epoch', placement_date::TIMESTAMP WITH TIME zone - actual_arrval_date::TIMESTAMP WITH TIME zone) / 3600::DOUBLE PRECISION)::NUMERIC, 2) AS arrvtoplac
					,ROUND((date_part('epoch', removal_date::TIMESTAMP WITH TIME zone - placement_date::TIMESTAMP WITH TIME zone) / 3600::DOUBLE PRECISION)::NUMERIC, 2) AS placetorele
				FROM (
					SELECT rake_name rakename
					FROM logistics_semantic.layer4_rake_running_status_mv
					WHERE UPPER(STATUS) IN (
							'UNDER OPERATION'
							,'AWAITING DEPARTURE'
							,'PARKED'
							)
					) run
				LEFT JOIN logistics_semantic.layer4_cfsmag_latest_rake_status_mv mv ON run.rakename = mv.rake_name
				LEFT JOIN (
					SELECT *
					FROM (
						SELECT *
							,row_number() OVER (
								PARTITION BY x.tno ORDER BY COALESCE(x.timestamp_s, '1999-01-01 00:00:00'::TIMESTAMP without TIME zone) DESC
								) AS rnk
						FROM (
							SELECT train_visit_no AS tno
								,t.*
							FROM logistics_semantic.layer4_cfsmag_latest_rake_status_mv c
							CROSS JOIN LATERAL(VALUES (
									c.placement_date
									,'PLACED'
									), (
									c.removal_date
									,'REMOVAL COMPLETED'
									), (
									c.stable_start_date
									,'STABLE STARTED'
									), (
									c.stable_complete_date
									,'STABLE COMPLETED'
									), (
									c.txr_start_date
									,'STABLE STARTED'
									), (
									c.txr_complete_date
									,'TXR COMPLETED'
									), (
									c.unload_start_date
									,'UNLOAD STARTED'
									), (
									c.unload_complete_date
									,'UNLOAD COMPLETED'
									), (
									c.load_start_date
									,'LOAD STARTED'
									), (
									c.load_complete_date
									,'LOAD COMPLETED'
									)) AS t(timestamp_s, event)
							) x
						) p_data
					WHERE rnk = 1
						AND tno IS NOT NULL
					ORDER BY 1
					) pdata ON pdata.tno = mv.train_visit_no
				WHERE mv.train_visit_no IS NOT NULL
				) abc
			LEFT JOIN (
				SELECT terminal_name AS origin_code
					,placement_to_removal AS t_tat_sla
				FROM logistics_cleansed.layer2_cfsmag_terminal_operation_sla_mst
				GROUP BY terminal_name
					,placement_to_removal
				ORDER BY 1
				) xyz ON xyz.origin_code = abc.visit_port --where 
				--UPPER(status) in ('UNDER OPERATION', 'OTHERS')
			) aa
		) x
	LEFT JOIN logistics_cleansed.layer2_all_rake_txr_details y ON y.rake_name = x.rake_name
	LEFT JOIN logistics_cleansed.layer2_cfsmag_rake_master rm ON rm.rake_name = x.rake_name
	) main
WHERE business_unit IN ('ALL','ALSPL')
AND visit_port IN ('AFAS','ALGV','ALIK','ICAK','LONI','MAAM','PALB','PATP','PDLL')
 ) X
ORDER BY rake_name DESC"""
df_terminal = PG_CONN(task='dataframe',query=terminal_query,tgt_connection_string=cloud_sql_pg_prod)
print(df_terminal.head())
df_terminal.rename(columns={'event':'eventaction','train_visit_no':'train_visit_no1'},inplace=True)
print(df_terminal.columns)




# Read from Bigquery
df = read_gbq(ib_wagon_query,project_id = project_id)
df.rename(columns={'TRAIN_VISIT_NO':'train_visit_no2'},inplace=True)
print(df.columns)


final_df = df_terminal.merge(df,how = "left",left_on='ib_train_no',right_on='OB_TRAIN_NO')
print(final_df.shape)


datetime_cols=['actual_arrval_date','bpc_valid_to','load_complete_date','load_start_date','placement_date','removal_date','stable_complete_date','stable_start_date','txr_complete_date','txr_start_date','unload_complete_date','unload_start_date']
for col in datetime_cols:
  try:
    final_df[col] = final_df[col].dt.tz_localize(None)
    final_df[col] = final_df[col].dt.strftime('%d-%m-%Y %H:%M')
    final_df[col] = final_df[col].apply(lambda x: str(None) if str(x) == 'nan' else x)
  except:
    final_df[col] = str(None)




final_df.rename(columns={'CONT_NO':'cont_no','POSITION':'position','CONT_SIZE':'cont_size','CONT_STATUS':'cont_status'},inplace=True)
final_df.rename(columns={'WAGON_NO':'wagon_no','WAGON_STATUS':'wagon_status','TEUS':'teus'},inplace=True)

final_df[['wagon_no','load_plan_teus','remaining_dist','total_travelled','train_visit_no1']] = final_df[['wagon_no','load_plan_teus','remaining_dist','total_travelled','train_visit_no1']].fillna(0)
final_df['wagon_no'] = final_df['wagon_no'].replace('-',0).astype(int)
final_df['load_plan_teus'] = final_df['load_plan_teus'].replace('-',0).astype(int)
final_df['remaining_dist'] = final_df['remaining_dist'].replace('-',0).astype(int)
final_df['total_travelled'] = final_df['total_travelled'].replace('-',0).astype(int)
final_df['train_visit_no1'] = final_df['train_visit_no1'].replace('-',0).astype(int)
print(final_df.columns)

final_df = final_df.head(10)
print(final_df.head())

main_dict ={}
terminal_wagon_list = []
wagon_list = []
main_list = []
group = final_df.groupby('wagon_no')final_df[['wagon_no','cont_no','position','cont_size','cont_status']]
for i in range(len(final_df)):
  if pd.isna(final_df['ob_train_no'][i]):
    schtype = 2
  else:
    schtype = 1
  main_dict['schtype'] = schtype
  main_dict['rakename'] = final_df['rake_name'][i]
  main_dict['incomingterminalcode'] = final_df['visit_port'][i]
  terminal_wagon_df = final_df[['actual_arrval_date', 'arrival_to_now', 'arrival_to_placement',
       'base_depot_1', 'base_depot_code', 'bpc_valid_to', 'business_unit',
       'eventaction', 'load_complete_date', 'load_plan_teus', 'load_start_date',
       'ob_discharge_port', 'placement_date', 'placement_to_release',
       'railway_line_id', 'remaining_dist', 'removal_date',
       'removal_to_now', 'stable_complete_date', 'stable_start_date',
       'status_hours', 'total_travelled', 'train_visit_no1',
       'txr_complete_date', 'txr_start_date', 'unload_complete_date',
       'unload_start_date', 'visit_port', 'ib_train_no', 'ob_train_no']]
  #terminal_wagon_dict=terminal_wagon_df.to_dict()
  tm_wg_list = terminal_wagon_df.to_dict('records')
  for terminal_wagon_dict in tm_wg_list:
    for j in range(len(final_df['train_visit_no2'])):
      wagon_details_df = final_df[['wagon_no','wagon_status','teus']]
      #query = f"""select wagon_no,wagon_status,teus from final_df where train_visit_no2 = {0}""".format(int(final_df['train_visit_no2'][j]))
      #wagon_details_df = duckdb.query(query).df()
      #wagon_details_dict = wagon_details_df.to_dict()
      wagon_details_dict =  wagon_details_df.to_dict('records')[j]
      terminal_wagon_dict['train_visit_no2'] = int(final_df['train_visit_no2'][j]) 
      #cont_df = final_df[['wagon_no','cont_no','position','cont_size','cont_status']]
      #final_df['wagon_no'] = final_df['wagon_no'].astype(int)
      #query1 = f"""select cont_no,position,cont_size,cont_status from final_df where wagon_no={0}""".format(wagon_details_dict['wagon_no'])
      #cont_df = duckdb.query(query1).df()
      #cont_dict=cont_df.to_dict()
      # group_df = final_df.groupby('wagon_no').apply(lambda  x: x[['wagon_no','cont_no','position','cont_size','cont_status']])
      #group = cont_df.groupby('wagon_no')
      wagon_no= wagon_details_dict['wagon_no']
      result = str(None)
      try:
          group_wn = group.get_group(wagon_no)
          result = group_wn.drop(columns='wagon_no').to_dict(orient='records')
          wagon_details_dict['continfo'] = result
          terminal_wagon_dict['wagoninfo'] = wagon_details_dict
          terminal_wagon_list.append(terminal_wagon_dict)
      except Exception as e:
          print("does not exist")
        # group_df_filter =  group_df[group_df["wagon_no"] == "{0}".format(wagon_details_dict['wagon_no'])][['cont_no','position','cont_size','cont_status']]
        #group_df_filter.drop('wagon_no',axis=1,inplace=True)
        #cont_list_dict = group_df_filter.to_dict('records')
        #cont_list_dict = cont_df.to_dict('records')
        #if(result != str(None)):
       	  #wagon_details_dict['continfo'] = result
      # print(wagon_details_dict)
  main_dict['schdetails'] = terminal_wagon_list
  main_list.append(main_dict)
print(main_list)
result = json.dumps(main_list)


with open('superapp.json','w') as f:
  json.dump(main_dict,f,indent=4)

"""
final_json=json.dumps(final_dict)
print(final_json)"""





  
"""
df_cont = df[['CONT_NO','POSITION','CONT_SIZE','CONT_STATUS']]




df_cont_dict = df_cont.to_dict('records')"""


"""result = final_df.to_dict('records')


with open('superapp.json','w') as f:
  json.dump(result,f)"""

"""
# Data Cleaning
df[['TRAIN_VISIT_NO','CONT_SIZE']]=df[['TRAIN_VISIT_NO','CONT_SIZE']].fillna(0)
df[['TRAIN_VISIT_NO','CONT_SIZE']]=df[['TRAIN_VISIT_NO','CONT_SIZE']].astype(int)

df = df.applymap(lambda x:str(None) if pd.isna(x) else x)
print(df.head())

result = df.to_dict('records')
result = json.dumps(result)
"""
# Post data To Endpoint

response = requests.request("POST", url, headers=headers, data=result)
print(response.text)
print(response.status_code)



