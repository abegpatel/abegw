import requests

def get_token():
  url = "https://veracityapi.riddhigroup.in/api/api-login"
  payload = {'user_name': 'AdaniCustomerAPI24','password': 'LtAOqZiNGvVEuTY'}
  headers = {'Accept': 'application/json'}
  #try:
  response = requests.request("POST", url, headers=headers, data=payload)
  if (response.status_code == 200):
    token = response.json().get('authorization_key')
    print(token)
  #except Exception as Message:
  #print(Message)
  #print(response.status_code,response.text)
get_token()

