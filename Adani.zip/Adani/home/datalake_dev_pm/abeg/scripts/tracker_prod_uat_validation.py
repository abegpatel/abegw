import pymssql
username = 'trackerach'
password = 'Tr@cker@22'

"""prod_conn = pymssql.connect(
    server='10.112.88.71:443',
    user=username,
    password=password,
    database='trackerNCID')"""
uat_conn = pymssql.connect(
    server='10.112.88.74:1433',
    user=username,
    password=password,
    database='trackerUAT')
print("Connection is Successful")
uat_cursor = uat_conn.cursor()
uat_cursor.execute("select * from bond_accountmas exp_IN")
rows=uat_cursor.fetchall()
for row in rows:
    print(row)
#prod_conn.close()
uat_conn.close()

SELECT COUNT(*) FROM exp_IN;


                 
;WITH notcust AS (SELECT AGID FROM Customer where modifiedon >= DATEADD(DAY,-28,(SELECT CONVERT(DATE,MAX(modifiedon)) FROM Customer)))
SELECT count(*) FROM Customer where AGID NOT IN(SELECT AGID from notcust);

;WITH notexpin AS (SELECT entryID FROM exp_IN where indate >= DATEADD(DAY,-28,(SELECT CONVERT(DATE,MAX(indate)) FROM exp_IN)))
SELECT count(*) FROM exp_IN where entryID NOT IN(SELECT entryID from notexpin);

SELECT count(*) FROM exp_IN where indate >= DATEADD(DAY,-15,(SELECT CONVERT(DATE,MAX(indate)) FROM exp_IN))
