import os
import zipfile

zip_filename = 'myzipfile.zip'
filenames = [
            'Customer_Portal_Order_Booking_Details',
            'Customer_Portal_Invoice_Details',
            'Track_Your_Container_Details'
             ]
current_dir = os.getcwd()

with zipfile.ZipFile(zip_filename,"w") as zipf:
    for filename in os.listdir(current_dir):
        if filename.endswith('.xslx'):
            zipf.write(filename)
    


