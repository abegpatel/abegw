import psycopg2
import sqlalchemy as sql
import pandas as pd
import logging


# Define database connection parameters
hostname = 'apsez-as1-analytics-prod-rds.cpjhdhjkpglj.ap-south-1.rds.amazonaws.com'
username = 'pgadmin'
password = 'Adani$#390'
database = 'analytics'
    

query ="""select * from logistics_prod.riddhi_order_booking_details limit 10;"""
print(query)
conn = psycopg2.connect(dbname=database, host=hostname, port=5432, user=username, password=password, sslmode='require')
cur_pg = conn.cursor(cursor_factory = psycopg2.extras.RealDictCursor)
# print(query%cntr_nos)
try:
    cur_pg.execute(query)
    result = cur_pg.fetchall()
    print(result)
except Exception as e:
    print("Error: {0}".format(e))
    raise Exception('"ExecutionError": "Please contact API Developer"')


"""query1 = '''
ALTER TABLE logistics_prod.riddhi_order_booking_details
ADD COLUMN cha VARCHAR(255)
ADD COLUMN cha_ref_code VARCHAR(255)
ADD COLUMN exporter_name VARCHAR(255)
ADD COLUMN exporter_ref_code VARCHAR(255)
ADD COLUMN agent_name VARCHAR(255)
ADD COLUMN agent_ref_code VARCHAR(255)''''"""




#print(PG_CONN(task='query',query=update_columns_order_booking_query,tgt_connection_string=cloud_sql_pg_prod))
#df=PG_CONN(task='dataframe',query=update_columns_order_booking_query,tgt_connection_string=cloud_sql_pg_prod)
#print(df.head())
