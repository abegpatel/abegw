import functions_framework
import pandas as pd
import numpy as np
import networkx as nx
from pytz import timezone
from ortools.sat.python import cp_model # pip install ortools
import time as tme
import heapq
import warnings
warnings.simplefilter("ignore")
from datetime import datetime, timedelta
from itertools import groupby
from google.cloud import bigquery
from google.cloud import storage
import json
from typing import Any
from urllib.parse import unquote
import base64




# pd.set_option('display.max_rows', 500)
# pd.set_option('display.max_columns', 500)
# pd.set_option('display.width', 1000)


@functions_framework.cloud_event
def rail_route_optimizer_generate(cloud_event):
    import pandas as pd
    import numpy as np
    import networkx as nx
    from pytz import timezone
    from ortools.sat.python import cp_model # pip install ortools
    import time as tme
    import heapq
    import warnings
    warnings.simplefilter("ignore")
    from datetime import datetime, timedelta
    import datetime as dt
    from itertools import groupby
    from google.cloud import bigquery
    from google.cloud import storage
    import json
    from typing import Any
    from urllib.parse import unquote
    import base64

    project = 'apsez-svc-prod-datalake' # Project ID inserted based on the query results selected to explore
    location = 'asia-south1' # Location inserted based on the query results selected to explore
    client = bigquery.Client(project=project, location=location)
    print("cloud event : : ",cloud_event)
    message = base64.b64decode(cloud_event.data["message"]["data"]).decode()
    print("message = ",message,"\n",json.loads(message))
    email = json.loads(message)['adid']
    try:
      if json.loads(message)['recalculate'].lower() == 'true':
        recalculate = True
        dct = json.loads(message)['recalculate_data']
        final_df_changed = pd.DataFrame.from_dict(dct)
        final_df_changed['currtrp_eta'] = pd.to_datetime(final_df_changed['currtrp_eta'])
        final_df_changed['load_ts'] = pd.to_datetime(final_df_changed['load_ts'])
        final_df_changed['opt_start_time'] = pd.to_datetime(final_df_changed['opt_start_time'])
        final_df_changed['opt_end_time'] = pd.to_datetime(final_df_changed['opt_end_time']) 
        final_df_changed.columns = final_df_changed.columns.str.lower()
        final_df_changed['recalculate'] = final_df_changed['recalculate'].fillna(value=0)
        final_df_changed.recalculate=final_df_changed.recalculate.astype(int)
        final_df_changed=final_df_changed[['recalculate','rake_name', 'current_trip', 'currtrp_eta', 'rake_status', 'next_trip_trip1', 'af_1', 'status_flag_trip1', 'af_2', 'status_flag_trip2', 'pendency', 'teus_trip1', 'next_trip_trip2', 'teus_trip2', 'loaded_teus_evacuated_20_trip1', 'loaded_teus_evacuated_40_trip1', 'empty_teus_evacuated_20_trip1', 'empty_teus_evacuated_40_trip1', 'loaded_teus_evacuated_20_trip2', 'loaded_teus_evacuated_40_trip2', 'empty_teus_evacuated_20_trip2', 'empty_teus_evacuated_40_trip2', 'unts', 'base_depot_code','txr_due_date', 'txr_kmsrem_currdest']]
        final_df_changed["loaded_teus_evacuated_20_trip1"]=pd.to_numeric(final_df_changed["loaded_teus_evacuated_20_trip1"], errors='coerce').fillna(0).astype('int64')
        final_df_changed["loaded_teus_evacuated_40_trip1"]=pd.to_numeric(final_df_changed["loaded_teus_evacuated_40_trip1"], errors='coerce').fillna(0).astype('int64')
        final_df_changed["empty_teus_evacuated_20_trip1"]=pd.to_numeric(final_df_changed["empty_teus_evacuated_20_trip1"], errors='coerce').fillna(0).astype('int64')
        final_df_changed["empty_teus_evacuated_40_trip1"]=pd.to_numeric(final_df_changed["empty_teus_evacuated_40_trip1"], errors='coerce').fillna(0).astype('int64')
        final_df_changed["teus_trip1"]=pd.to_numeric(final_df_changed["teus_trip1"], errors='coerce').fillna(0).astype('int64')
      else:
        recalculate = False
    except Exception as e:
      print("Recalculate parameter not found \n", e)
      recalculate = False
    #warnings.filterwarnings("ignore")
    #pd.set_option('display.max_rows', 500)
    #pd.set_option('display.max_columns', 500)
    #pd.set_option('display.width', 500)

    opt_start_time = datetime.now(timezone("Asia/Kolkata")).strftime('%Y-%m-%d %H:%M:%S')
    today, now = datetime.today().strftime("%Y-%m-%d"), datetime.now(timezone("Asia/Kolkata")).strftime('%Y-%m-%d %H:%M:%S')
    today_filename = datetime.today().strftime("%d%m%Y")
    print(today, now, today_filename)

    ''' if recalculate:
      del_query_recalculate= """delete from apsez-svc-prod-datalake.logistics_cleansed.layer2_route_optimization_plan_api where optimization_type = 'generic' and email = '{0}' and status = 'Recalculated'""".format(email)
      del_job_recalculate = client.query(del_query_recalculate)
      del_job_recalculate.result() '''

    del_query = """delete from apsez-svc-prod-datalake.logistics_cleansed.layer2_route_optimization_plan_api where optimization_type = 'generic' and email = '{0}' and status = 'Generated'""".format(email)
    del_job = client.query(del_query)
    del_job.result()

    ##################################################################################################################
    # APSEZ ANALYTICS CODE BEGINS
    ##################################################################################################################
    ###############################################################################################################

    try:
      


      
      #################################### DATA COLLECTION AND PREPARATION ############################################

      ##################################################################################################################
      # FORECAST DATA PREPATATION
      ##################################################################################################################

      # Manual forecast data for forecast pendency
      query_lmf="""select * from logistics_cleansed.layer2_locc_manual_forecast"""
      query_job_rd=client.query(query_lmf).result()
      forecast_pend1 = query_job_rd.to_dataframe()
      forecast_pend = forecast_pend1.copy()
      forecast_pend.rename(columns = {"POD":"booking_location_code","Final_Destination":"to_terminal_code"}, inplace = True)
      forecast_pend = forecast_pend[forecast_pend.booking_location_code != "POD"]
      # split data by 20 feet and 40 feet containers and change data in same schema as pendency data
      forecast_pend["Count_of_20"]=pd.to_numeric(forecast_pend["Count_of_20"], errors='coerce').fillna(0).astype('int64')
      forecast_pend["Count_of_40"]=pd.to_numeric(forecast_pend["Count_of_40"], errors='coerce').fillna(0).astype('int64')
      #forecast_pend[["Count_of_20","Count_of_40"]] = forecast_pend[["Count_of_20","Count_of_40"]].astype('int64')
      # converting 40-feeter units to TEUs
      forecast_pend["Count_of_40"] = forecast_pend["Count_of_40"] * 2

      # ODR DAYS and ETA
      forecast_pend['odr_days'] = forecast_pend['ETA']
      forecast_pend.odr_days = forecast_pend.odr_days.str.replace('/','-',regex=True)
      forecast_pend.odr_days = pd.to_datetime(forecast_pend['odr_days'], format = '%Y-%m-%d %H:%M:%S', errors = 'coerce')
      forecast_pend.odr_days = pd.to_datetime(forecast_pend.odr_days).dt.strftime('%Y-%m-%d')
      forecast_pend['ETA'] = forecast_pend['odr_days']
      forecast_pend = forecast_pend.dropna(subset = ['odr_days'])
      forecast_pend = forecast_pend.dropna(subset = ['ETA'])
      forecast_pend.sort_values(by = ["odr_days"], ascending = False, inplace = True)
      forecast_pend.odr_days = (pd.to_datetime(forecast_pend.odr_days) - pd.to_datetime(today)).dt.days
      forecast_pend['ETA'] = pd.to_datetime(forecast_pend['ETA'], format = '%Y-%m-%d', errors = 'coerce').dt.strftime('%d/%m/%Y')

      # consider forecast data from tomorrow (as today's data is included in pendency) until 7th day (for a week)
      # same schema as pendency data
      forecast_pend = forecast_pend[(forecast_pend.odr_days >= 1) & (forecast_pend.odr_days <= 7)][["booking_location_code","to_terminal_code","odr_days","Count_of_20","Count_of_40","ETA"]].reset_index(drop = True)
      forecast_pend.groupby(["booking_location_code","to_terminal_code","odr_days","ETA"])[["Count_of_20","Count_of_40"]].sum().reset_index()
      forecast_pend_20 = forecast_pend[["booking_location_code","to_terminal_code","odr_days","Count_of_20","ETA"]]
      forecast_pend_20["cont_size"] = 20.0
      forecast_pend_20.rename(columns = {"Count_of_20":"pendency"}, inplace = True)
      forecast_pend_40 = forecast_pend[["booking_location_code","to_terminal_code","odr_days","Count_of_40","ETA"]]
      forecast_pend_40["cont_size"] = 40.0
      forecast_pend_40.rename(columns = {"Count_of_40":"pendency"}, inplace = True)
      forecast_pend = pd.concat([forecast_pend_20,forecast_pend_40]).reset_index(drop = True)
      forecast_pend.groupby(["booking_location_code","to_terminal_code","odr_days","ETA"])[["pendency"]].sum().reset_index()
      forecast_pend["empty_pendency"] = 0
      forecast_pend = forecast_pend[["pendency","empty_pendency","booking_location_code","to_terminal_code","odr_days","cont_size","ETA"]]
      forecast_pend = forecast_pend.groupby(["booking_location_code",
                                            "to_terminal_code",
                                            "cont_size",
                                            "odr_days","ETA"]).agg({"pendency":"sum",
                                                                "empty_pendency":"sum"}).reset_index()
      forecast_pend = forecast_pend[~((forecast_pend.pendency==0) & (forecast_pend.empty_pendency==0))].reset_index(drop = True)
      forecast_pend.sort_values(by = ["booking_location_code","to_terminal_code","odr_days","ETA"], ascending = True, inplace = True)
      forecast_pend_copy = forecast_pend.copy()
      # forecast_pend

      #################################### DATA COLLECTION AND PREPARATION ############################################

      ################################################################################
      # For Distance Data- Loading BigQuery data for Route Details
      ################################################################################

      # logistics_cleansed.layer2_route_sla_mst - Route Master
      # logistics_cleansed.layer2_terminal_master - Terminal Master

      query_rd="""select coalesce(og_map.fois, origin_code) as origin_code, coalesce(to_map.fois, destination_code) destination_code, route, rational_distance, critical_non_critical, ss_ds, r_tat_sla, t_tat_sla, closed_rt, active_rt
      from `logistics_cleansed.layer2_route_sla_mst` rsm
      left join (select terminal_code, fois from `logistics_cleansed.layer2_terminal_master` qualify row_number() over(partition by terminal_code)  = 1 ) og_map on og_map.terminal_code = rsm.origin_code
      left join (select terminal_code, fois from `logistics_cleansed.layer2_terminal_master` qualify row_number() over(partition by terminal_code)  = 1 ) to_map on to_map.terminal_code = rsm.destination_code"""
      query_job_rd=client.query(query_rd).result()
      route_details = query_job_rd.to_dataframe()
      route_details.drop(columns = ["critical_non_critical","route"], inplace = True)
      route_details = route_details[(route_details.origin_code.notnull()) | (route_details.destination_code.notnull())]
      route_details.t_tat_sla = route_details.t_tat_sla.fillna(0)
      route_details[['closed_rt','active_rt']] = route_details[['closed_rt','active_rt']].astype(int).round(0)
      # t_tat_sla is given at origin
      # Don't remove t_tat_sla_origin null terminals as they could be base terminals but with 0 pendency
      route_details.rename(columns = {"t_tat_sla":"t_tat_sla_origin"},inplace = True)
      route_details[['rational_distance','t_tat_sla_origin','r_tat_sla']] = route_details[['rational_distance','t_tat_sla_origin','r_tat_sla']].astype('float64').round(0)
      # Fill null ss_ds with "SS" to avoid any error
      route_details.ss_ds = route_details.ss_ds.fillna("SS")
      route_details = route_details.drop_duplicates(subset = ["origin_code","destination_code"], keep = 'first').reset_index(drop = True)

      # update t_tat_sla for origin
      for i in range(len(route_details)):
        if route_details.loc[i,"rational_distance"] != 0:
          route_details.loc[i,"t_tat_sla_origin"] = 12

      route_details_t_tat = route_details[["origin_code","t_tat_sla_origin"]].drop_duplicates(subset = ["origin_code"], keep = "first").reset_index(drop = True)

      # create t_tat_sla for destination
      route_details.t_tat_sla_destination = float()
      for i in range(len(route_details)):
          for j in range(len(route_details_t_tat)):
              if route_details.loc[i,"destination_code"] == route_details_t_tat.loc[j,"origin_code"]:
                  route_details.loc[i,"t_tat_sla_destination"] = float(route_details_t_tat.loc[j,"t_tat_sla_origin"])

      # update t_tat_sla for origin
      for i in range(len(route_details)):
        if route_details.loc[i,"rational_distance"] != 0:
          route_details.loc[i,"t_tat_sla_destination"] = 12

      selected_locations = route_details[route_details.active_rt == 1].reset_index(drop = True)

      distance_data = selected_locations.drop_duplicates(subset = ['origin_code','destination_code'],keep = "first").reset_index(drop = True)
      distance_data_copy = distance_data.copy()

      ##################################################################################
      # For Current Status of the trains- Loading BigQuery data for Train Current Status
      ##################################################################################



      query_t= """select a.*,b.bpc_valid_to,b.remaining_dist,c.base_depot_code, arp.Loaded_Teus_20, arp.Loaded_Teus_40, arp.Empty_Teus_20, arp.Empty_Teus_40,  prev_origin,  prev_dest from logistics_semantic.layer4_bt_rake_running_status_snap_hourly_vw as a
                  left join logistics_semantic.layer4_rt_all_rake_txr_details_mv as b on (a.rake_name=b.rake_name)
                  left join logistics_semantic.layer4_rake_master_vw as c on (a.rake_name=c.rake_name)
                  left join (select rr.ob_train_no, apr.rr_paid_by, sum(case when rr.cont_size  = '20' and cont_status = 'L' then 1 else 0 end) Loaded_Teus_20,
                  sum(case when rr.cont_size  = '40' and cont_status = 'L' then 2 else 0 end) Loaded_Teus_40, sum(case when rr.cont_size  = '20' and cont_status = 'E' then 1 else 0 end) Empty_Teus_20,
                  sum(case when rr.cont_size  = '40' and cont_status = 'E' then 2 else 0 end) Empty_Teus_40 from `logistics_semantic.layer4_rt_rail_report_mv` rr
                  right join `logistics_semantic.layer4_rt_all_rail_performance_mv` apr on apr.train_visit_no = rr.train_visit_no
                  group by rr.ob_train_no, rr_paid_by) arp on arp.ob_train_no = a.ob_train_no
                  left join (select ob_train_no, visit_port prev_origin, ob_discharge_port prev_dest from `logistics_semantic.layer4_rt_all_rail_performance_mv`) ib on a.ib_trAIN_NO = IB.OB_TRAIN_NO"""
      query_job_t = client.query(query_t).result()
      rcs = query_job_t.to_dataframe()
      rcs = rcs[rcs.bu.isin(['ALSPL', 'ALL'])]

      #######
      # to find previous trips of at-terminal rakes
      atTrakes_prev_terminals = rcs.copy()
      all_locs = list(set(set(distance_data.origin_code)|set(distance_data.destination_code)))
      query_tm="""select * from logistics_cleansed.layer2_terminal_master"""
      query_job_rd=client.query(query_tm).result()
      terminal_master = query_job_rd.to_dataframe()
      terminal_master.terminal_name = terminal_master.terminal_name.str.upper()
      terminal_master = terminal_master[['terminal_code','fois']]
      terminal_master.drop_duplicates(subset = 'terminal_code', keep = 'first', inplace = True)
      terminal_code_dict = dict(terminal_master.values)
      atTrakes_prev_terminals = atTrakes_prev_terminals[atTrakes_prev_terminals.rake_status == "AT TERMINAL"][['crntdvsn', 'crntsttn', 'rake_name', 'rake_status', 'prev_origin', 'prev_dest']].reset_index(drop = True)
      for rakes in range(len(atTrakes_prev_terminals)):
        prev_origin = atTrakes_prev_terminals.loc[rakes,"prev_origin"]
        prev_dest = atTrakes_prev_terminals.loc[rakes,"prev_dest"]
        if prev_origin not in all_locs:
          try:
            atTrakes_prev_terminals.loc[rakes,"prev_origin"] = terminal_code_dict[prev_origin]
          except:
            atTrakes_prev_terminals.loc[rakes,"prev_origin"] = prev_origin
        if prev_dest not in all_locs:
          try:
            atTrakes_prev_terminals.loc[rakes,"prev_dest"] = terminal_code_dict[prev_dest]
          except:
            atTrakes_prev_terminals.loc[rakes,"prev_dest"] = prev_dest
      atTrakes_prev_terminals_copy = atTrakes_prev_terminals.copy()
      #######

      # drop columns that are not required
      rcs.drop(columns = ["actual_running_hrs","departure_delay","examtype","operation_delay_flag","operation_time","stable_flag","stable_since","sttschngtime","trans_flag","congestion_alert"],inplace = True)
      # # Uncomment this for all trains
      # selected_train_cs = rcs[(rcs.rake_status == 'IN-TRANSIT') | ((rcs.rake_status == 'AT TERMINAL') & (rcs.ob_t.isna()))]
      selected_train_cs = rcs[(rcs.rake_status == 'IN-TRANSIT') | (rcs.rake_status == 'AT TERMINAL')]

      # selected trains where wagons is not "-" (Only in-transit vehicles are considered). Take 45 unts by default if no. of wagons in rake is missing
      selected_train_cs.unts = selected_train_cs.unts.fillna(45)
      selected_train_cs["eta"] = pd.to_datetime(selected_train_cs["eta"])
      # selected_train_cs.drop(columns = ["actual_departure","address","bu","cmdt","cnsg","cnsr","crntdvsn","crntdvsn","destination_name",'fnr','fois_location', 'gps_tracker_flag', 'ist_timestamp', 'latitude','leflag', 'loadid', 'loadstts', 'loadtype', 'loco', 'longitude', 'ob_r','ob_t', 'ob_train_no', 'origin_name','sequence','rnk','remaining_kms','crntsttn','remaining_kms','rnk','source','running_delay','trans_flag_calc','refg_flag_calc','ref_flag','rakeid','rakeownr'], inplace = True)
      selected_train_cs.drop(columns = ["actual_departure","address","bu","cmdt","cnsg","cnsr","crntdvsn","crntdvsn","destination_name",'fnr','fois_location', 'gps_tracker_flag', 'ist_timestamp', 'latitude','leflag', 'loadid', 'loadstts', 'loadtype', 'loco', 'longitude', 'origin_name','sequence','rnk','remaining_kms','crntsttn','remaining_kms','rnk','source','running_delay','trans_flag_calc','refg_flag_calc','ref_flag','rakeid','rakeownr'], inplace = True)

      selected_train_cs.rename(columns = {"sttnfrom":"origin_code","sttnto":"destination_code","bpc_valid_to":"TXR_Due_Date","remaining_dist":"TXR_Kms_Remaining","eta":"FOIS_ETA", "actual_arrval_date":"actual_arrival"}, inplace = True)
      selected_train_cs1 = selected_train_cs.merge(route_details[["origin_code","destination_code","rational_distance","ss_ds","t_tat_sla_destination"]],on = ["origin_code","destination_code"],how = "left").reset_index(drop = True)
      selected_train_cs1[["t_tat_sla_destination","t_tat_sla","unts"]] = selected_train_cs1[["t_tat_sla_destination","t_tat_sla","unts"]].fillna(12)
      selected_train_cs1[["t_tat_sla_destination","rational_distance","t_tat_sla"]] = selected_train_cs1[["t_tat_sla_destination","rational_distance","t_tat_sla"]].astype('float64').round(0)
      selected_train_cs1['TXR_Due_Date'] = pd.to_datetime(selected_train_cs1['TXR_Due_Date']).dt.date

      # selected trains next available time (FOIS ETA + operation time at destination) or (+ 6 days), our algorithm is supposed to schedule its txr trip by itself
      # next_availability = FOIS ETA
      selected_train_cs1["t_tat_sla_destination"] = selected_train_cs1["t_tat_sla_destination"].fillna(0)

      # If a train doesn't have an arrival date then the train must not be scheduled for it's next trip
      selected_train_cs1.FOIS_ETA = selected_train_cs1.FOIS_ETA.fillna(selected_train_cs1.actual_arrival)
      selected_train_cs1["FOIS_ETA"] = pd.to_datetime(selected_train_cs1["FOIS_ETA"]).apply(lambda x: x.strftime('%Y-%m-%d %H:%M:%S'))
      # # only select trains which are in-transit within 24 hours from now.
      selected_train_cs2 = selected_train_cs1[((pd.to_datetime(selected_train_cs1["FOIS_ETA"]) >= pd.to_datetime(now) - pd.Timedelta(hours = 1)) & (pd.to_datetime(selected_train_cs1["FOIS_ETA"]) <= pd.to_datetime(now) + pd.Timedelta(hours = 25)))|((selected_train_cs1["rake_status"] == "PARKED"))|((selected_train_cs1["rake_status"] == "AT TERMINAL"))].reset_index(drop = True)
      selected_train_cs2.destination_code = selected_train_cs2.destination_code.fillna(selected_train_cs2.origin_code)
      selected_train_cs2 = selected_train_cs2.drop_duplicates(subset = ['rake_name','origin_code','destination_code'],keep = "first").reset_index(drop = True)

      # To reduce pendency for trains that carry TEUs in current trip
      selected_train_cs2[["Loaded_Teus_20","Loaded_Teus_40","Empty_Teus_20","Empty_Teus_40"]] = selected_train_cs2[["Loaded_Teus_20","Loaded_Teus_40","Empty_Teus_20","Empty_Teus_40"]].fillna(0).astype(int)

      # consider to reduce TEUs only for the rakes which are present at terminal and loaded with TEUs already, hence, to manage data, make these values for rakes which are "in-transit"
      selected_train_cs2.loc[(selected_train_cs2.rake_status != "AT TERMINAL"), ["Loaded_Teus_20","Loaded_Teus_40","Empty_Teus_20","Empty_Teus_40"]] = 0,0,0,0
      ob_not_booked_rakes = selected_train_cs2.copy()

      # Remove the ob trains which are already booked from being scheduled (trains which are at terminal - origin and destination available - don't plan and subtract TEUs)
      # for any "at-terminal" rake if ob_number is available (means it's booked/scheduled) then dont consider for scheduling via optimizer.
      ob_not_booked_rakes = ob_not_booked_rakes[((ob_not_booked_rakes.ob_train_no.isna()) & (ob_not_booked_rakes.rake_status == "AT TERMINAL"))|((ob_not_booked_rakes.rake_status == "IN-TRANSIT"))].reset_index(drop = True)

      train_current_status = ob_not_booked_rakes.reset_index(drop = True)
      train_current_status_copy = train_current_status.copy()
      train_current_status_copy

      ################################################################################
      # For Pendency Data- Loading BigQuery data for Pendency
      ################################################################################

      query_p = """ select distinct * from
      (select pendency_loaded, pendency_empty, og_map.fois as booking_location_code, to_map.fois to_terminal_code, odr_days, cont_size from
      (select sum(case when pendency_type = 'LOADED' and cont_size = 20 then 1 when pendency_type = 'LOADED' and cont_size = 40 then 2 else 0 end) pendency_loaded, sum(case when pendency_type = 'EMPTY' and cont_size = 20 then 1 when pendency_type = 'EMPTY' and cont_size = 40 then 2 else 0 end) pendency_empty, booking_location_code, to_terminal_code, round(max_age/24) odr_days, cont_size from
      (SELECT *, max(aging_in_hrs) over(partition by booking_location_code, to_terminal_code) max_age,
      CASE WHEN cont_size = 20 AND movement_types = 'EMPTY' AND status = 'AWAITING RAILMENT' AND all_empty_flag = 0 AND bu = 'ALL' THEN 'ALL EMPTY'
      WHEN cont_size = 40 AND movement_types = 'EMPTY' AND status = 'AWAITING RAILMENT' AND all_empty_flag = 0 AND bu = 'ALL' THEN 'ALL EMPTY'
      WHEN cont_size = 20 AND movement_types = 'EMPTY' AND status = 'AWAITING RAILMENT' THEN 'EMPTY'
      WHEN cont_size = 40 AND movement_types = 'EMPTY' AND status = 'AWAITING RAILMENT' THEN 'EMPTY'
      WHEN cont_size = 20 AND movement_types = 'EMPTY' AND status = 'INTRANSIT HUB PENDENCY' THEN 'EMPTY (HUB)'
      WHEN cont_size = 40 AND movement_types = 'EMPTY' AND status = 'INTRANSIT HUB PENDENCY' THEN 'EMPTY (HUB)'
      WHEN cont_size = 20 AND movement_types = 'LOADED' AND status = 'AWAITING RAILMENT' THEN 'LOADED'
      WHEN cont_size = 40 AND movement_types = 'LOADED' AND status = 'AWAITING RAILMENT' THEN 'LOADED'
      WHEN cont_size = 20 AND movement_types = 'LOADED' AND status = 'INTRANSIT HUB PENDENCY' THEN 'LOADED (HUB)'
      WHEN cont_size = 40 AND movement_types = 'LOADED' AND status = 'INTRANSIT HUB PENDENCY' THEN 'LOADED (HUB)'
      WHEN cont_size = 20 AND movement_types = 'HOLD' AND status = 'AWAITING RAILMENT' THEN 'ON HOLD'
      WHEN cont_size = 40 AND movement_types = 'LOADED' AND status = 'AWAITING RAILMENT' THEN 'ON HOLD' ELSE 'OTHERS' END AS pendency_type FROM
      (SELECT Movement_Type, status, cont_no, cont_size, booking_no, booking_ref_code, customer, booking_location,  current_location, to_terminal, COALESCE(fois, to_terminal_code) AS to_terminal_code,  COALESCE(bk.bk_fois, booking_location_code) AS booking_location_code,route, aging_in_hrs, container_status_start_date, book_date, train_no, rake_name, transport_by,  monthyear,  bu,  mov_type,  load_date, location, movement_types,  Driven_BU,  0 AS all_empty_flag FROM
      (SELECT Movement_Type, UPPER(status) AS status, cont_no, cont_size, booking_no, booking_ref_code, customer, booking_location, current_location, to_terminal, to_terminal_code, booking_location_code, route, aging_in_hrs, container_status_start_date, book_date, train_no, rake_name, transport_by, monthyear, bu, mov_type, load_date, location, CASE WHEN Movement_Type = 'Empty' THEN 'EMPTY' WHEN Movement_Type = 'Hold' THEN 'HOLD' ELSE 'LOADED' END AS movement_types,
      CASE WHEN UPPER(booking_location_code) IN ( SELECT terminal_code FROM apsez-svc-prod-datalake.logistics_cleansed.layer2_gpwis_terminal_mst ) OR UPPER(to_terminal_code) IN ( SELECT terminal_code FROM apsez-svc-prod-datalake.logistics_cleansed.layer2_gpwis_terminal_mst ) THEN 'GPWIS' ELSE 'ALL+ALSPL' END AS Driven_BU, 0 AS all_empty_flag FROM apsez-svc-prod-datalake.logistics_semantic.layer4_rt_rail_pendency_mv a WHERE load_date = ( SELECT MAX(load_date) FROM apsez-svc-prod-datalake.logistics_semantic.layer4_rt_rail_pendency_mv )
      AND booking_location <> to_terminal AND book_date >= '2021-04-01' AND customer LIKE '%ADANI LOGISTICS LTD.%' AND Movement_Type = 'Empty'
      UNION DISTINCT
      SELECT Movement_Type, UPPER(status) AS status, cont_no, cont_size, booking_no, booking_ref_code, customer, booking_location, current_location, to_terminal, to_terminal_code, CASE WHEN status = 'Intransit Hub Pendency' THEN current_location ELSE booking_location_code END, route, aging_in_hrs, container_status_start_date, book_date, train_no, rake_name, transport_by, monthyear, bu, mov_type, load_date, location, CASE WHEN Movement_Type = 'Empty' THEN 'EMPTY' WHEN Movement_Type = 'Hold' THEN 'HOLD' ELSE 'LOADED' END AS movement_types,
      CASE WHEN UPPER(booking_location_code) IN ( SELECT terminal_code FROM apsez-svc-prod-datalake.logistics_cleansed.layer2_gpwis_terminal_mst ) OR UPPER(to_terminal_code) IN (SELECT terminal_code FROM apsez-svc-prod-datalake.logistics_cleansed.layer2_gpwis_terminal_mst ) THEN 'GPWIS' ELSE 'ALL+ALSPL' END AS Driven_BU, 1 AS all_empty_flag FROM apsez-svc-prod-datalake.logistics_semantic.layer4_rt_rail_pendency_mv b WHERE load_date = ( SELECT MAX(load_date) FROM apsez-svc-prod-datalake.logistics_semantic.layer4_rt_rail_pendency_mv )
      AND booking_location <> to_terminal AND book_date >= '2021-04-01' AND customer NOT LIKE '%ADANI LOGISTICS') x LEFT JOIN ( SELECT * FROM ( SELECT terminal_code, fois, ROW_NUMBER() OVER (PARTITION BY terminal_code) AS rnk FROM apsez-svc-prod-datalake.logistics_cleansed.layer2_terminal_master) x WHERE rnk = 1 ) tm ON x.to_terminal_code = tm.terminal_code LEFT JOIN ( SELECT * FROM ( SELECT terminal_code as bk_tcode, fois as bk_fois, ROW_NUMBER() OVER (PARTITION BY terminal_code) AS rnk FROM apsez-svc-prod-datalake.logistics_cleansed.layer2_terminal_master ) x WHERE rnk = 1 ) bk ON x.booking_location_code = bk.bk_tcode)
      ) where status in ('AWAITING RAILMENT', 'INTRANSIT HUB PENDENCY') and pendency_type in ('LOADED', 'EMPTY')
      group by  booking_location_code, to_terminal_code, max_age, cont_size) a
      left join (select terminal_code, fois from `logistics_cleansed.layer2_terminal_master` qualify row_number() over(partition by terminal_code)  = 1 ) og_map on og_map.terminal_Code = booking_location_code
      left join (select terminal_code, fois from `logistics_cleansed.layer2_terminal_master` qualify row_number() over(partition by terminal_code)  = 1 ) to_map on to_map.terminal_Code = to_terminal_code
      right join (select coalesce(og_map.fois, origin_code) as origin_code, coalesce(to_map.fois, destination_code) destination_code, route, rational_distance, critical_non_critical, ss_ds, r_tat_sla, t_tat_sla  from `logistics_cleansed.layer2_route_sla_mst` rsm
      left join (select terminal_code, fois from `logistics_cleansed.layer2_terminal_master` qualify row_number() over(partition by terminal_code)  = 1 ) og_map on og_map.terminal_code = rsm.origin_code
      left join (select terminal_code, fois from `logistics_cleansed.layer2_terminal_master` qualify row_number() over(partition by terminal_code)  = 1 ) to_map on to_map.terminal_code = rsm.destination_code) sla on sla.origin_code = og_map.fois and sla.destination_code = to_map.fois)x where (pendency_loaded is not null or pendency_empty is not null)"""
      query_job_p=client.query(query_p).result()
      pendency = query_job_p.to_dataframe()
      pendency.rename(columns = {"pendency_loaded":"pendency","pendency_empty":"empty_pendency"}, inplace = True)
      pendency.empty_pendency = pendency.empty_pendency.fillna(0)
      pendency[['pendency','empty_pendency']] = pendency[['pendency','empty_pendency']].astype(int)
      pendency = pendency[["pendency","empty_pendency","booking_location_code","to_terminal_code","odr_days","cont_size"]].reset_index(drop = True)
      selected_pendency = pendency.copy()
      ###
      # Reduce pendency for ob number created as per 20 or 40 split
      pendency_minus = selected_train_cs2[["origin_code","destination_code","Loaded_Teus_20","Loaded_Teus_40","Empty_Teus_20","Empty_Teus_40"]]
      pendency_minus = pendency_minus[(pendency_minus.Loaded_Teus_20 > 0) | (pendency_minus.Loaded_Teus_40 > 0) | (pendency_minus.Empty_Teus_20 > 0) | (pendency_minus.Empty_Teus_40 > 0)].reset_index(drop = True)
      pendency_minus_20 = pendency_minus[(pendency_minus.Loaded_Teus_20 > 0) | (pendency_minus.Empty_Teus_20 > 0)][["origin_code","destination_code","Loaded_Teus_20","Empty_Teus_20"]]
      pendency_minus_20.rename(columns = {"Loaded_Teus_20":"pendency", "Empty_Teus_20":"empty_pendency"}, inplace = True)
      pendency_minus_20["cont_size"] = 20.0
      pendency_minus_40 = pendency_minus[(pendency_minus.Loaded_Teus_40 > 0) | (pendency_minus.Empty_Teus_40 > 0)][["origin_code","destination_code","Loaded_Teus_40","Empty_Teus_40"]]
      pendency_minus_40.rename(columns = {"Loaded_Teus_40":"pendency", "Empty_Teus_40":"empty_pendency"}, inplace = True)
      pendency_minus_40["cont_size"] = 40.0
      pendency_minus = pd.concat([pendency_minus_20,pendency_minus_40]).reset_index(drop = True)
      pendency_minus = pendency_minus.groupby(["origin_code","destination_code","cont_size"]).agg({"pendency":"sum","empty_pendency":"sum"}).reset_index()
      pendency_minus["pendency"] = (-1)*pendency_minus["pendency"]
      pendency_minus[["odr_days","flag"]] = 1, 1
      pendency_minus["empty_pendency"] = (-1)*pendency_minus["empty_pendency"]
      pendency_minus.rename(columns = {"origin_code":"booking_location_code","destination_code":"to_terminal_code"}, inplace = True)
      pendency_minus = pendency_minus[['pendency', 'empty_pendency', 'booking_location_code', 'to_terminal_code', 'odr_days', 'cont_size', 'flag']]
      pendency_data11 = pd.concat([selected_pendency,pendency_minus])
      pendency_data = pendency_data11.groupby(["booking_location_code","to_terminal_code","cont_size"]).agg({"pendency":"sum", "empty_pendency":"sum", "odr_days":"max"}).reset_index()
      ###
      # Current pendency data is past, so odr is negative, for forecasted pendency, odr will be in positive.Negative odr pendency will always be given more priority.
      pendency_data.odr_days = (-1)*pendency_data.odr_days
      pendency_data = pendency_data[(pendency_data.pendency > 0) | (pendency_data.empty_pendency > 0)]
      # pendency_data = pd.concat([pendency_data,forecast_pend]).reset_index(drop = True)
      pendency_data_copy = pendency_data.copy()

      ################################################################################
      # For Via Route Data- Loading BigQuery data for Via Route
      ################################################################################
      # There are some base which mandatorily go through some via terminals (route_type = "Maintenance")
      # There are some terminals which are hub-terminals, the containers are dropped at hub terminals (route_type = "Transhipment-Hub") then taken to the destination, in such cases, destination_code is updated to hub terminal name (present in via column) and optimizer is run again
      # There are some terminals which fall in between origin and destination (route_type = "Transhipment-Indirect"), such terminals are yet to be dealt with

      query_v = """select distinct * from logistics_master.layer2_via_route_master"""
      query_job_v=client.query(query_v).result()
      via_rt = query_job_v.to_dataframe()
      via_rt.rename(columns = {"source":"origin_code","destination":"destination_code"}, inplace = True)
      via_rt = via_rt.groupby(['origin_code','destination_code','route_type']).via.agg([('via','/'.join)]).reset_index()
      via_rt["route"] = via_rt["origin_code"] + "-" + via_rt["destination_code"]
      via_rt["via_route"] = via_rt["origin_code"] + "-" + via_rt["via"] + "-" + via_rt["destination_code"]


      # ALL FUNCTIONS
      ###
      ###############################################################################################################################################################################
      # Convert time to minutes (ex: 0 days 08:30:03 to 485 minutes)
      ###############################################################################################################################################################################
      def day_time_to_min(day_time):
        duration_str = str(day_time).split()
        days = int(duration_str[0])
        hours_minutes_seconds = list(map(int, duration_str[-1].split(":")))
        hours,minutes,seconds = hours_minutes_seconds[0], hours_minutes_seconds[1], hours_minutes_seconds[2]
        try:
          s = int(seconds/minutes)
        except:
          s = 0
        total_minutes = days*24*60 + hours*60 + minutes + s
        return total_minutes
      ###############################################################################################################################################################################
      # Update schedules from df
      ###############################################################################################################################################################################
      def concat_outputs(df1_1):
        # Concat output for all scheduled trains and unscheduled trains
        df1 = df1_1.copy().reset_index(drop = True)
        if len(df1) > 0:
          df1["Pend"] = df1["Pend"].apply(lambda x: ','.join(map(str, x)))
          df1["Evacuated"] = df1["Evacuated"].apply(lambda x: ','.join(map(str, x)))
          df1["odr_days"] = df1["odr_days"].apply(lambda x: ','.join(map(str, x)))
          df1[["Pendency_20","Pendency_40","Empties_20","Empties_40"]] = df1["Pend"].str.split(",", expand = True).astype(int)
          df1[["Loaded_Pend_Cleared_20","Loaded_Pend_Cleared_40","Empty_Pend_Cleared_20","Empty_Pend_Cleared_40"]] = df1["Evacuated"].str.split(",", expand = True).astype(int)
          df1[["odr_days_20","odr_days_40"]] = df1["odr_days"].str.split(",", expand = True).astype(int)
          df1.rename(columns = {'i':'Source','j':'Destination'}, inplace = True)
          df1['AWAITING_FORECAST'] = df1["odr_days"]
        else:
          print("no df_out planned")
        df = df1.reset_index(drop = True)
        return df
      ###############################################################################################################################################################################
      # Update schedules from df
      ###############################################################################################################################################################################
      def update_schedules(df):
        # Rename the final outputs
        df.rename(columns = {'Train':'rake_name', 'Source':'origin_code', 'Destination':'destination_code', 'clse_rt':'closed_rt', 'Loaded_Pend_Cleared_20':'loaded_TEUs_evacuated_20', 'Pendency_20':'pendency_loaded20', 'Loaded_Pend_Cleared_40':'loaded_TEUs_evacuated_40', 'Pendency_40':'pendency_loaded40', 'Empty_Pend_Cleared_20':'empty_TEUs_evacuated_20', 'Empties_20':'pendency_empties20', 'Empty_Pend_Cleared_40':'empty_TEUs_evacuated_40', 'Empties_40':'pendency_empties40', 'Wagons':'wagons', 'Stack':'stack', 'Base_Loc':'base_location_code'}, inplace = True)
        if 'STATUS_FLAG' not in df: df['STATUS_FLAG'] = None
        if 'AWAITING_FORECAST' not in df: df['AWAITING_FORECAST'] = 0
        if len(df) < 1: df = pd.DataFrame(columns = ["rake_name","Trip_Num","origin_code","destination_code","loaded_TEUs_evacuated_20","loaded_TEUs_evacuated_40","empty_TEUs_evacuated_20","empty_TEUs_evacuated_40","STATUS_FLAG","AWAITING_FORECAST"])
        df = df[["rake_name","Trip_Num","origin_code","destination_code","loaded_TEUs_evacuated_20","loaded_TEUs_evacuated_40","empty_TEUs_evacuated_20","empty_TEUs_evacuated_40","STATUS_FLAG","AWAITING_FORECAST"]].reset_index(drop = True)
        return df
      ######################################################################################################################################################################################################
      # Rake Status of Final Unscheduled Trains - Train status is decided by TXR, TXR-NO-ROUTE-TO-BASE and PARK
      ######################################################################################################################################################################################################
      def train_status_dict(unscheduled_train_df,tcs,origin_base_km_min_dict):
        # origin to any nearest location is calculated and stored in a dict
        distance_data1 = distance_data[distance_data.Active_Route == 1].sort_values(by = ["origin_code","rational_distance"])
        distance_data1 = distance_data1.drop_duplicates(subset = ["origin_code"], keep = 'first').reset_index(drop = True)
        distance_data1['origin_nearest_dest'] = distance_data1.origin_code # + "-" + distance_data1.destination_code
        origin_destination_km_min_dict = dict(zip(distance_data1.origin_nearest_dest, (zip(distance_data1['rational_distance'],distance_data1['r_tat_sla'], distance_data1['destination_code']))))

        # origin to all possible bases is calculated and stored in a dict
        all_bases = list((train_current_status.base_depot_code.unique()))
        distance_data2 = distance_data[(distance_data.Active_Route == 1) & (distance_data.destination_code.isin(all_bases))].sort_values(by = ["origin_code","rational_distance"])
        distance_data2['rake_route'] = distance_data2.origin_code + "-" + distance_data2.destination_code
        origin_base_dist_actv = dict(zip(distance_data2.rake_route, (zip(distance_data2['rational_distance'],distance_data2['r_tat_sla']))))
        via_rt['via_destination'] = via_rt.via + "-" + via_rt.destination_code

        df1 = unscheduled_train_df.copy().reset_index(drop = True)
        tcs = tcs.reset_index(drop = True)
        train_status_dict = dict()
        for i in range(len(df1)):
          rake = df1.loc[i,"Trains_Not_Scheduled"]
          train_status_dict[rake] = None
          # train current status df
          train_cs_df = tcs[tcs.rake_name == rake].drop_duplicates(subset = 'rake_name', keep = 'first').reset_index(drop = True)
          rake_origin = train_cs_df.destination_code[0]
          rem_km = train_cs_df.TXR_KmsRem_CurrDest[0]
          rem_time = train_cs_df.TXR_DueRem_CurrDest[0]
          rake_base = train_cs_df.base_depot_code[0]
          rake_route = rake_origin + "-" + rake_base
          # as per min km from origin to base
          origin_to_base_km = origin_base_km_min_dict[rake_route][0]
          origin_to_base_min = origin_base_km_min_dict[rake_route][1]
          # as per active route from origin to nearest destination
          origin_to_destination_km = origin_destination_km_min_dict[rake_origin][0]
          origin_to_destination_min = origin_destination_km_min_dict[rake_origin][1]
          nearest_destination = origin_destination_km_min_dict[rake_origin][2]
          rake_route_dest_to_base = nearest_destination + "-" + rake_base
          nearest_destiny_to_base_km = origin_base_km_min_dict[rake_route_dest_to_base][0]
          nearest_destiny_to_base_min = origin_base_km_min_dict[rake_route_dest_to_base][1]

          status = ''
          # if rake's licence is about to expire, it is at base and it cannot go to any nearest destination and be back => "txr"
          if ((rake_origin == rake_base) & ((rem_km <= 2*origin_to_destination_km) or (rem_time <= 2*origin_to_destination_min))):
            status = "(TXR)"
          # else if rake's licence is about to expire because it's rem_km/hr is less to go to it's nearest location + nearest loc to base loc then status is 'txr'
          # active route => yes
          elif ((rake_route in origin_base_dist_actv) & ((rem_km <= origin_to_destination_km + nearest_destiny_to_base_km) or (rem_time <= origin_to_destination_min + nearest_destiny_to_base_min))):
            status = "(TXR)"
          # # else if rake's licence is about to expire because it's rem_km/hr is less to go to it's base
          # # active route => no
          elif ((rake_route not in origin_base_dist_actv) & ((rem_km <= origin_to_destination_km + nearest_destiny_to_base_km) or (rem_time <= origin_to_destination_min + nearest_destiny_to_base_min))):
            status = "(TXR-NO-ROUTE-TO-BASE)"
            # if rake's licence is about to expire and no direct route to base but it's a via route then only txr (via route is printed in output)
            if rake_route in via_rt[via_rt.route_type == "Maintenance"].route.to_list():
              status = "(TXR)"
          # elif rake_route in via_rt[via_rt.route_type == "Maintenance"].via_destination.to_list():
          #   if rem_time <= 24*60 :
          #     status = "(TXR)"
          else:
            if rake_origin not in ad_terminals:
              status = "(PARK)"
              origin_to_parking_spot_kms = route_df_adt[route_df_adt.origin_code == rake_origin].reset_index(drop = True).rational_distance[0]
              origin_to_parking_spot_min = route_df_adt[route_df_adt.origin_code == rake_origin].reset_index(drop = True).min_hrs[0]
              parking_spot = route_df_adt[route_df_adt.origin_code == rake_origin].reset_index(drop = True).destination_code[0]
              rake_route_park_to_base = parking_spot + "-" + rake_base
              parking_spot_to_base_km = origin_base_km_min_dict[rake_route_park_to_base][0]
              parking_spot_to_base_min = origin_base_km_min_dict[rake_route_park_to_base][1]
              if (rem_km <= origin_to_parking_spot_kms + parking_spot_to_base_km) or (rem_time <= origin_to_parking_spot_min + parking_spot_to_base_min):
                if rake_route not in origin_base_dist_actv:
                  status = "(TXR)"
                else:
                  status = "(TXR-NO-ROUTE-TO-BASE)"
            else:
              status = "(PARK)"
          train_status_dict[rake] = status
        return dict(train_status_dict)
      ####################################################################################################################################################################################
      # Schedule for TXR trains and PARKED trains
      ####################################################################################################################################################################################
      def scheduleX(train_status_dict,final_unsch_trains,previous_schedule):
        txr_trains = []           # list of all unscheduled txr trains
        park_trains = []          # list of all unscheduled to-be-parked trains
        txr_noroute_trains = []
        for i in train_status_dict:
          if (train_status_dict[i] == "(TXR)"):
            txr_trains.append(i)
          elif (train_status_dict[i] == "(TXR-NO-ROUTE-TO-BASE)"):
            txr_noroute_trains.append(i)
          elif (train_status_dict[i] == "(PARK)"):
            park_trains.append(i)
        schedule_x = pd.DataFrame()
        schedule2 = pd.DataFrame()
        schedule2_exists = 0
        if (len(txr_trains) + len(park_trains) + len(txr_noroute_trains) > 0):
          # schedule2_txr is txr train schedule
          schedule2_txr = train_current_status[train_current_status.rake_name.isin(txr_trains)].reset_index(drop = True)
          schedule2_txr.drop(columns = ["origin_code"], inplace = True)
          schedule2_txr['origin_code'] = schedule2_txr['destination_code']
          schedule2_txr['destination_code'] = schedule2_txr['base_depot_code']
          schedule2_txr['Trip_Num'] = 1
          schedule2_txr['STATUS_FLAG'] = -1 # -1 is for TXR
          # TO BE UPDATED TO STATUS_FLAG = -2
          # schedule2_txr_NR is TXR-NO-ROUTE-TO-BASE train schedule
          schedule2_txr_NR = train_current_status[train_current_status.rake_name.isin(txr_noroute_trains)].reset_index(drop = True)
          schedule2_txr_NR.drop(columns = ["origin_code"], inplace = True)
          schedule2_txr_NR['origin_code'] = schedule2_txr_NR['destination_code']
          # schedule2_txr_NR['destination_code'] = schedule2_txr_NR['base_depot_code']
          schedule2_txr_NR['destination_code'] = schedule2_txr_NR['destination_code'] # Rakes must be parked at location if they cannot move with some pendency to base location even if TXR to be done
          # schedule2_txr_NR['destination_code'] = 'TO-BE-DECIDED'
          schedule2_txr_NR['Trip_Num'] = 1
          schedule2_txr_NR['STATUS_FLAG'] = -2 # -2 is for TXR-NO-ROUTE-TO-BASE
          # schedule2_park is park train schedule
          schedule2_park = train_current_status[train_current_status.rake_name.isin(park_trains)].reset_index(drop = True)
          schedule2_park.drop(columns = ["destination_code","origin_code"], inplace = True)
          schedule2_park = schedule2_park.merge(final_unsch_trains[['Trains_Not_Scheduled','Start_Loc']], left_on = ['rake_name'], right_on = ['Trains_Not_Scheduled'], how = 'inner')
          schedule2_park.rename(columns = {"Start_Loc":"origin_code"}, inplace = True)
          schedule2_park['destination_code'] = schedule2_park['origin_code']
          schedule2_park['Trip_Num'] = 1
          schedule2_park['STATUS_FLAG'] = 1 # 1 is for PARK
          schedule2 = pd.concat([schedule2_txr,schedule2_park]).reset_index(drop = True)
          schedule2 = pd.concat([schedule2,schedule2_txr_NR]).reset_index(drop = True)
          schedule2[['loaded_TEUs_evacuated_20','loaded_TEUs_evacuated_40',
                    'empty_TEUs_evacuated_20','empty_TEUs_evacuated_40']] = 0,0,0,0
          schedule_x = update_schedules(schedule2)
          print("scheduled for txr")
          previous_schedule_rakes = list(previous_schedule.rake_name.unique())
          schedule_x = schedule_x[~schedule_x.rake_name.isin(previous_schedule_rakes)]
        # txr_trains and park_trains are removed from unscheduled train list
        final_unsch_trains = final_unsch_trains[~(final_unsch_trains.Trains_Not_Scheduled.isin(txr_trains))].reset_index(drop = True)
        final_unsch_trains = final_unsch_trains[~(final_unsch_trains.Trains_Not_Scheduled.isin(park_trains))].reset_index(drop = True)
        final_unsch_trains = final_unsch_trains[~(final_unsch_trains.Trains_Not_Scheduled.isin(txr_noroute_trains))].reset_index(drop = True)
        return schedule_x, final_unsch_trains
      ################################################################################################################################################################################################################################################
      # Via route terminals (No direct route between destination and base location)
      ################################################################################################################################################################################################################################################
      # Function to update via-route terminals
      def update_via_rt_terminals(df_schedule,df_via_rt,row_trip):
        for i in range(df_schedule.shape[0]):
          trip = df_schedule.loc[i,row_trip]
          df_via_rt1 = df_via_rt[df_via_rt.route_type == "Maintenance"].reset_index(drop = True)
          for j in range(df_via_rt1.shape[0]):
            bad_via_trip = df_via_rt1.loc[j,"route"]
            good_via_trip = df_via_rt1.loc[j,"via_route"]
            if bad_via_trip in trip:
              trip = trip.replace(bad_via_trip,good_via_trip)
          df_schedule.loc[i,row_trip] = trip
        return df_schedule
      ##########################################################################################################################################################################
      # Remove consecutive duplicate strings(terminal names) from trip suggestion column
      ##########################################################################################################################################################################
      # Function to remove consecutive duplicates of terminals from trip names
      def remove_duplicate_terminals_from_trips(df, row):
        for idx in range(df.shape[0]):
          # df2 = df.copy()
          L = df.loc[idx,row].split('-')
          df.loc[idx,row] = '-'.join([key for key, _group in groupby(L)])
        return df
      ##########################################################################################################################################################################
      # Update pendency line by line for a scheduled rake as per next trip
      ##########################################################################################################################################################################
      def update_pendency_in_ouput(final_df, row, row2):
        all_next_trip = list(final_df.next_trip_trip1.unique())
        df = pd.DataFrame()
        for i in (all_next_trip):
          filt_next_trip = final_df[final_df.next_trip_trip1 == i].reset_index(drop = True)
          pend_next_trip = filt_next_trip[row][0]
          for i in range(filt_next_trip.shape[0]-1):
            filt_next_trip.loc[i,row] = pend_next_trip
            filt_next_trip.loc[i+1,row] = pend_next_trip - filt_next_trip.loc[i,row2]
            pend_next_trip = filt_next_trip.loc[i+1,row]
          df = df._append(filt_next_trip).reset_index(drop = True)
        return df
      ##########################################################################################################################################################################
      # Update column as per status flag (-1 for TXR, 1 for PARK)
      ##########################################################################################################################################################################
      def update_status_in_trip(df,col,sts_flg):
        for i in range(len(df)):
          if df.loc[i,sts_flg] == -1:
            if df.loc[i,col].split("-")[-1] == df.loc[i,'base_depot_code']:
              df.loc[i,col] = df.loc[i,col] + "-(TXR)"
          if df.loc[i,sts_flg] == 1:
            df.loc[i,col] = df.loc[i,col] + "-(PARK)"
          # if rake is txr-no-route-to-base and cannot be scheduled due to low pendency through via route then park the rake
          # the rake which will can be scheduled will be updated to -1 status flag else the statul flag will stay -2 and such rakes will be parked
          if df.loc[i,sts_flg] == -2:
            if df.loc[i,col].split("-")[-1] == df.loc[i,'base_depot_code']:
              df.loc[i,col] = df.loc[i,col] + "-(TXR)"
            else:
              df.loc[i,col] = df.loc[i,col] + "-(PARK)"
        return df
      ##########################################################################################################################################################################
      # Update parking spot (if rake has to be parked) to nearest Adani terminal
      ##########################################################################################################################################################################
      def update_parking_spot(df, row, status_flag_row):
        for i in range(len(df)):
          trip = df[row][i]
          trip_list = trip.split("-")
          status_flag = df[status_flag_row][i]
          if trip_list[-1] == '(PARK)':
            if status_flag == -2: # if a rake has txr-no-route-to-base status and it has no pendency to cover towards it's base location then park at origin and follow forecast
              continue
            if trip_list[-2] in ad_terminals:
              continue
            parking_spot = route_df_adt[route_df_adt.origin_code == trip_list[-2]].reset_index(drop = True).via_route[0]
            trip_list = []
            trip_list.append(parking_spot)
            trip_list.append('(PARK)')
          trip_list = ("-").join(trip_list)
          df[row][i] = trip_list
        return df
      ##########################################################################################################################################################################
      # Update via routes by adding "-" between origin and destination
      ##########################################################################################################################################################################
      def splt_route(df, row):
        df = route_df_adt.copy()
        row = 'via_route'
        for i in range(len(df)):
          trip = df.loc[i,row]
          if len(trip) > 1:
            # trip_list = trip.split(",")
            trip1 = " - ".join(trip)
            df.loc[i,row] = trip1
          else:
            df.loc[i,row] = trip.pop()
        return df
      
      ##########################################################################################################################################################################
      # Update Pendency for recalculation
      ##########################################################################################################################################################################
      def update_recalculate_pendency(pendency_data_x,loaded_TEUs_evacuated_20_trip1,loaded_TEUs_evacuated_40_trip1,empty_TEUs_evacuated_20_trip1,empty_TEUs_evacuated_40_trip1,trip_origin,trip_destination):
        df=pendency_data_x.loc[(pendency_data_x.booking_location_code==trip_origin)&(pendency_data_x.to_terminal_code==trip_destination)]
        df_20=df[df.cont_size==20]
        df_sorted_20=df_20.sort_values(by='odr_days',ascending=True).reset_index(drop=True)
        for index, row in df_sorted_20.iterrows():
          if loaded_TEUs_evacuated_20_trip1>0:
            if row.pendency>=loaded_TEUs_evacuated_20_trip1:
              df_sorted_20.at[index,'pendency']-=loaded_TEUs_evacuated_20_trip1
              loaded_TEUs_evacuated_20_trip1=0
            else:
              loaded_TEUs_evacuated_20_trip1-=row.pendency
              df_sorted_20.at[index,'pendency']=0
          if empty_TEUs_evacuated_20_trip1>0:
            if row.empty_pendency>=empty_TEUs_evacuated_20_trip1:
              df_sorted_20.at[index,'empty_pendency']-=empty_TEUs_evacuated_20_trip1
              empty_TEUs_evacuated_20_trip1=0
            else:
              empty_TEUs_evacuated_20_trip1-=row.empty_pendency
              df_sorted_20.at[index,'empty_pendency']=0

        df_40=df[df.cont_size==40]
        df_sorted_40=df_40.sort_values(by='odr_days',ascending=True).reset_index(drop=True)
        for index, row in df_sorted_40.iterrows():
          if loaded_TEUs_evacuated_40_trip1>0:
            if row.pendency>=loaded_TEUs_evacuated_40_trip1:
              df_sorted_40.at[index,'pendency']-=loaded_TEUs_evacuated_40_trip1
              loaded_TEUs_evacuated_40_trip1=0
            else:
              loaded_TEUs_evacuated_40_trip1-=row.pendency
              df_sorted_40.at[index,'pendency']=0

          if empty_TEUs_evacuated_40_trip1>0:
            if row.empty_pendency>=empty_TEUs_evacuated_40_trip1:
              df_sorted_40.at[index,'empty_pendency']-=empty_TEUs_evacuated_40_trip1
              empty_TEUs_evacuated_40_trip1=0
            else:
              empty_TEUs_evacuated_40_trip1-=row.empty_pendency
              df_sorted_40.at[index,'empty_pendency']=0
        pendency_data_x.iloc[(pendency_data_x.booking_location_code==trip_origin)&(pendency_data_x.to_terminal_code==trip_destination)]=pd.concat([df_sorted_20,df_sorted_40])
        return pendency_data_x
      

      ###########################################################################################################################################################################
      # Optimizer (Scheduler)
      ###########################################################################################################################################################################
      def optimizer(dist_time_df, pend_df, train_curr_plan_df, container_df, wagon_df, TRIPS, obj_flag, UP_TO_TRIPS,
                    IGNORE_CAPACITY_CONSTRAINT, IGNORE_STRONG_MAINTENANCE_CONSTRAINT, IGNORE_CLOSED_ROUTE, PAYLOAD_FLAG,
                    FORECAST_PEND, forecast_date_var):

        from ortools.sat.python import cp_model # pip install ortools
        from collections import defaultdict
        import warnings
        warnings.simplefilter(action='ignore', category = FutureWarning)
        import pandas as pd
        import numpy as np
        import time as tme

        PAYLOAD_FLAG = PAYLOAD_FLAG # Flag to control payload optimization # Set to True to activate Payload
        FORECAST_PEND = FORECAST_PEND # Flag to control forecast pendency # Set to True to activate for forecast pendency
        Weightage_Load_Pend = 5
        # Increasing this will incentivize the solver to pick as many trains as possible.
        Weightage_Trains = 10000
        CALCULATE_ALL_PAIRS_SHORTEST = False
        CALCULATE_ALL_BASE_LOC_PAIRS_SHORTEST = True
        INF = 1000000000
        ndist = INF # Default distance if a route doesn't exists between two points
        ntime = INF # Default time if a route doesn't exists between two points
        nstack = 2 # Default is considered SS
        npendency = 0 # Default pendency if path doesn't exist between locations
        nodr = INF # Default odr_days
        cont_sz_dict = {20: 0, 40: 1}
        TRIPS = TRIPS # Currently works only upto 2 trips.
        # If this is True and TRIPS = 2 then that means
        # each scheduled_train can be planned for 1 or 2 trips.
        # Set this to False and TRIPS = 2 if each train needs to be planned for 2 trips only.
        UP_TO_TRIPS = UP_TO_TRIPS
        # Set this to True to
        # Ignore the 100 % (SS) / 70 % (DS) (2nd trip) as well as the ODR <= -7 days.
        IGNORE_CAPACITY_CONSTRAINT = IGNORE_CAPACITY_CONSTRAINT
        IGNORE_STRONG_MAINTENANCE_CONSTRAINT = IGNORE_STRONG_MAINTENANCE_CONSTRAINT
        IGNORE_CLOSED_ROUTE = IGNORE_CLOSED_ROUTE
        # obj_flag = 0 => Maximize Pendency Evacuated + Weightage_Trains
        # obj_flag = 1 => Minimize dist_ij + Maximize pend_jm.
        # Note: Set TRIPS = 2 and UP_TO_TRIPS = False for obj_flag = 1
        obj_flag = obj_flag

        def get_loc(df, df1, df2):
            src = sorted(list(df['Origin'].tolist())) # Dist_Time
            dest = sorted(list(df['Destination'].tolist())) # Dist_Time
            src1 = sorted(list(df1['Source'].tolist())) # Pendency
            dest1 = sorted(list(df1['Destination'].tolist())) # Pendency
            dest2 = sorted(list(df2['Destination'].tolist())) # Train_Curr_Status
            base_depots = sorted(list(df2['base_depot_code'].tolist())) # Train_Curr_Status
            locs = sorted(list(set((src) + (dest) + (src1) + (dest1) + (dest2) + (base_depots)))) # get unique locations
            loc_dict = {}
            for idx, loc in enumerate(locs):
                loc_dict[loc] = idx
            return locs, loc_dict

        def get_base_depot(df, trains, train_dict):
            base_depot_dict = {}
            for idx in range(df.shape[0]):
                train, base_depot = df.at[idx, 'Train'], df.at[idx, 'base_depot_code']
                base_depot_dict[train] = base_depot
            base_depot_locs = list(df['base_depot_code'].unique().tolist())
            return base_depot_locs, base_depot_dict

        def get_dist_time_stack(df, num_loc, loc_dict, locs, base_loc, Trains, train_dict, start_loc):
            dist = [[ndist] * num_loc for _ in range(num_loc)]
            dist_org = [[ndist] * num_loc for _ in range(num_loc)]
            time = [[ntime] * num_loc for _ in range(num_loc)]
            time_org = [[ntime] * num_loc for _ in range(num_loc)]
            closed_rt = {}
            for i in range(num_loc):
                # dist[i][i], time[i][i] = 0, 0
                dist_org[i][i], time_org[i][i] = 0, 0
            stack = [[nstack] * num_loc for _ in range(num_loc)]
            for idx in range(df.shape[0]):
                src, dest, d, t, s, actve, close_rt = df.at[idx, 'Origin'], df.at[idx, 'Destination'], df.at[idx, 'Dist'], df.at[idx, 'Time_min'], df.at[idx, 'ss_ds'], df.at[idx, 'active_rt'], df.at[idx, 'closed_rt']
                val = 2
                if s == 'DS':
                    val = 4
                dist[loc_dict[src]][loc_dict[dest]] = int(d)
                dist_org[loc_dict[src]][loc_dict[dest]] = int(d)
                # dist[loc_dict[dest]][loc_dict[src]] = d
                time[loc_dict[src]][loc_dict[dest]] = int(t)
                time_org[loc_dict[src]][loc_dict[dest]] = int(t)
                # time[loc_dict[dest]][loc_dict[src]] = t
                stack[loc_dict[src]][loc_dict[dest]] = val
                stack[loc_dict[dest]][loc_dict[src]] = val
                if int(close_rt) == 1:
                    closed_rt[(src, dest)] = 1

            closed_rt_train = {}
            for train in Trains:
                loc1 = start_loc[train]
                k = train_dict[train]
                closed_rt_train[k] = 0
                for loc2 in locs:
                    if (loc1, loc2) in closed_rt:
                        closed_rt_train[k] = 1
                        break

            n = len(dist)
            if CALCULATE_ALL_BASE_LOC_PAIRS_SHORTEST:
                # Calculate all-pairs shortest path
                # but only consider base_locations
                # as i -> base or j -> base in (i -> j -> base) can be active or inactive
                for k in range(n):
                    for loc1 in locs:
                        for bloc2 in base_loc:
                            i, j = loc_dict[loc1], loc_dict[bloc2]
                            if dist[i][k] < INF and dist[k][j] < INF:
                                dist[i][j] = min(dist[i][j], dist[i][k] + dist[k][j])
                            if time[i][k] < INF and time[k][j] < INF:
                                time[i][j] = min(time[i][j], time[i][k] + time[k][j])
            elif CALCULATE_ALL_PAIRS_SHORTEST:
                # Calculate all-pairs shortest path
                for k in range(n):
                    for i in range(n):
                        for j in range(n):
                            if dist[i][k] < INF and dist[k][j] < INF:
                                dist[i][j] = min(dist[i][j], dist[i][k] + dist[k][j])
                            if time[i][k] < INF and time[k][j] < INF:
                                time[i][j] = min(time[i][j], time[i][k] + time[k][j])
            return dist, time, stack, closed_rt, closed_rt_train, dist_org, time_org

        def get_trains_rem_dist_time(df):
            Trains = df['Train'].unique().tolist()
            train_dict = {}
            for idx, train in enumerate(Trains):
                train_dict[train] = idx
            wagons = {}
            Rem_Dist = {}
            Rem_Time = {}
            start_loc = {}
            Eta = {}
            Eta_T = {}
            Eta_rank={}
            for idx in range(df.shape[0]):
                train, rem_km, rem_min, starting_loc, wg, eta,eta_r = df.at[idx, 'Train'], df.at[idx, 'Actual_remaining_kms'], df.at[idx, 'remaining_min'], df.at[idx, 'Destination'], df.at[idx, 'unts'], df.at[idx, 'ETA'],df.at[idx, 'rank']
                Rem_Dist[train_dict[train]] = int(rem_km)
                Rem_Time[train_dict[train]] = int(rem_min)
                wagons[train_dict[train]] = int(wg)
                start_loc[train] = starting_loc
                Eta[train_dict[train]] = pd.to_datetime(eta)
                Eta_rank[train_dict[train]] = int(eta_r)
                # Eta_T[str(eta)] = Eta_T.get(str(eta), []) + [train_dict[train]]
            return Trains, train_dict, Rem_Dist, Rem_Time, start_loc, wagons, Eta, Eta_rank

        def get_pendency(df, num_loc, loc_dict):
            pend = [[[npendency, npendency] for _ in range(num_loc)] for _ in range(num_loc)]
            empty_pend = [[[npendency, npendency] for _ in range(num_loc)] for _ in range(num_loc)]
            odr_days = [[[nodr, nodr] for _ in range(num_loc)] for _ in range(num_loc)]
            for idx in range(df.shape[0]):
                src, dest, pendency, e_pend, cont_sz, odr = df.at[idx, 'Source'], df.at[idx, 'Destination'], df.at[idx, 'Pendency'], df.at[idx, 'empty_pendency'], df.at[idx, 'cont_size'], df.at[idx, 'odr_days']
                x, y= loc_dict[src], loc_dict[dest]
                pend[x][y][cont_sz_dict[cont_sz]] = int(pendency)
                # pend[y][x] = pendency
                empty_pend[x][y][cont_sz_dict[cont_sz]] = int(e_pend)
                odr_days[x][y][cont_sz_dict[cont_sz]] = int(odr)
            pend_sums = []
            for i in range(len(pend)):
                nsum = 0
                for j in range(len(pend[i])):
                    nsum += pend[i][j][0] + pend[i][j][1]
                pend_sums.append(nsum)
            return pend, pend_sums, empty_pend, odr_days

        def get_container_details(df):
            # Ensure that aggregate data and container level data matches.
            # One container cannot occur more than once.
            containers = df['cont_no'].unique().tolist()
            cont_dict = {}
            cont_ij_dict = defaultdict(list)
            for idx, cont in enumerate(containers):
                cont_dict[cont] = idx
            src_cont, dest_cont, sz_cont, wt_cont = {}, {}, {}, {}
            for idx in range(df.shape[0]):
                cont_no, cont_sz, src, dest, full_wt = df.at[idx, 'cont_no'], int(df.at[idx, 'cont_size']), df.at[idx, 'booking_location_code'], df.at[idx,'to_terminal_code'], int(round(df.at[idx, 'full_wt']/1000))
                cont_idx = cont_dict[cont_no]
                src_cont[cont_idx] = src
                dest_cont[cont_idx] = dest
                sz_cont[cont_idx] = cont_sz
                wt_cont [cont_idx] = full_wt
                cont_ij_dict[(src, dest, cont_sz)].append(cont_idx)
            return containers, cont_dict, src_cont, dest_cont, sz_cont, wt_cont, cont_ij_dict

        def get_wagon_details(df):
            # wagon_no is unique
            tot_wagons = df['wagon_no'].unique().tolist()
            assert(len(tot_wagons) == df.shape[0])
            wagon_dict = {}
            for idx, wag in enumerate(tot_wagons):
                wagon_dict[wag] = idx
            wag_train, wag_wt = {}, {}
            for idx in range(df.shape[0]):
                rake, wagon_no, wt = df.at[idx, 'rake_name'], df.at[idx, 'wagon_no'], int(round(df.at[idx, 'permissible_wt']))
                wag_idx = wagon_dict[wagon_no]
                wag_train[wag_idx] = rake
                wag_wt[wag_idx] = wt
            return tot_wagons, wagon_dict, wag_train, wag_wt

        def get_pend_updated(pend_df, df_out):
          if len(df_out) > 0:
              df_out2 = df_out.copy()
              df_out2["Pend"] = df_out2["Pend"].apply(lambda x: ','.join(map(str, x)))
              df_out2["Evacuated"] = df_out2["Evacuated"].apply(lambda x: ','.join(map(str, x)))
              df_out2[["20ftloadedPend","40ftloadedPend","20ftempPend","40ftempPend"]] = df_out2["Pend"].str.split(",", expand = True).astype(int)
              df_out2[["20ftloadedEvac","40ftloadedEvac","20ftempEvac","40ftempEvac"]] = df_out2["Evacuated"].str.split(",", expand = True).astype(int)
              df_out2.rename(columns = {'i':'Source','j':'Destination'}, inplace = True)
              df_pend_cleared_20 = df_out2.groupby(['Source', 'Destination'], as_index=False)['20ftloadedEvac'].sum()
              df_empty_cleared_20 = df_out2.groupby(['Source', 'Destination'], as_index=False)['20ftempEvac'].sum()
              df_pend_cleared_40 = df_out2.groupby(['Source', 'Destination'], as_index=False)['40ftloadedEvac'].sum()
              df_empty_cleared_40 = df_out2.groupby(['Source', 'Destination'], as_index=False)['40ftempEvac'].sum()
              df_merged = pd.merge(df_pend_cleared_20, pend_df, on=['Source', 'Destination'], how='right')
              df_merged_1 = pd.merge(df_empty_cleared_20, df_merged, on=['Source', 'Destination'], how='right')
              df_merged_40 = pd.merge(df_pend_cleared_40, df_merged_1, on=['Source', 'Destination'], how='right')
              df_merged_1_40 = pd.merge(df_empty_cleared_40, df_merged_40, on=['Source', 'Destination'], how='right')
              cols_type_int = ["20ftloadedEvac","40ftloadedEvac","20ftempEvac","40ftempEvac"]
              df_merged_1_40['pen_units_remaining'] =np.where(df_merged_1_40['cont_size']==40,df_merged_1_40['Pendency'] - df_merged_1_40['40ftloadedEvac'] ,df_merged_1_40['Pendency'] - df_merged_1_40['20ftloadedEvac'])
              df_merged_1_40['pen_units_remaining'].fillna(df_merged_1_40['Pendency'],inplace=True)
              df_merged_1_40['emp_units_remaining'] =np.where(df_merged_1_40['cont_size']==40,df_merged_1_40['empty_pendency'] - df_merged_1_40['40ftempEvac'] ,df_merged_1_40['empty_pendency'] - df_merged_1_40['20ftempEvac'])
              df_merged_1_40['emp_units_remaining'].fillna(df_merged_1_40['empty_pendency'],inplace=True)
              pend_df_updated = df_merged_1_40[['Source','Destination','pen_units_remaining','emp_units_remaining','odr_days','cont_size']].copy()
              pend_df_updated.rename(columns={'pen_units_remaining':'Pendency','emp_units_remaining':'empty_pendency' }, inplace=True)
              pend_df_updated.head()
          else:
            pend_df_updated = pend_df
          return pend_df_updated

        def optimize(locs, Trains, train_dict, dist,
                              time, dist1, time1, Rem_Dist, Rem_Time, loc_dict, base_loc, base_depot_dict, pend, empty_pend, stack, start_loc,
                              pend_sums, odr_days, wagons, Eta, Eta_T, closed_rt, closed_rt_train, dist_time_df, pend_df, train_curr_plan_df, container_df, wagon_df,
                              cont_names, cont_dict, src_cont, dest_cont, sz_cont, wt_cont, cont_ij_dict, wag_names, wagon_dict, wag_train, wag_wt,
                              pend_evacuated, dist_travelled, obj_flag, forecast_date_var):

            # Create the CP-SAT model
            # Uses Google CP-SAT Solver
            model = cp_model.CpModel()
            # x_{rkij} = 1 if Train k is assigned location pair (i,j) else 0 in r^th trip.
            x = {}
            # y_{rkij_{20/40}} -> Loaded_Pendency cleared (20 ft / 40 ft) by train k from i -> j in r^th trip
            y = {}
            # t_{rkij_{20/40}} -> Empty_Pendency cleared (20 ft / 40 ft) by train k from i -> j in r^th trip
            t = {}
            r_st = {} # r_st[(r, k, i)] = list[x[(r, k, i, j)] for all j]
            train_start_locs = []
            all_expr = []
            all_expr_trains = {}
            start = tme.time()
            for r in range(TRIPS):
                for train in Trains:
                    k = train_dict[train]
                    L = locs
                    if r == 0:
                        L = [start_loc[train]]
                        train_start_locs.append(start_loc[train])
                    for loc1 in L:
                        expr = []
                        for loc2 in locs:
                            if loc1 == loc2:
                                continue
                            i, j = loc_dict[loc1], loc_dict[loc2]
                            if dist[i][j] == INF or time[i][j] == INF:
                              continue
                            x[(r, k, i, j)] = model.NewBoolVar(f"x_{r}{k}{i}{j}")
                            expr.append(x[(r, k, i, j)])
                            if r == 0:
                                all_expr.append(x[((r, k, i, j))])
                            all_expr_trains[k] = all_expr_trains.get(k, []) + [x[((r, k, i, j))]]
                            capacity = wagons[train_dict[train]] * stack[i][j]
                            lb_20, lb_40 = 0, 0
                            # loaded_pendency_{20 / 40} evacuated can now be 0.
                            y[(r, k, i, j, 20)] = model.NewIntVar(lb_20, min(pend[i][j][cont_sz_dict[20]], capacity), f"y_{r}{k}{i}{j}{20}")
                            y[(r, k, i, j, 40)] = model.NewIntVar(lb_40, min(pend[i][j][cont_sz_dict[40]], capacity), f"y_{r}{k}{i}{j}{40}")
                            # Make loaded_pend_cleared for 20 ft and 40 ft container 'even' if path(i->j) is chosen
                            for cont_size in [20, 40]:
                                yx = model.NewIntVar(0, min(pend[i][j][cont_sz_dict[cont_size]], capacity), f"yx{r}{k}{i}{j}{cont_size}")
                                model.AddMultiplicationEquality(yx, x[(r, k, i, j)], y[(r, k, i, j, cont_size)])
                                b = model.NewBoolVar('b')
                                model.AddModuloEquality(b, yx, 2)
                                model.Add(b == 0)
                            lb_empty = 0
                            t[(r, k, i, j, 20)] = model.NewIntVar(lb_empty, min(empty_pend[i][j][cont_sz_dict[20]], capacity), f"t_{r}{k}{i}{j}{20}")
                            t[(r, k, i, j, 40)] = model.NewIntVar(lb_empty, min(empty_pend[i][j][cont_sz_dict[40]], capacity), f"t_{r}{k}{i}{j}{40}")
                            # Make empties_cleared for 20 ft and 40 ft container 'even' if path (i->j) is chosen
                            for cont_size in [20, 40]:
                                tx = model.NewIntVar(0, min(empty_pend[i][j][cont_sz_dict[cont_size]], capacity), f"tx{r}{k}{i}{j}{cont_size}")
                                model.AddMultiplicationEquality(tx, x[(r, k, i, j)], t[(r, k, i, j, cont_size)])
                                b1 = model.NewBoolVar('b1')
                                model.AddModuloEquality(b1, tx, 2)
                                model.Add(b1 == 0)
                            # 2nd trip should be planned only if odr_days <= -7
                            if r == 1 and IGNORE_CAPACITY_CONSTRAINT == False and FORECAST_PEND == False:
                                if odr_days[i][j][cont_sz_dict[20]] > -7 and odr_days[i][j][cont_sz_dict[40]] > -7:
                                    model.Add(x[(r, k, i, j)] == 0)
                                elif odr_days[i][j][cont_sz_dict[20]] <= -7 and odr_days[i][j][cont_sz_dict[40]] > -7:
                                    # model.Add(y[(r, k, i, j, 20)] >= 1).OnlyEnforceIf(x[((r, k, i, j))])
                                    model.Add(y[(r, k, i, j, 40)] == 0)
                                elif odr_days[i][j][cont_sz_dict[40]] <= -7 and odr_days[i][j][cont_sz_dict[20]] > -7:
                                    # model.Add(y[(r, k, i, j, 40)] >= 1).OnlyEnforceIf(x[((r, k, i, j))])
                                    model.Add(y[(r, k, i, j, 20)] == 0)
                        r_st[(r, k, i)] = expr
            train_start_locs = list(set(train_start_locs))

            print("Variables Created and Even Constraint")

            rt = {} # rt[k]: How many routes are allocated for Train k. Range: [0, TRIPS]
            # Connecting Constraint
            for train in Trains:
                k = train_dict[train]
                texpr = []
                texpr0, texpr1=[],[]
                for r in range(TRIPS):
                    L = locs
                    if r == 0:
                        L = [start_loc[train]]
                    expr = []
                    for loc1 in L:
                        for loc2 in locs:
                            if loc1 == loc2:
                                continue
                            i, j = loc_dict[loc1], loc_dict[loc2]
                            if dist[i][j] == INF or time[i][j] == INF:
                              continue
                            expr.append(x[(r, k, i, j)])
                            texpr.append(x[(r, k, i, j)])
                            if r==0:
                              texpr0.append(x[(r,k,i,j)])
                            else :
                              texpr1.append(x[(r, k, i, j)])
                            if r < (TRIPS - 1):
                                # Until penultimate trip
                                # Connecting Constraint
                                # model.Add(x[((r, k, i, j))] >= x[(((r + 1), k, i, j))])
                                # i -> j and then j -> m
                                # con_expr = all_routes beginning from j in the next trip for train k
                                con_expr = r_st[((r + 1), k, j)]
                                s1 = cp_model.LinearExpr.Sum(con_expr)
                                # if i -> j allocated then all routes beginning from j' (j' != j)
                                # in the next trip should not be considered
                                # con_expr_1 = all_routes beginning from j' (j' != j) in the next trip for train k
                                con_expr_1 = []
                                for loc22 in locs:
                                    if loc22 == loc2:
                                        continue
                                    j_dash = loc_dict[loc22]
                                    con_expr_1 += (r_st[((r + 1), k, j_dash)])
                                s2 = cp_model.LinearExpr.Sum(con_expr_1)
                                model.Add(s2 == 0).OnlyEnforceIf(x[((r, k, i, j))])
                                if not UP_TO_TRIPS:
                                  model.Add(s1 == 1).OnlyEnforceIf(x[((r, k, i, j))])
                                # if i -> j not allocated then no route can start from j in the next trip
                                model.Add(s1 == 0).OnlyEnforceIf(x[(r, k, i, j)].Not())
                    # A train can be assigned to at-most 1 route in each trip.
                    # However, in trip (n; n > 0), route can be assigned iff a
                    # route has been assigned in trip (n-1).
                    model.Add(cp_model.LinearExpr.Sum(expr) <= 1)
                model.Add(cp_model.LinearExpr.Sum(texpr0)>= cp_model.LinearExpr.Sum(texpr1))
                rt[k] = cp_model.LinearExpr.Sum(texpr)

            print("Connecting Constraint")
            '''
            # If no route (i->j) exists, it won't be considered.
            for r in range(TRIPS):
                for train in Trains:
                    k = train_dict[train]
                    L = locs
                    if r == 0:
                        L = [start_loc[train]]
                    for loc1 in L:
                        for loc2 in locs:
                            i, j = loc_dict[loc1], loc_dict[loc2]
                            if i == j: # or loc == base_depot_dict[train]
                                continue
                            if dist[i][j] == INF or time[i][j] == INF:
                              model.Add(x[(r, k, i, j)] == 0)
            print("Route Constraint")
            '''
            # Deal with closed_rt
            # A closed_route (i->j) must be allocated to some train k in trip r.
            if IGNORE_CLOSED_ROUTE == False:
                for (loc, val) in closed_rt.items():
                    loc1, loc2 = loc
                    i, j = loc_dict[loc1], loc_dict[loc2]
                    if i == j or dist[i][j] == INF or time[i][j] == INF:
                      continue
                    expr = []
                    for r in range(TRIPS):
                        for train in Trains:
                            k = train_dict[train]
                            expr.append(x[(r, k, i, j)])
                    model.Add(cp_model.LinearExpr.Sum(expr) == 1)

            print(f"Closed_Route and Ignore_Closed_Route = {IGNORE_CLOSED_ROUTE}")

            # For each pair of location (i, j), the sum of {loaded, empty}_pendency (for 20 ft and 40 ft containers)
            # cleared across i->j by all chosen trains should be <= to the amount of {loaded, empty}_pendency
            # from i->j (for 20 ft and 40 ft containers separately) *across all trips*.
            load_expr, empty_expr, dist_expr = [], [], []
            uload_expr, uempty_expr, udist_expr = [], [], []
            first_trip_const = 100
            for loc1 in locs:
                for loc2 in locs:
                    if loc1  == loc2:
                        continue
                    expr_20, expr_40, expr1_20, expr1_40 = [], [], [], []
                    i, j = loc_dict[loc1], loc_dict[loc2]
                    if dist[i][j] == INF or time[i][j] == INF:
                      continue
                    for train in Trains:
                        k = train_dict[train]
                        capacity = wagons[train_dict[train]] * stack[i][j]
                        for r in range(TRIPS):
                            if r == 0 and loc1 != start_loc[train]:
                                continue
                            odr_factor_20, odr_factor_40 = 1, 1
                            if odr_days[i][j][cont_sz_dict[20]] < 0:
                                odr_factor_20 = int(-1 * odr_days[i][j][cont_sz_dict[20]])
                            if odr_days[i][j][cont_sz_dict[40]] < 0:
                                odr_factor_40 = int(-1 * odr_days[i][j][cont_sz_dict[40]])
                            odr_factor_20, odr_factor_40 = 1, 1
                            first_trip_imp = 1
                            if r == 0:
                                # CHANGE IMPORTANCE OF FIRST TRIP
                                first_trip_imp = first_trip_const
                            yx20 = model.NewIntVar(0, min(pend[i][j][cont_sz_dict[20]], capacity), f"yx{r}{k}{i}{j}{20}")
                            model.AddMultiplicationEquality(yx20, x[(r, k, i, j)], y[(r, k, i, j, 20)])
                            load_expr.append(first_trip_imp * odr_factor_20 * yx20*Eta_rank[k])
                            expr_20.append(yx20)

                            yx40 = model.NewIntVar(0, min(pend[i][j][cont_sz_dict[40]], capacity), f"yx{r}{k}{i}{j}{40}")
                            model.AddMultiplicationEquality(yx40, x[(r, k, i, j)], y[(r, k, i, j, 40)])
                            load_expr.append(first_trip_imp * odr_factor_40 * yx40*Eta_rank[k])
                            expr_40.append(yx40)

                            tx20 = model.NewIntVar(0, min(empty_pend[i][j][cont_sz_dict[20]], capacity), f"tx{r}{k}{i}{j}{20}")
                            model.AddMultiplicationEquality(tx20, x[(r, k, i, j)], t[(r, k, i, j, 20)])
                            empty_expr.append(first_trip_imp * odr_factor_20 * tx20*Eta_rank[k])
                            expr1_20.append(tx20)

                            tx40 = model.NewIntVar(0, min(empty_pend[i][j][cont_sz_dict[40]], capacity), f"tx{r}{k}{i}{j}{40}")
                            model.AddMultiplicationEquality(tx40, x[(r, k, i, j)], t[(r, k, i, j, 40)])
                            empty_expr.append(first_trip_imp * odr_factor_40 * tx40*Eta_rank[k])
                            expr1_40.append(tx40)

                            if r == 1:
                                uload_expr.append(first_trip_imp * odr_factor_20 * yx20*Eta_rank[k])
                                uload_expr.append(first_trip_imp * odr_factor_40 * yx40*Eta_rank[k])
                                uempty_expr.append(first_trip_imp * odr_factor_20 * tx20*Eta_rank[k])
                                uempty_expr.append(first_trip_imp * odr_factor_40 * tx40*Eta_rank[k])

                    model.Add(cp_model.LinearExpr.Sum(expr_20) <= (pend[i][j][cont_sz_dict[20]]))
                    model.Add(cp_model.LinearExpr.Sum(expr_40) <= (pend[i][j][cont_sz_dict[40]]))
                    model.Add(cp_model.LinearExpr.Sum(expr1_20) <= (empty_pend[i][j][cont_sz_dict[20]]))
                    model.Add(cp_model.LinearExpr.Sum(expr1_40) <= (empty_pend[i][j][cont_sz_dict[40]]))

            print("Capacity Constraint for a particular route")

            txr_dexpiry = {}
            txr_texpiry = {}
            for train in Trains:
                k, i, j = train_dict[train], loc_dict[start_loc[train]], loc_dict[base_depot_dict[train]]
                if i == j:
                    continue
                if dist[i][j] == INF or time[i][j] == INF:
                  continue
                txr_dexpiry[k] = model.NewBoolVar(f'txr_dexpire{k}')
                model.Add(dist[i][j] * x[((0, k, i, j))] >= (Rem_Dist[k] + 1)).OnlyEnforceIf(txr_dexpiry[k]).OnlyEnforceIf(x[((0, k, i, j))])
                model.Add(dist[i][j] * x[((0, k, i, j))] <= Rem_Dist[k]).OnlyEnforceIf(txr_dexpiry[k].Not()).OnlyEnforceIf(x[((0, k, i, j))])
                model.Add(txr_dexpiry[k] == 0).OnlyEnforceIf(x[((0, k, i, j))].Not())
                txr_texpiry[k] = model.NewBoolVar(f'txr_texpire{k}')
                model.Add(time[i][j] * x[((0, k, i, j))] >= (Rem_Time[k] + 1)).OnlyEnforceIf(txr_texpiry[k]).OnlyEnforceIf(x[((0, k, i, j))])
                model.Add(time[i][j] * x[((0, k, i, j))] <= Rem_Time[k]).OnlyEnforceIf(txr_texpiry[k].Not()).OnlyEnforceIf(x[((0, k, i, j))])
                model.Add(txr_texpiry[k] == 0).OnlyEnforceIf(x[((0, k, i, j))].Not())

            # Loaded_Pendency + Empty_Pendency >= 100% for SS and >= 70 % for DS, applicable only for 2nd leg of the trip, for (i -> j -> m -> base) kind of trips.
            # In case the solver selects (i -> j -> base) kind of route or (i -> base) (like original optimizer) then 70% becomes 50% for DS.
            # Also for DS, sum of loaded_pend + empty_pend for 20 ft containers <= 50% of capacity (20 ft containers can't occupy upper berth).
            # Also deal with the case if TXR has expired when train directly goes to base.
            b11 = {}
            b22 = {}
            for r in range(TRIPS):
                for train in Trains:
                    k = train_dict[train]
                    b11[k] = model.NewBoolVar(f'b11{k}')
                    b22[k] = model.NewBoolVar(f'b22{k}')

                    model.Add(rt[k] == 2).OnlyEnforceIf(b22[k])
                    model.Add(rt[k] <= 1).OnlyEnforceIf(b22[k].Not())
                    model.Add(rt[k] == 1).OnlyEnforceIf(b11[k]).OnlyEnforceIf(b22[k].Not())
                    model.Add(rt[k] == 0).OnlyEnforceIf(b11[k].Not()).OnlyEnforceIf(b22[k].Not())

                    L = locs
                    if r == 0:
                        L = [start_loc[train]]

                    for loc1 in L:
                        for loc2 in locs:
                            i, j = loc_dict[loc1], loc_dict[loc2]
                            if i == j or dist[i][j] == INF or time[i][j] == INF: # or start_loc[train] == loc2:
                              continue

                            if r == 0:
                                udist_expr.append(-1 * dist[i][j] * x[(r, k, i, j)])

                            dist_expr.append(dist[i][j] * x[(r, k, i, j)])

                            capacity = wagons[train_dict[train]] * stack[i][j]

                            yx20 = model.NewIntVar(0, min(pend[i][j][cont_sz_dict[20]], capacity ), f"yx{r}{k}{i}{j}{20}")
                            model.AddMultiplicationEquality(yx20, x[(r, k, i, j)], y[(r, k, i, j, 20)])
                            yx40 = model.NewIntVar(0, min(pend[i][j][cont_sz_dict[40]], capacity ), f"yx{r}{k}{i}{j}{40}")
                            model.AddMultiplicationEquality(yx40, x[(r, k, i, j)], y[(r, k, i, j, 40)])
                            yx = model.NewIntVar(0, min(pend[i][j][cont_sz_dict[20]] + pend[i][j][cont_sz_dict[40]], capacity ), f"yx{r}{k}{i}{j}")
                            model.Add(yx == (yx20 + yx40))

                            tx20 = model.NewIntVar(0, min(empty_pend[i][j][cont_sz_dict[20]], capacity), f"tx{r}{k}{i}{j}{20}")
                            model.AddMultiplicationEquality(tx20, x[(r, k, i, j)], t[(r, k, i, j, 20)])
                            tx40 = model.NewIntVar(0, min(empty_pend[i][j][cont_sz_dict[40]], capacity), f"tx{r}{k}{i}{j}{40}")
                            model.AddMultiplicationEquality(tx40, x[(r, k, i, j)], t[(r, k, i, j, 40)])
                            tx = model.NewIntVar(0, min(empty_pend[i][j][cont_sz_dict[20]] + empty_pend[i][j][cont_sz_dict[40]], capacity ), f"tx{r}{k}{i}{j}")
                            model.Add(tx == (tx20 + tx40))

                            # Loaded_Pend + Empties <= capacity
                            model.Add(yx + tx <= capacity)

                            # Ignore these constraints not considered if a route (i-j) is a closed_route
                            if IGNORE_CLOSED_ROUTE == False and (loc1, loc2) in closed_rt:
                                continue

                            # For DS, sum of loaded_pend + empty_pend for 20 ft containers <= 50% of capacity
                            # Upper_Berth constraint
                            if stack[i][j] == 4:
                                model.Add(2 * (yx20 + tx20) <= capacity).OnlyEnforceIf(x[((r, k, i, j))])

                            # If a train directly goes to base and TXR has expired
                            # then the train should carry whatever pendency it can. Otherwise 100% (SS) and  50% (DS) 1 trip rule should be followed.
                            # TXR_Expiry is possible because we aren't checking Stong_Maintenance constraint if train directly goes to base.
                            if r == 0 and j == base_depot_dict[train]:
                                if stack[i][j] == 2:
                                    model.Add(yx + tx == capacity).OnlyEnforceIf([b11[k], b22[k].Not()]).OnlyEnforceIf([txr_dexpiry[k].Not(), txr_texpiry[k].Not(), x[(r, k, i, j)]]) # 1 trip
                                elif stack[i][j] == 4:
                                    model.Add(2 * (yx + tx) >= capacity).OnlyEnforceIf([b11[k], b22[k].Not()]).OnlyEnforceIf([txr_dexpiry[k].Not(), txr_texpiry[k].Not(), x[(r, k, i, j)]]) # 1 trip
                            elif IGNORE_CAPACITY_CONSTRAINT == False:
                                if stack[i][j] == 2:
                                    # Loaded_Pendency + Empty_Pendency >= 100% for SS
                                    # applicable only for 2nd leg of the trip, for (i -> j -> m -> base) kind of trips.
                                    # This 100% constraint is valid for (i -> j -> base) and (i -> base) kind of trips also.
                                    if r == 0:
                                        model.Add(yx + tx == capacity).OnlyEnforceIf([b11[k], b22[k].Not()]).OnlyEnforceIf(x[(r, k, i, j)]) # 1 trip
                                        model.Add(yx + tx <= capacity).OnlyEnforceIf([b11[k].Not(), b22[k]]).OnlyEnforceIf(x[(r, k, i, j)]) # 2 trip
                                    else:
                                        model.Add(yx + tx == capacity).OnlyEnforceIf(x[(r, k, i, j)])

                                elif stack[i][j] == 4:
                                    # Loaded_Pendency + Empty_Pendency >= 70% for DS
                                    # applicable only for 2nd leg of the trip, for (i -> j -> m -> base) kind of trips
                                    # For the 1 trip case [(i -> j -> base) and (i -> base)], 70% becomes 50%.
                                    if r == 0:
                                        model.Add(2 * (yx + tx) >= capacity).OnlyEnforceIf([b11[k], b22[k].Not()]).OnlyEnforceIf(x[(r, k, i, j)]) # 1 trip
                                        model.Add(yx + tx <= capacity).OnlyEnforceIf([b11[k].Not(), b22[k]]).OnlyEnforceIf(x[(r, k, i, j)]) # 2 trip
                                    else:
                                        model.Add(10 * (yx + tx) >= 7 * capacity).OnlyEnforceIf(x[(r, k, i, j)])

            print(f"100 %/ 50 % / 70 % Constraints for SS / DS and some other constraints! and Ignore_Capacity_Constraint = {IGNORE_CAPACITY_CONSTRAINT}")

            # Maintenance constraint (strong, makes sure that after the next trip train can
            # still return for maintenance without violating constraint):
            # This doesn't consider trains going directly to base location.
            # Train can do i -> j ---> base or i -> j -> m ---> base
            # Distance and Time both considered
            if IGNORE_STRONG_MAINTENANCE_CONSTRAINT == False:
                for train in Trains:
                    k, base_depot_idx = train_dict[train], loc_dict[base_depot_dict[train]]
                    for r in range(TRIPS):
                        L = locs
                        if r == 0:
                            L = [start_loc[train]]
                        for loc1 in L:
                            for loc2 in locs:
                                i, j = loc_dict[loc1], loc_dict[loc2]
                                if loc1 == loc2:
                                    continue
                                if dist[i][j] == INF or time[i][j] == INF:
                                  continue
                                # Maintenance constraint not considered when train goes directly to base
                                if r == 0 and loc2 == base_depot_dict[train]:
                                    continue
                                # Maintenance constraint not considered if a route (i-j) is a closed_route
                                # Note: 10/1/24: Closed_Routes ignored currently for the 2 trip case.
                                if IGNORE_CLOSED_ROUTE == False and (loc1, loc2) in closed_rt:
                                    continue
                                # We optimize this for 2 trips by using the fact that loc i in (i->j->m->base) is the start location
                                # So for any (j->m) in trip 2, the i will be the start_loc of that train in trip 1.
                                # i.e. x[1, k, i, j] and x[0, k, loc_dict[start_loc[train]], i] are linked.
                                if r == 0:
                                    model.Add((dist1[j][base_depot_idx] * x[(r, k, i, j)]) <= (Rem_Dist[k] - (dist[i][j] * x[((r, k, i, j))]))).OnlyEnforceIf(x[((r, k, i, j))])
                                    model.Add((time1[j][base_depot_idx] * x[(r, k, i, j)]) <= (Rem_Time[k] - (time[i][j] * x[((r, k, i, j))]))).OnlyEnforceIf(x[((r, k, i, j))])
                                elif r == 1 and (start_loc[train] != loc1) and (r - 1, k, loc_dict[start_loc[train]], i) in x:
                                    model.Add((dist1[j][base_depot_idx] * x[(r, k, i, j)]) <= (Rem_Dist[k] - ((dist[loc_dict[start_loc[train]]][i] * x[((r - 1, k, loc_dict[start_loc[train]], i))]) + (dist[i][j] * x[((r, k, i, j))])))).OnlyEnforceIf([x[((r - 1, k, loc_dict[start_loc[train]], i))], x[((r, k, i, j))]])
                                    model.Add((time1[j][base_depot_idx] * x[(r, k, i, j)]) <= (Rem_Time[k] - ((time[loc_dict[start_loc[train]]][i] * x[((r - 1, k, loc_dict[start_loc[train]], i))]) + (time[i][j] * x[((r, k, i, j))])))).OnlyEnforceIf([x[((r - 1, k, loc_dict[start_loc[train]], i))], x[((r, k, i, j))]])

            print(f"Strong Maintenance Constraint and Ignore_Strong_Maintenance_Constraint = {IGNORE_STRONG_MAINTENANCE_CONSTRAINT}")

            if PAYLOAD_FLAG:
                '''Payload Optimization'''
                c = {} # c[(r, i, j)] => if in r^th trip, container i is allocated to jth wagon. Note: wagon_names are unique.
                for r in range(TRIPS):
                    for cont in cont_names:
                        cont_idx = cont_dict[cont]
                        expr = []
                        for wag in wag_names:
                            wag_idx = wagon_dict[wag]
                            c[(r, cont_idx, wag_idx)] = model.NewBoolVar(f'c{r}{cont_idx}{wag_idx}')
                            expr.append(c[(r, cont_idx, wag_idx)])
                        # A container can be assigned to at-most 1 wagon in a trip.
                        model.Add(cp_model.LinearExpr.Sum(expr) <= 1)

                print("Container can be assigned to at-most 1 wagon in a trip")

                for cont in cont_names:
                    cont_idx = cont_dict[cont]
                    expr1 = []
                    for r in range(TRIPS):
                        for wag in wag_names:
                            wag_idx = wagon_dict[wag]
                            expr1.append(c[(r, cont_idx, wag_idx)])
                    # A container can be assigned to a wagon in at-most 1 trip.
                    model.Add(cp_model.LinearExpr.Sum(expr1) <= 1)

                print("Container can be assigned to a wagon in at-most 1 trip")

                for r in range(TRIPS):
                    for wag in wag_names:
                        wag_idx = wagon_dict[wag]
                        k = train_dict[wag_train[wag_idx]]
                        expr20, expr40 = [], []
                        for cont in cont_names:
                            cont_idx = cont_dict[cont]
                            if sz_cont[cont_idx] == 20:
                                expr20.append(c[(r, cont_idx, wag_idx)])
                            elif sz_cont[cont_idx] == 40:
                                expr40.append(c[(r, cont_idx, wag_idx)])
                        # Currently assume all wagons are SS
                        # Note: This is different from the route wise SS/DS given in distance csv.
                        # In SS wagon, either 2 20 ft container or 1 40 ft container can go.
                        s_expr20 = cp_model.LinearExpr.Sum(expr20)
                        s_expr40 = cp_model.LinearExpr.Sum(expr40)
                        model.Add(s_expr40 <= 1)
                        model.Add(s_expr20 + s_expr40 <= 2)

                print("Wagon SS/DS constraint")

                for r in range(TRIPS):
                    for train in Trains:
                        k = train_dict[train]
                        for wag in wag_names:
                            wag_idx  = wagon_dict[wag]
                            expr, expr20, expr40 = [], [], []
                            for cont in cont_names:
                                cont_idx = cont_dict[cont]
                                expr.append(wt_cont[cont_idx] * c[(r, cont_idx, wag_idx)])
                            # Total weight of all containers assigned to a wagon <= wagon_weight
                            model.Add(cp_model.LinearExpr.Sum(expr) <= wag_wt[wag_idx])

                print("Payload Weight Constraint")

                for r in range(TRIPS):
                    for train in Trains:
                        k = train_dict[train]
                        L = locs
                        if r == 0:
                            L = [start_loc[train]]
                        for loc1 in L:
                            i = loc_dict[loc1]
                            for loc2 in locs:
                                j = loc_dict[loc2]
                                if i == j:
                                    continue
                                expr20, expr40 = [], []
                                for cont_idx20 in cont_ij_dict[(loc1, loc2, 20)]:
                                    for wag in wag_names:
                                        wag_idx = wagon_dict[wag]
                                        if train == wag_train[wag_idx]:
                                            expr20.append(c[(r, cont_idx20, wag_idx)])

                                for cont_idx40 in cont_ij_dict[(loc1, loc2, 40)]:
                                    for wag in wag_names:
                                        wag_idx = wagon_dict[wag]
                                        if train == wag_train[wag_idx]:
                                            expr40.append(c[(r, cont_idx40, wag_idx)])
                                # Link number of containers with variable y
                                model.Add(cp_model.LinearExpr.Sum(expr20) + 2 * cp_model.LinearExpr.Sum(expr40)  == y[(r, k, i, j, 20)] + y[(r, k, i, j, 40)])

                print("Number of 20ft/40ft containers allocated should map with aggregate 20ft/40ft pendency (TEU) evacuated by train.")

            if FORECAST_PEND:
              for train in Trains:
                  k = train_dict[train] # index of train
                  start_loc_idx = loc_dict[start_loc[train]] # starting location index of train
                  eta_train = Eta[k] # ETA of train (when the train arrives at its start_location)
                  for loc in locs:
                      j = loc_dict[loc]
                      if start_loc_idx == j or dist[start_loc_idx][j] == INF or time[start_loc_idx][j] == INF:
                          continue
                          # Time it takes the train to move from its start_loc to any location
                          # should less than or equal to the duration between forecast_date and eta_train.
                          # Note: forecast_date is the current chosen forecast pendency date.
                          # Note: All this is done in minutes.
                      model.Add(time[start_loc_idx][j] * x[(0, k, start_loc_idx, j)] - round(pd.Timedelta(forecast_date - eta_train).total_seconds() / 60.0) <= 0).OnlyEnforceIf(x[(0, k, start_loc_idx, j)])

            sload_expr = cp_model.LinearExpr.Sum(load_expr)
            sempty_expr = cp_model.LinearExpr.Sum(empty_expr)
            sdist_expr = cp_model.LinearExpr.Sum(dist_expr)
            sall_expr = cp_model.LinearExpr.Sum(all_expr)
            if obj_flag == 0:
                # Objective changed to max sum over(i, j, k)
                # Weightage_Load_Pend * {y_{rkij} * x_{rkij}} + {t_{rkij} * x{rkij}} + Weightage_Trains * x_{0kij}
                model.Maximize(Weightage_Load_Pend * sload_expr + sempty_expr + Weightage_Trains * sall_expr)
            elif obj_flag == 1:
                # Unscheduled_Trains (Minimize dist_ij + Maximize pend_jm)
                # Maximize (-dist_ij + pend_jm)
                usload_expr = cp_model.LinearExpr.Sum(uload_expr)
                usempty_expr = cp_model.LinearExpr.Sum(uempty_expr)
                usdist_expr = cp_model.LinearExpr.Sum(udist_expr)
                model.Maximize(Weightage_Load_Pend * usload_expr + usempty_expr + usdist_expr)

            print("Model Building Completed")
            end = tme.time()
            elapsed_time = (end - start) / 60.0
            print(f"Model_Building_Time = {round(elapsed_time, 2)} mins")
            solver = cp_model.CpSolver()
            solver.parameters.log_search_progress = False
            solver.parameters.cp_model_presolve = True
            solver.parameters.max_time_in_seconds = 120
            # solver.random_seed = 42
            print("Solving Started")
            status = solver.Solve(model)
            status_dict = {
            0: "UNKNOWN: The status of the model is still unknown. A search limit has been reached before any of the statuses below could be determined.",
            1: "MODEL_INVALID: The given CpModelProto didn't pass the validation step.",
            2: "FEASIBLE: A feasible solution has been found. But the search was stopped before we could prove optimality.",
            3: "INFEASIBLE: The problem has been proven infeasible.",
            4: "OPTIMAL: An optimal feasible solution has been found."
            }
            print(status_dict[status])
            if status == 2 or status == 4:
                print(f"Objective = {solver.ObjectiveValue()}")
                cols = ['Train', 'Trip_Num', 'Start', 'i', 'j', 'odr_days', 'Base', 'clse_rt', 'Pend', 'Evacuated', 'Stack', 'Wagons', 'Utilized', 'Capacity',
                        'dist[i][j]', 'dist[j][base]', 'rem_dist[train]',
                        'time[i][j]', 'time[j][base]', 'rem_time[train]', 'TXR_FLAG', 'TXR_DVar', 'TXR_TVar' ]

                df_out = pd.DataFrame(columns = cols) # Scheduled Trains
                df_out_1 = pd.DataFrame() # Unscheduled Trains
                trains_not_scheduled, start_loc_not_scheduled, pend_train_not_scheduled, eta_train_not_scheduled, closed_route_train = [], [], [], [], []
                num_scheduled_trains = 0
                for train in Trains:
                    k = train_dict[train]
                    base_idx = loc_dict[base_depot_dict[train]]
                    flag = 0
                    sd, st = 0, 0 # cummulative sums for dist and time
                    for r in range(TRIPS):
                        L  = locs
                        if r == 0:
                            L = [start_loc[train]]
                        for loc1 in L:
                            i = loc_dict[loc1]
                            for loc2 in locs:
                                j = loc_dict[loc2]
                                if i == j or dist[i][j] == INF or time[i][j] == INF:
                                  continue
                                if solver.Value(x[((r, k, i, j))]):
                                    flag = 1
                                    close_rt_flag = 0
                                    if (loc1, loc2) in closed_rt:
                                        close_rt_flag = 1
                                    TXR_FLAG = 0
                                    sd += dist[i][j]
                                    st += time[i][j]
                                    if (sd + dist[j][base_idx]) > Rem_Dist[k] or (st + time[j][base_idx]) > Rem_Time[k]:
                                        TXR_FLAG = 1
                                    capacity = wagons[train_dict[train]] * stack[i][j]
                                    utilized = solver.Value(y[(r, k, i, j, 20)]) + solver.Value(t[(r, k, i, j, 20)]) + solver.Value(y[(r, k, i, j, 40)]) + solver.Value(t[(r, k, i, j, 40)])
                                    trip_num =  r + 1
                                    x1, y1  = 0, 0
                                    if loc1 == start_loc[train] and loc2 == base_depot_dict[train]:
                                        x1, y1 = solver.Value(txr_dexpiry[k]), solver.Value(txr_texpiry[k])
                                    data = [train, trip_num, start_loc[train], loc1, loc2, odr_days[i][j], base_depot_dict[train], close_rt_flag,
                                            [pend[i][j][cont_sz_dict[20]], pend[i][j][cont_sz_dict[40]], empty_pend[i][j][cont_sz_dict[20]], empty_pend[i][j][cont_sz_dict[40]]],
                                            [solver.Value(y[(r, k, i, j, 20)]), solver.Value(y[(r, k, i, j, 40)]), solver.Value(t[(r, k, i, j, 20)]), solver.Value(t[(r, k, i, j, 40)])],
                                            stack[i][j], wagons[train_dict[train]], utilized, capacity, dist[i][j], dist[j][base_idx], Rem_Dist[k],
                                            time[i][j], time[j][base_idx], Rem_Time[k], TXR_FLAG, x1, y1 ]
                                    new_row = pd.DataFrame([data], columns = cols)
                                    df_out = pd.concat([df_out, new_row], ignore_index = True)
                    if flag:
                        num_scheduled_trains += 1
                    else:
                        trains_not_scheduled.append(train)
                        start_loc_not_scheduled.append(start_loc[train])
                        pend_train_not_scheduled.append((pend_sums[loc_dict[start_loc[train]]]))
                        eta_train_not_scheduled.append(Eta[train_dict[train]])
                        closed_route_train.append(closed_rt_train[k])

                df_out_1['Trains_Not_Scheduled'] = trains_not_scheduled
                df_out_1['closed_rt_train'] = closed_route_train
                df_out_1['Start_Loc'] = start_loc_not_scheduled
                df_out_1['Total Pendency'] = pend_train_not_scheduled
                df_out_1['ETA'] = eta_train_not_scheduled

            if (status == 2 or status == 4) and PAYLOAD_FLAG:
                cols1= ['Train', 'Trip_Num', 'cont_no', 'wagon_no', 'cont_sz', 'wt_cont', 'wagon_wt']
                df_out_cont = pd.DataFrame(columns = cols1)
                for r in range(TRIPS):
                    for cont in cont_names:
                        cont_idx = cont_dict[cont]
                        for wag in wag_names:
                            wag_idx = wagon_dict[wag]
                            if solver.Value(c[(r, cont_idx, wag_idx)]):
                                data = [wag_train[wag_idx], r + 1, cont, wag, sz_cont[cont_idx], wt_cont[cont_idx], wag_wt[wag_idx]]
                                new_row = pd.DataFrame([data], columns = cols1)
                                df_out_cont = pd.concat([df_out_cont, new_row], ignore_index = True)
                # df_out_cont.to_csv(f'./08032024_cont_details_{obj_flag}.csv', index = False)

            print("****************************************************")
            num_unscheduled_trains = len(Trains) - num_scheduled_trains
            print(f"Scheduled_Trains = {num_scheduled_trains}, Unscheduled_Trains = {num_unscheduled_trains}")
            # df_out.to_csv(f'./08032024_output_two_trips_dist_{obj_flag}.csv', index = False)
            # df_out_1.to_csv(f'./08032024_unscheduled_two_trips_dist_{obj_flag}.csv', index = False)
            # pend_df.to_csv(f'./08032024_pend_two_trips_dist_{obj_flag}.csv', index = False)
            pend_df_upd = get_pend_updated(pend_df, df_out)
            # pend_df_upd.to_csv(f'./08032024_pend_two_trips_dist_upd_{obj_flag}.csv', index = False)
            total_pend_evacuated = (int(solver.Value(sload_expr)) + int(solver.Value(sempty_expr)))//int(first_trip_const)
            total_dist_travelled = int(solver.Value(sdist_expr))
            return df_out, df_out_1, pend_df_upd, total_pend_evacuated, total_dist_travelled



        def data_prep(df_dist_time, df_pendency, df_train_curr_plan, container_df, wagon_df):
            # Distance-Time data
            # In stack, SS = 90 and DS = 180.
            # Dist is the rounded off Distance and Time_min is in minutes.
            # NULL values in Time_min is replaced by (distance between this route / average speed of train)
            df_dist_time.rename(columns={'origin_code':'Origin','destination_code':'Destination','rational_distance':'Distance', 'Active_Route':'active_rt'}, inplace = True)
            df_dist_time['Stack'] = df_dist_time['ss_ds'].apply(lambda x: 90 if x == 'SS' else (180 if x == 'DS' else None))
            df_dist_time['Time_min'] = round(60 * df_dist_time['r_tat_sla'])
            df_dist_time['Dist'] = round(df_dist_time['Distance'])
            valid_rows = df_dist_time['Time_min'].notnull()  # boolean mask for non-null values in 'time'
            average_speed = df_dist_time.loc[valid_rows, 'Dist'].sum() / df_dist_time.loc[valid_rows, 'Time_min'].sum()
            df_dist_time['Time_min'].fillna(df_dist_time['Dist'] / average_speed,inplace=True)
            # Pendency data
            df_pendency.rename(columns={'pendency':'Pendency','to_terminal_code':'Destination','booking_location_code':'Source'}, inplace = True)
            df_pendency['Pendency'] = df_pendency['Pendency'].apply(lambda x: max(0,x))
            df_pendency['empty_pendency'] = df_pendency['empty_pendency'].apply(lambda x: max(0,x))

            # Train Current Status data
            # Rational distance value are replaced by 0 because these trains were at the Terminal. They didn't cover any distance.
            # Actual remaining km = Remaining_kms - Distance already covered (rational_distance)
            df_train_curr_plan.rename(columns={'FOIS_ETA':'ETA','rake_name':'Train','origin_code':'Origin','destination_code':'Destination','TXR_Kms_Remaining':'Remaining_kms'},inplace = True)
            df_train_curr_plan['rational_distance'].fillna(0,inplace=True)
            df_train_curr_plan['Actual_remaining_kms'] = round(df_train_curr_plan['Remaining_kms'])
            df_train_curr_plan["remaining_min"] = pd.to_datetime(df_train_curr_plan["TXR_Due_Date"]) - pd.to_datetime(df_train_curr_plan["ETA"])
            df_train_curr_plan["remaining_min"] = round((60*df_train_curr_plan["remaining_min"])//pd.Timedelta(hours=1))
            df_train_curr_plan.sort_values(by = ["Destination","ETA"], ascending = True, inplace = True)
            df_train_curr_plan["rank"] = df_train_curr_plan.groupby("Destination")["ETA"].rank(method="dense", ascending=False)
            return df_dist_time, df_pendency, df_train_curr_plan, container_df, wagon_df

        dist_time_df, pend_df, train_curr_plan_df, container_df, wagon_df = data_prep(dist_time_df, pend_df, train_curr_plan_df, container_df, wagon_df)

        locs, loc_dict = get_loc(dist_time_df, pend_df, train_curr_plan_df) # locations are indexed from [0, num_loc - 1]
        Trains, train_dict, Rem_Dist, Rem_Time, start_loc, wagons, Eta, Eta_rank = get_trains_rem_dist_time(train_curr_plan_df) # trains are indexed from [0, num_trains - 1]
        base_loc, base_depot_dict = get_base_depot(train_curr_plan_df, Trains, train_dict)
        dist, time, stack, closed_rt, closed_rt_train, dist_org, time_org = get_dist_time_stack(dist_time_df, len(locs), loc_dict, locs, base_loc, Trains, train_dict, start_loc)
        pend, pend_sums, empty_pend, odr_days = get_pendency(pend_df, len(locs), loc_dict)

        # Container and Wagon Details
        cont_names, cont_dict, src_cont, dest_cont, sz_cont, wt_cont, cont_ij_dict = get_container_details(container_df)
        wag_names, wagon_dict, wag_train, wag_wt = get_wagon_details(wagon_df)

        num_trains, num_stations, num_base, num_loc = len(Trains), len(locs) - len(base_loc), len(base_loc), len(locs)
        print(f"Total_Trains = {len(Trains)}: Total_Stations = {len(locs) - len(base_loc)}: Total_Base_Locs = {len(base_loc)}")
        print(f"Total_Containers = {len(cont_names)}, Total_Wagons = {len(wag_names)}")
        print(f"Model_Building_Started, obj_flag = {obj_flag}")

        # Solving the model
        total_pend_evacuated, total_dist_travelled = 0, 0
        forecast_date = pd.to_datetime(forecast_date_var)
        df_out, df_out_1, pend_df_upd, pend_evacuated, dist_travelled = optimize(locs, Trains, train_dict,
                    dist_org, time_org, dist, time, Rem_Dist, Rem_Time, loc_dict, base_loc, base_depot_dict, pend, empty_pend, stack, start_loc,
                    pend_sums, odr_days, wagons, Eta, Eta_rank, closed_rt, closed_rt_train, dist_time_df, pend_df, train_curr_plan_df, container_df, wagon_df,
                    cont_names, cont_dict, src_cont, dest_cont, sz_cont, wt_cont, cont_ij_dict, wag_names, wagon_dict, wag_train, wag_wt,
                    total_pend_evacuated, total_dist_travelled, obj_flag, forecast_date)

        print(f"Total Pendency Evacuated = {pend_evacuated} / {int(df_out['Utilized'].sum())} and Total Distance Travelled = {dist_travelled}")
        print("****************************************************")

        pend_upd, pend_sums_upd, empty_pend_upd, odr_upd = get_pendency(pend_df_upd, len(locs), loc_dict)

        pend_df_upd_unsch = pend_df_upd.copy().reset_index(drop = True)

        final_unsch_trains = df_out_1.copy()

        # Additional changes for the output
        df_out.rename(columns = {"TXR_FLAG":"STATUS_FLAG"}, inplace = True)
        df_out.STATUS_FLAG = (-1)*df_out.STATUS_FLAG

        return df_out, df_out_1, final_unsch_trains, pend_df_upd_unsch

      ################################################################################
      # Data Prep for Optimiser
      ################################################################################
      ################################################################################
      # Data Prep for Optimiser
      ################################################################################
      ################################################################################
      # Data Prep for Optimiser
      ################################################################################

      import pandas as pd
      import numpy as np
      import warnings
      warnings.simplefilter("ignore")
      pd.set_option('display.max_rows', 500)
      pd.set_option('display.max_columns', 1000)
      from datetime import datetime, timedelta

      today_filename = datetime.today().strftime("%d%m%Y")

      # today_filename = "24042024"
      # train_current_status_file_name = "/content/drive/MyDrive/Filesfrom27thOct/"+today_filename+"_train_current_status.csv"
      # distance_data_file_name = "/content/drive/MyDrive/Filesfrom27thOct/"+today_filename+"_distance_data.csv"
      # pendency_data_file_name = "/content/drive/MyDrive/Filesfrom27thOct/"+today_filename+"_pendency_data.csv"
      # forecast_pend_file_name = "/content/drive/MyDrive/Filesfrom27thOct/"+today_filename+"_forecast_data.csv"
      # via_rt_file_name = "/content/drive/MyDrive/Filesfrom27thOct/"+"_via_rt_data.csv"
      # atTrakes_prev_terminals_file_name = "/content/drive/MyDrive/Filesfrom27thOct/"+today_filename+"_atTrakes_prev_terminals_data.csv"

      # The following has been done for payload, need to read payload data once the payload code is activated to be used
      container_df = pd.DataFrame(columns = ['status', 'cont_no', 'cont_size', 'booking_location_code', 'to_terminal_code', 'aging_in_hrs', 'movement_types', 'max_age', 'rational_distance', 'ss_ds', 'r_tat_sla', 't_tat_sla', 'full_wt'])
      wagon_df = pd.DataFrame(columns = ['rake_name', 'wagon_no', 'permissible_wt']) # need to add container_df and wagon_df, pendency_data must sync with container_df file, number of wagons in train must sync with wagon_df


      forecast_pend = forecast_pend_copy.copy()



      today = datetime.today().strftime("%Y-%m-%d")
      train_current_status1 = train_current_status_copy.reset_index(drop = True)
      pendency_data = pendency_data_copy[pendency_data_copy.odr_days <= 0].reset_index(drop = True)
      distance_data = distance_data_copy.reset_index(drop = True)
      via_rt = via_rt.reset_index(drop = True)

      # dates in date format
      train_current_status1["TXR_Due_Date"] = pd.to_datetime(train_current_status1["TXR_Due_Date"])
      train_current_status1["flag"] = 1

      # drop the rows from pendency data if destination or origin is na.
      pendency_data["flag"] = 1
      pendency_data['pendency'] = pendency_data['pendency'].apply(lambda x: max(0,x))
      pendency_data['empty_pendency'] = pendency_data['empty_pendency'].apply(lambda x: max(0,x))
      for i in range(len(pendency_data)):
        # if origin or destination is missing then flag is 0
        if ((pd.isna(pendency_data.loc[i,"booking_location_code"]))) or (pd.isna(pendency_data.loc[i,"to_terminal_code"])) or (pd.isna(pendency_data.loc[i,"pendency"])):
          pendency_data.loc[i,"flag"] = 0
        # if both loaded and empty pendency is negative then flag is 0
        if ((pendency_data.loc[i,"pendency"] <= 0) & (pendency_data.loc[i,"empty_pendency"] <= 0)):
          pendency_data.loc[i,"flag"] = 0
      pendency_data = pendency_data[pendency_data.flag == 1].reset_index(drop = True)

      # drop the rows from distance data if destination or origin is na.
      distance_data.rename(columns = {"active_rt":"Active_Route"}, inplace = True)
      distance_data["flag"] = 1
      # take only the active routes
      distance_data = distance_data[distance_data.Active_Route == 1].reset_index(drop = True)
      for i in range(len(distance_data)):
        # if origin, destination or rational distance is missing then flag 0
        if ((pd.isna(distance_data.loc[i,"origin_code"]))) or (pd.isna(distance_data.loc[i,"destination_code"])) or (pd.isna(distance_data.loc[i,"rational_distance"])):
          distance_data.loc[i,"flag"] = 0
      distance_data = distance_data[distance_data.flag == 1].reset_index(drop = True)

      loc = list(set(list(distance_data.origin_code) + list(distance_data.destination_code)))
      for i in range(len(train_current_status1)):
        # if origin or destination not in all locations available in route master then flag 0
        if train_current_status1.loc[i,"origin_code"] not in loc:
          train_current_status1.loc[i,"flag"] = 0
        if train_current_status1.loc[i,"destination_code"] not in loc:
          train_current_status1.loc[i,"flag"] = 0
        # if txr due date is not available then flag is 0
        if (train_current_status1.loc[i,"TXR_Due_Date"] is pd.NaT):
          train_current_status1.loc[i,"flag"] = 0
        # if txr kms is not available for a train then flag is 0
        if ((pd.isna(train_current_status1.loc[i,"TXR_Kms_Remaining"]))| ((train_current_status1.loc[i,"TXR_Kms_Remaining"]) == "None")| ((train_current_status1.loc[i,"TXR_Kms_Remaining"]) == "NA")):
          train_current_status1.loc[i,"TXR_Kms_Remaining"] = -1
          train_current_status1.loc[i,"flag"] = 0
        # if txr kms is "END-TO-END" then txr is negative already
        if (train_current_status1.loc[i,"TXR_Kms_Remaining"] == "END TO END"):
          train_current_status1.loc[i,"TXR_Kms_Remaining"] = -1
        # if ((train_current_status1.loc[i,"destination_code"] == train_current_status1.loc[i,"base_depot_code"]) & ((train_current_status1.loc[i,"TXR_Due_Date"] <= pd.to_datetime(today)))):
        #   train_current_status1.loc[i,"TXR_Due_Date"] = pd.to_datetime(today)
        # if ((train_current_status1.loc[i,"destination_code"] == train_current_status1.loc[i,"base_depot_code"]) & (int(train_current_status1.loc[i,"TXR_Kms_Remaining"]) <= 0)):
        #  train_current_status1.loc[i,"TXR_Kms_Remaining"] = -1
        if ((train_current_status1.loc[i,"destination_code"] == train_current_status1.loc[i,"origin_code"])):
          train_current_status1.loc[i,"rational_distance"] = 0

      train_current_status = train_current_status1[train_current_status1.flag == 1].reset_index(drop = True)

      train_current_status["TXR_Kms_Remaining"] = train_current_status.TXR_Kms_Remaining.astype('float64').round(0)
      train_current_status["rational_distance"] = train_current_status["rational_distance"].astype('float64').round(0)
      train_current_status["TXR_KmsRem_CurrDest"] = train_current_status["TXR_Kms_Remaining"]
      train_current_status["TXR_DueRem_CurrDest"] = train_current_status["TXR_Due_Date"] - pd.to_datetime(now)
      train_current_status["TXR_DueRem_CurrDest"] = train_current_status["TXR_DueRem_CurrDest"].apply(day_time_to_min)

      train_current_status_copy1 = train_current_status.copy() #copy of all flag 1 trains
       ################################################################################
      # Recalculate pendency and train current status and saving the data to Big Query
      ################################################################################
      
      if recalculate:
        ###retrive the pendency data, train current status and schedule from bq
        adid=email
        re_pendency_query=f"""with cte as (SELECT * except(adid,load_ts),RANK() OVER ( PARTITION BY adid ORDER BY load_ts DESC ) as rn FROM `apsez-svc-prod-datalake.logistics_cleansed.layer2_train_pendency_data_h` where adid='{adid}')select  *except(rn)from cte  where rn=1"""
        query_job_re_pendency=client.query(re_pendency_query).result()
        re_train_query=f"""with cte as (SELECT * except(adid,load_ts),RANK() OVER ( PARTITION BY adid ORDER BY load_ts DESC ) as rn FROM `apsez-svc-prod-datalake.logistics_cleansed.layer2_train_current_status_h` where adid='{adid}')select  *except(rn)from cte  where rn=1"""
        query_job_re_train=client.query(re_train_query).result()
        pendency_data_up_fx=query_job_re_pendency.to_dataframe()
        pendency_data_up_fx.cont_size = pendency_data_up_fx.cont_size.astype('float64')
        pendency_data_up_fx.odr_days = pendency_data_up_fx.odr_days.astype('float64')
        train_current_status_fx=query_job_re_train.to_dataframe()
        train_current_status_fx['FOIS_ETA']=pd.to_datetime(train_current_status_fx['FOIS_ETA']).dt.tz_localize(None)
        train_current_status_fx.TXR_Due_Date= pd.to_datetime(train_current_status_fx.TXR_Due_Date,format='%Y-%m-%d')

        ###update the train current status
        train_current_status_re=train_current_status_fx.loc[(train_current_status_fx.rake_name.isin(list(final_df_changed[final_df_changed.recalculate!=1].rake_name)))].reset_index(drop=True)
        ###update the pendency data
        ###idea: substract the pendeny of the fixed/changed routes and pendency from the old pendency as those pendency are already planned by user
        final_df_need=final_df_changed[final_df_changed.recalculate!=0].reset_index(drop=True)
        
        for i in range(len(final_df_need)):
          trip_details=final_df_need.loc[i,"next_trip_trip1"].split('-')
          trip_origin=trip_details[0]
          trip_destination=trip_details[1]
          if len(trip_details)>=3:
            trip_destination=trip_details[len(trip_details)-2]
          loaded_TEUs_evacuated_20_trip1=final_df_need.loc[i,"loaded_teus_evacuated_20_trip1"]
          loaded_TEUs_evacuated_40_trip1=final_df_need.loc[i,"loaded_teus_evacuated_40_trip1"]
          empty_TEUs_evacuated_20_trip1=final_df_need.loc[i,"empty_teus_evacuated_20_trip1"]
          empty_TEUs_evacuated_40_trip1=final_df_need.loc[i,"empty_teus_evacuated_40_trip1"]
          pendency_data_up_fx=update_recalculate_pendency(pendency_data_up_fx,loaded_TEUs_evacuated_20_trip1,loaded_TEUs_evacuated_40_trip1,empty_TEUs_evacuated_20_trip1,empty_TEUs_evacuated_40_trip1, trip_origin, trip_destination)
          
        pendency_data=pendency_data_up_fx
        train_current_status=train_current_status_re
      else:
         # save the pendency data and train current status to bq
        train_current_status['adid'] = email
        train_current_status['load_ts'] = pd.to_datetime(datetime.now(timezone("Asia/Kolkata"))).tz_localize(None)
        train_current_status['FOIS_ETA'] = pd.to_datetime(train_current_status['FOIS_ETA'])
        train_current_status['unts'] = pd.to_numeric(train_current_status["unts"], errors='coerce').fillna(0).astype('int64')
        schema = [ {"name": "FOIS_ETA", "type": "TIMESTAMP" }, {"name": "ob_r",  "type": "STRING" }, {"name": "ob_t",  "type": "STRING" }, {"name": "ob_train_no",  "type": "STRING" }, {"name": "rake_name",  "type": "STRING" }, {"name": "rake_status",  "type": "STRING" }, {"name": "status",  "type": "STRING" }, {"name": "origin_code",  "type": "STRING" }, {"name": "destination_code",  "type": "STRING" }, {"name": "transit_sla",  "type": "FLOAT" }, {"name": "t_tat_sla",  "type": "FLOAT" }, {"name": "unts",  "type": "INTEGER" }, {"name": "actual_arrival",  "type": "TIMESTAMP" }, {"name": "placement_date",  "type": "TIMESTAMP" }, {"name": "ib_train_no",  "type": "STRING" }, {"name": "TXR_Due_Date",  "type": "DATE" }, {"name": "TXR_Kms_Remaining",  "type": "FLOAT" }, {"name": "base_depot_code",  "type": "STRING" }, {"name": "Loaded_Teus_20",  "type": "INTEGER" }, {"name": "Loaded_Teus_40",  "type": "INTEGER" }, {"name": "Empty_Teus_20",  "type": "INTEGER" }, {"name": "Empty_Teus_40",  "type": "INTEGER" }, {"name": "prev_origin",  "type": "STRING" }, {"name": "prev_dest",  "type": "STRING" }, {"name": "rational_distance",  "type": "FLOAT" }, {"name": "ss_ds",  "type": "STRING" }, {"name": "t_tat_sla_destination",  "type": "FLOAT" }, {"name": "flag",  "type": "INTEGER" }, {"name": "TXR_KmsRem_CurrDest",  "type": "FLOAT" }, {"name": "TXR_DueRem_CurrDest",  "type": "INTEGER" }, {"name": "adid",  "type": "STRING" }, {"name": "load_ts",  "type": "TIMESTAMP" } ]
        train_current_status.to_gbq('apsez-svc-prod-datalake.logistics_cleansed.layer2_train_current_status_h',project_id='apsez-svc-prod-datalake',table_schema=schema,if_exists='append')
        pendency_data['adid'] = email
        pendency_data['load_ts'] = pd.to_datetime(datetime.now(timezone("Asia/Kolkata"))).tz_localize(None)
        print(pendency_data.dtypes)
        print(pendency_data.head())
        schema = [{"name": "booking_location_code","type": "STRING"},{"name": "to_terminal_code","type": "STRING"},{"name": "cont_size","type": "INTEGER"},{"name": "pendency","type": "INTEGER"},{"name": "empty_pendency","type": "INTEGER"},{"name": "odr_days","type": "INTEGER"},{"name": "flag","type": "INTEGER"},{"name": "adid","type": "STRING"},{"name": "load_ts","type": "TIMESTAMP"} ]
        pendency_data.to_gbq('apsez-svc-prod-datalake.logistics_cleansed.layer2_train_pendency_data_h',project_id='apsez-svc-prod-datalake',table_schema=schema,if_exists='append')


      # train_current_status_copy1

      ###############################################################################################################################################
      # Direct Indirect Route Calculation
      ###############################################################################################################################################
      # Import pandas library
      import pandas as pd
      import heapq
      route_data = distance_data_copy[distance_data_copy.active_rt==1].copy().reset_index(drop = True)
      route_data.rename(columns = {"origin_code":"origin","destination_code":"destination",
                                  "rational_distance":"route_distance_in_km",
                                  "r_tat_sla":"route_distance_in_hours"}, inplace = True)
      route_data.route_distance_in_hours = route_data.route_distance_in_hours*60
      # Create a list of unique locations
      location_list = list(set(set(route_data["origin"]).union(set(route_data["destination"]))))
      # Create a list of primary locations
      primary_location_list = list(train_current_status.base_depot_code.unique())
      # Create an empty dataframe to store the output
      output = pd.DataFrame(columns=["origin", "destination", "min_km", "min_hrs"])
      # Loop through each location in the list
      for location in location_list:
          # Loop through each primary location in the list
          for primary_location in primary_location_list:
              # If the location is the same as the primary location, the distance and time are zero
              if location == primary_location:
                  min_km = 0
                  min_hrs = 0
              # Otherwise, find the shortest path from the location to the primary location using Dijkstra's algorithm
              else:
                  # Initialize a dictionary to store the distances and times from the location to other locations
                  dist = {loc: float("inf") for loc in location_list}
                  time = {loc: float("inf") for loc in location_list}
                  # Set the distance and time from the location to itself as zero
                  dist[location] = 0
                  time[location] = 0
                  # Initialize a set to store the visited locations
                  visited = set()
                  # Initialize a priority queue to store the locations and their distances and times
                  queue = [(0, 0, location)]
                  # Loop until the queue is empty or the primary location is visited
                  while queue and primary_location not in visited:
                      # Pop the location with the smallest distance and time from the queue
                      d, t, loc = heapq.heappop(queue)
                      # Mark the location as visited
                      visited.add(loc)
                      # Loop through the neighbors of the location in the route data
                      for index, row in route_data[route_data["origin"] == loc].iterrows():
                          # Get the neighbor, the distance and the time
                          neighbor = row["destination"]
                          distance = row["route_distance_in_km"]
                          duration = row["route_distance_in_hours"]
                          # If the neighbor is not visited and the distance and time are smaller than the current values, update them
                          if neighbor not in visited and d + distance < dist[neighbor] and t + duration < time[neighbor]:
                              dist[neighbor] = d + distance
                              time[neighbor] = t + duration
                              # Push the neighbor and its distance and time to the queue
                              heapq.heappush(queue, (dist[neighbor], time[neighbor], neighbor))
                  # Get the minimum distance and time from the location to the primary location
                  min_km = dist[primary_location]
                  min_hrs = time[primary_location]
              # Append the origin, destination, min_km and min_hrs to the output dataframe
              df_dict_series = pd.DataFrame({"origin": [location],"destination": [primary_location],"min_km": [min_km],"min_hrs": [min_hrs]})
              output = pd.concat([output,df_dict_series], axis = 0, ignore_index=True)
      # Print the output dataframe
      route_df = output.copy().reset_index(drop = True)
      route_df.route = route_df.origin + "-" + route_df.destination
      origin_base_km_min_dict = dict(zip(route_df.route, (zip(route_df['min_km'],route_df['min_hrs']))))
      ############################################################################################################################################################################
      # Shortest active route to base locations from each possible terminal
      ############################################################################################################################################################################
      import pandas as pd
      import numpy as np
      import networkx as nx
      rt_data = distance_data_copy[distance_data_copy.active_rt == 1].copy()
      rt_data.rename(columns = {"origin_code":"origin", "destination_code":"destination", "rational_distance":"distance_in_km", "r_tat_sla":"time_in_hours"}, inplace = True)
      # Extract unique locations
      all_locations = set(rt_data['origin']) | set(rt_data['destination'])
      # Define base locations (replace with your actual base locations)
      base_locations = list(train_current_status.base_depot_code.unique())
      # Calculate minimum distance using Dijkstra's algorithm
      G = nx.DiGraph()
      for _, row in rt_data.iterrows():
          G.add_edge(row['origin'], row['destination'], weight=row['distance_in_km'])
      min_distances = {}
      for origin_loc in all_locations:
          min_distances[origin_loc] = {}
          for base_loc in base_locations:
              try:
                  min_dist = nx.shortest_path_length(G, source=origin_loc, target=base_loc, weight='weight')
                  min_hrs = nx.shortest_path_length(G, source=origin_loc, target=base_loc, weight='time_in_hours')
              except nx.NetworkXNoPath:
                  min_dist, min_hrs = 0, 0
              min_distances[origin_loc][base_loc] = {'min_dist': min_dist, 'min_hrs': min_hrs}
      # Create output DataFrame
      output_data = []
      for origin_loc, base_info in min_distances.items():
          for base_loc, info in base_info.items():
              output_data.append({
                  'origin_loc': origin_loc,
                  'base_loc': base_loc,
                  'min_dist': info['min_dist'],
                  'min_hrs': info['min_hrs'],
                  'via_route': nx.shortest_path(G, source=origin_loc, target=base_loc)
              })
      loc_to_base = pd.DataFrame(output_data)
      ############################################################################################################################################################################
      # Shortest active route to parking locations from each possible terminal
      ############################################################################################################################################################################
      import pandas as pd
      import numpy as np
      import networkx as nx
      rt_data = distance_data_copy[distance_data_copy.active_rt == 1].copy()
      rt_data.rename(columns = {"origin_code":"origin", "destination_code":"destination", "rational_distance":"distance_in_km", "r_tat_sla":"time_in_hours"}, inplace = True)
      # Define base locations (replace with your actual base locations)
      ad_terminals = ["PDLL","PALB","ALIK","MAAM","ICAK","PATP","AFAS"]
      # ad_terminals = ["PDLL","PALB","ALIK","MAAM","ICAK","PATP","AFAS","ALGV"]
      # Extract unique locations
      all_locations = set(set(rt_data['origin']) | set(rt_data['destination']) | set(ad_terminals))
      # Calculate minimum distance using Dijkstra's algorithm
      G = nx.DiGraph()
      for _, row in rt_data.iterrows():
        if row['active_rt']:
          G.add_edge(row['origin'], row['destination'], weight=row['distance_in_km'])
      min_distances = {}
      for origin_loc in all_locations:
          min_distances[origin_loc] = {}
          for base_loc in ad_terminals:
              try:
                  min_dist = nx.shortest_path_length(G, source=origin_loc, target=base_loc, weight='weight')
                  min_hrs = nx.shortest_path_length(G, source=origin_loc, target=base_loc, weight='time_in_hours')
              except nx.NetworkXNoPath:
                  min_dist, min_hrs = 0, 0
              min_distances[origin_loc][base_loc] = {'min_dist': min_dist, 'min_hrs': min_hrs}
      # Create output DataFrame
      output_data = []
      for origin_loc, base_info in min_distances.items():
          for base_loc, info in base_info.items():
              output_data.append({
                  'origin_loc': origin_loc,
                  'base_loc': base_loc,
                  'min_dist': info['min_dist'],
                  'min_hrs': info['min_hrs'],
                  'via_route': nx.shortest_path(G, source=origin_loc, target=base_loc)
              })
      loc_to_parking = pd.DataFrame(output_data)
      loc_to_parking.rename(columns = {"origin_loc":"origin_code","min_dist":"rational_distance", "base_loc":"destination_code"}, inplace = True)
      distance_data_temp = distance_data[distance_data.Active_Route == 1].copy().reset_index(drop = True)
      distance_data_temp["first_stop"] = distance_data["origin_code"]+"-"+distance_data["destination_code"]
      distance_data_temp.drop(columns = ["origin_code","destination_code","rational_distance"], inplace = True)
      for i in range(len(loc_to_parking)):
        via = loc_to_parking.loc[i,"via_route"][0:2]
        route = ("-").join(via)
        loc_to_parking.loc[i,"first_stop"] = route
      loc_to_parking = loc_to_parking.merge(distance_data_temp, on = "first_stop", how = "inner").reset_index(drop = True)
      route_df_adt = loc_to_parking.sort_values(by = ["origin_code","rational_distance"]).drop_duplicates(subset = ['origin_code'], keep = 'first').reset_index(drop = True)
      route_df_adt = splt_route(route_df_adt,'via_route')
      route_df_adt = route_df_adt[["origin_code","destination_code","rational_distance","min_hrs","via_route"]]

 
       
      ################################################################################
      # First schedule for all trains
      ################################################################################
      dist_time_df, pend_df, train_curr_plan_df, container_df, wagon_df = distance_data.copy().reset_index(drop = True), pendency_data.copy().reset_index(drop = True), train_current_status.copy().reset_index(drop = True), container_df.copy(), wagon_df.copy()
      # If Trips = 2 and up_to_trips = True then up to 2 trips optimizer will schedule (if false then exactly 2 trips will be scheduled)
      TRIPS, UP_TO_TRIPS = 2, True
      obj_flag = 0
      IGNORE_CAPACITY_CONSTRAINT, IGNORE_STRONG_MAINTENANCE_CONSTRAINT, IGNORE_CLOSED_ROUTE, PAYLOAD_FLAG, FORECAST_PEND = False, False, True, False, False
      forecast_date_var = datetime.today().strftime("%d/%m/%Y") #pd.to_datetime(datetime.today().strftime("%d/%m/%Y"))
      df_out, df_out_1, final_unsch_trains, pend_df_upd_unsch = optimizer(dist_time_df, pend_df, train_curr_plan_df, container_df, wagon_df,
                                                                          TRIPS, obj_flag, UP_TO_TRIPS, IGNORE_CAPACITY_CONSTRAINT,
                                                                          IGNORE_STRONG_MAINTENANCE_CONSTRAINT, IGNORE_CLOSED_ROUTE,
                                                                          PAYLOAD_FLAG, FORECAST_PEND, forecast_date_var)
      # df_out - trip1,trip2
      # df_out_1, final_unsch_trains - unscheduled rakes which could not be scheduled for trip1,trip2
      # pend_df_upd_unsch - remaining pendency after all the above rakes are scheduled
      df_out = concat_outputs(df_out)
      df_out

      ################################################################################
      # TRANSHIPMENT - HUB PENDENCY
      ################################################################################
      # run the first optimizer (done by this step)
      # find out rakes which carry less than full capacity for which hub route is present
      # unschedule those rakes, add back the pendency for those routes to output pendency data of first optimizer
      # find out routes which are common between pendency_data and via_rt data (where route type in via_rt is transshipment),
      # group by and modify those as origin and via instead of origin and destination
      # To handle - Transhipment Hub Pendency
      # rakes where full capacity isn't utlized
      unscheduled_trains_lesscap = []
      # lesscap_trains dictionary includes all the rakes where the capacity is not fully utilized and all the rakes from df_out_1 (unscheduled rakes)
      lesscap_trains_df = (df_out[df_out.Utilized != df_out.Capacity])  # less cap trains
      # un = pd.DataFrame()
      un = pd.DataFrame(columns = ["Train","Source"])
      if len(final_unsch_trains) > 0:
        un = final_unsch_trains.copy()  # unscheduled trains
        un.rename(columns = {"Trains_Not_Scheduled":"Train", "Start_Loc":"Source"}, inplace = True)
      if len(lesscap_trains_df) <= 0:
        lesscap_trains_df = pd.DataFrame(columns = un.columns.to_list())
      lesscap_trains_df = pd.concat([lesscap_trains_df[["Train","Source"]],un[["Train","Source"]]]).reset_index(drop = True)
      lesscap_trains = (lesscap_trains_df.set_index('Train')['Source'].to_dict())
      via_rt_origins = via_rt.origin_code.unique().tolist()
      # unscheduling rakes which are at via-rt origins only
      for i in lesscap_trains:
        if lesscap_trains[i] in via_rt_origins:
          unscheduled_trains_lesscap.append(i)
      # if any train with unutilized capacity is found then only proceed
      if len(unscheduled_trains_lesscap) > 0:
        # df_out of all less capacity trains
        df_out_x = df_out[df_out.Train.isin(unscheduled_trains_lesscap)].reset_index(drop = True)
        ##############################################################################
        # PENDENCY_DATA DATA
        ##############################################################################
        # add back the pendency for routes found above (where pendency_data is output of pendency_data after first optimizer is run)
        for i in range(df_out_x.shape[0]):
          source = df_out_x.loc[i,"Source"]
          destination = df_out_x.loc[i,"Destination"]
          loaded_pend_cleared_20 = df_out_x.loc[i,"Loaded_Pend_Cleared_20"]
          loaded_pend_cleared_40 = df_out_x.loc[i,"Loaded_Pend_Cleared_40"]
          odr_days_20 = df_out_x.loc[i,"odr_days_20"]
          emp_pend_cleared_20 = df_out_x.loc[i,"Empty_Pend_Cleared_20"]
          emp_pend_cleared_40 = df_out_x.loc[i,"Empty_Pend_Cleared_40"]
          odr_days_40 = df_out_x.loc[i,"odr_days_40"]
          # pend_df_upd is the updated pendency after first optimizer is run
          for j in range(pend_df_upd_unsch.shape[0]):
            if ((pend_df_upd_unsch.loc[j,"Source"] == source) & (pend_df_upd_unsch.loc[j,"Destination"] == destination) & ((loaded_pend_cleared_20 > 0) or (emp_pend_cleared_20 > 0))) :
              if ((pend_df_upd_unsch.loc[j,"cont_size"] == 20.0) & (pend_df_upd_unsch.loc[j,"odr_days"] == odr_days_20)) :
                pend_df_upd_unsch.loc[j,"Pendency"] += int(loaded_pend_cleared_20)               # add back loaded pendency
                pend_df_upd_unsch.loc[j,"empty_pendency"] += int(emp_pend_cleared_20)            # add back empty pendency
            if ((pend_df_upd_unsch.loc[j,"Source"] == source) & (pend_df_upd_unsch.loc[j,"Destination"] == destination) & ((loaded_pend_cleared_40 > 0) or (emp_pend_cleared_40 > 0))) :
              if ((pend_df_upd_unsch.loc[j,"cont_size"] == 40.0) & (pend_df_upd_unsch.loc[j,"odr_days"] == odr_days_40)):
                pend_df_upd_unsch.loc[j,"Pendency"] += int(loaded_pend_cleared_40)               # add back loaded pendency
                pend_df_upd_unsch.loc[j,"empty_pendency"] += int(emp_pend_cleared_40)            # add back empty pendency
        # unschedule rakes where full capacity isn't utilized are removed from scheduled trains list
        df_out = df_out[~df_out.Train.isin(unscheduled_trains_lesscap)].reset_index(drop = True)
        schedule1_x = df_out.copy()
        # delete the previous outputs
        del df_out
        # find out routes which are common between pendency_data and via_rt data (where route type in via_rt is Transhipment-Hub),
        pend_df_upd_x = pend_df_upd_unsch.merge(via_rt[via_rt.route_type != "Maintenance"][["origin_code","destination_code","via","route_type"]]
                                          , left_on = ["Source","Destination"]
                                          , right_on = ["origin_code","destination_code"]
                                          , how = 'left')
        pend_df_upd_x.via = pend_df_upd_x.via.fillna(pend_df_upd_x.Destination)
        # group by and modify those as origin and via instead of origin and destination for "Transhipment-Hub" type via routes
        for i in range(pend_df_upd_x.shape[0]):
          if pend_df_upd_x.loc[i,"route_type"] == "Transhipment-Indirect":
            continue
          pend_df_upd_x.loc[i,"Destination"] = pend_df_upd_x.loc[i,"via"]
        pend_df_upd_x = pend_df_upd_x.groupby(["Source","Destination","cont_size"]).agg({"Pendency":"sum","empty_pendency":"sum","odr_days":"min"}).reset_index()
        new_df_pendency = (pendency_data[["booking_location_code", "to_terminal_code", "odr_days","cont_size"]].merge(pend_df_upd_x[["Pendency", "empty_pendency", "Source", "Destination", "odr_days", "cont_size"]], left_on = ["booking_location_code","to_terminal_code","odr_days","cont_size"], right_on = ["Source","Destination","odr_days","cont_size"], how = 'outer'))[["Pendency","empty_pendency","Source","Destination","odr_days","cont_size"]]
        new_df_pendency = new_df_pendency.dropna().reset_index(drop = True)
        new_df_pendency = new_df_pendency[(new_df_pendency.Pendency > 0) | (new_df_pendency.empty_pendency > 0)]
        pend_df = new_df_pendency.copy().reset_index(drop = True)
        ##############################################################################
        # DIST TIME DATA
        ##############################################################################
        dist_time_df = distance_data.copy().reset_index(drop = True)
        ##############################################################################
        # TRAIN CURRENT STATUS DATA
        ##############################################################################
        lcap_df_train_curr_plan = train_current_status[train_current_status.rake_name.isin(list(final_unsch_trains.Trains_Not_Scheduled.unique()) + unscheduled_trains_lesscap)]
        # delete previous outputs
        del final_unsch_trains
        train_curr_plan_df = lcap_df_train_curr_plan.copy().reset_index(drop = True)
        ##############################################################################
        # OPTIMIZATION
        ##############################################################################
        # Scehdule Transhipment Hub pendency and rakes
        dist_time_df, pend_df, train_curr_plan_df, container_df, wagon_df = distance_data.copy().reset_index(drop = True), pend_df.copy().reset_index(drop = True), train_curr_plan_df.copy().reset_index(drop = True), container_df.copy(), wagon_df.copy()
        # If Trips = 2 and up_to_trips = True then up to 2 trips optimizer will schedule (if false then exactly 2 trips will be scheduled)
        TRIPS, UP_TO_TRIPS = 2, True
        obj_flag = 0
        IGNORE_CAPACITY_CONSTRAINT, IGNORE_STRONG_MAINTENANCE_CONSTRAINT, IGNORE_CLOSED_ROUTE, PAYLOAD_FLAG, FORECAST_PEND = False, False, True, False, False
        forecast_date_var = (datetime.today().strftime("%d/%m/%Y"))
        df_out, df_out_1, final_unsch_trains, pend_df_upd_unsch = optimizer(dist_time_df, pend_df, train_curr_plan_df, container_df, wagon_df,
                                                                          TRIPS, obj_flag, UP_TO_TRIPS, IGNORE_CAPACITY_CONSTRAINT,
                                                                          IGNORE_STRONG_MAINTENANCE_CONSTRAINT, IGNORE_CLOSED_ROUTE,
                                                                          PAYLOAD_FLAG, FORECAST_PEND, forecast_date_var)
        df_out = concat_outputs(df_out)
        schedule1 = pd.concat([schedule1_x,df_out]).reset_index(drop = True)
        final_unsch_trains = final_unsch_trains.copy().reset_index(drop = True)
        del df_out
      else:
        print("NO LOW CAPACITY RAKES FOUND - TRANSHIPMENT HUB SKIPPED")
        schedule1 = df_out.copy().reset_index(drop = True)
        final_unsch_trains = final_unsch_trains.copy().reset_index(drop = True)
      schedule1 = update_schedules(schedule1)  # schedule1 is df_out from first scheduler or after running trans-hub

      # SCHEDULE2 for train status - txr/park/txr-no-route-to-base
      train_status_dict1 = train_status_dict(final_unsch_trains,train_current_status,origin_base_km_min_dict)
      schedule2, final_unsch_trains =  scheduleX(train_status_dict1,final_unsch_trains, schedule1)
      schedule2 = schedule2.reset_index(drop = True)
      # (train_current_status.rake_name.nunique()), (schedule1.rake_name.nunique()) + (schedule2.rake_name.nunique())

      # (STATUS_FLAG = -1)
      # schedule2 is df_out_1 from the optimizer which are not scheduled as they should go for txr
      # all trains directly going to base location in schedule2 (STATUS_FLAG = -1) must carry TEUs if pendency exists
      if len(schedule2) > 0:
        # status_flag -1 refers to train going for txr
        if len(schedule2[schedule2.STATUS_FLAG == -1].reset_index(drop = True)) > 0:
          new_pend_df_upd_unsch = pd.DataFrame()
          for i in range(len(schedule2)):
            origin = schedule2.loc[i,"origin_code"]
            destination = schedule2.loc[i,"destination_code"]
            # if rake is already at base location then take no action
            if origin == destination:
              continue
            rake = schedule2.loc[i,"rake_name"]
            # rake capacity
            tcs = train_current_status[train_current_status.rake_name == rake].reset_index(drop = True)
            rake_cap = tcs.unts[0]
            # If not "txr" rake then skip the loop
            if schedule2.loc[i,"STATUS_FLAG"] != -1 :
              continue
            # if pendency exists for the route then only proceed with assigning TEUs to the TXR rake
            # only negative odr pendency is selected
            filt_pend_df_upd_unsch = pend_df_upd_unsch[ (pend_df_upd_unsch.Source == origin) &
                                                        (pend_df_upd_unsch.Destination == destination) &
                                                        (pend_df_upd_unsch.odr_days <= 0) &
                                                        ((pend_df_upd_unsch.Pendency > 0) | (pend_df_upd_unsch.empty_pendency > 0))
                                                      ].reset_index(drop = True)
            if len(filt_pend_df_upd_unsch) < 1:
              continue
            dist = distance_data[(distance_data.origin_code == origin) & (distance_data.destination_code == destination)].reset_index(drop = True)
            # if route exists in distance data then find out route capacity else assign it as a SS route.
            # as per business, ideally, if no route exists then no pendency created
            if len(dist) > 0:
              route_cap = dist.ss_ds[0]
              if route_cap == "DS":
                route_cap = 4
              else:
                route_cap = 2
            else:
              route_cap = 2
            # total capacity of rake
            tot_cap, full_cap, total_cap_rem = int(rake_cap) * int(route_cap), int(rake_cap) * int(route_cap), int(rake_cap) * int(route_cap)
            if len(filt_pend_df_upd_unsch) > 0:
              filt_pend_df_upd_unsch = filt_pend_df_upd_unsch.reset_index(drop = True)
              # more negative odr is given more priority always, 20-feeter is given more priority over 40-feeter as 20-feeter is restricted in upper deck of rake while 40-feeter can fit in in any deck
              filt_pend_df_upd_unsch = filt_pend_df_upd_unsch.sort_values(by = ["odr_days","cont_size"])
            # route capacity
            for p in range(len(filt_pend_df_upd_unsch)):
              pendency = 2*int(filt_pend_df_upd_unsch.loc[p,"Pendency"]/2)
              empty_pendency = 2*int(filt_pend_df_upd_unsch.loc[p,"empty_pendency"]/2)
              cont_size = filt_pend_df_upd_unsch.loc[p,"cont_size"]
              # 20_cont_size can occupy only 50% of rake in case of DS
              if cont_size == 20.0:
                if route_cap == 4:
                  total_cap = int(0.5*full_cap)
                else:
                  total_cap = full_cap
                schedule2.loc[i,'loaded_TEUs_evacuated_20'] += min(pendency,total_cap)
                loaded_teus_20 = min(pendency,total_cap)
                filt_pend_df_upd_unsch.loc[p,"Pendency"] = (-1)*loaded_teus_20
                total_cap_rem = total_cap - loaded_teus_20
                empty_teus_20 = 0
                if (total_cap_rem > 2) & (empty_pendency > 0):
                  schedule2.loc[i,'empty_TEUs_evacuated_20'] += min(empty_pendency,total_cap_rem)
                  empty_teus_20 = min(empty_pendency,total_cap_rem)
                  filt_pend_df_upd_unsch.loc[p,"empty_pendency"] = (-1)*empty_teus_20
                  tot_cap_rem = total_cap_rem - empty_teus_20
                total_cap_rem = tot_cap - loaded_teus_20 - empty_teus_20
              if total_cap_rem > 2:
                if cont_size == 40.0:
                  schedule2.loc[i,'loaded_TEUs_evacuated_40'] += min(pendency,total_cap_rem)
                  loaded_teus_40 = schedule2.loc[i,'loaded_TEUs_evacuated_40']
                  filt_pend_df_upd_unsch.loc[p,"Pendency"] = (-1)*loaded_teus_40
                  total_cap_rem -= loaded_teus_40
                  if (total_cap_rem > 2) & (empty_pendency > 0):
                    schedule2.loc[i,'empty_TEUs_evacuated_40'] += min(empty_pendency,total_cap_rem)
                    empty_teus_40 = schedule2.loc[i,'empty_TEUs_evacuated_40']
                    filt_pend_df_upd_unsch.loc[p,"empty_pendency"] = (-1)*empty_teus_40
                    total_cap_rem = total_cap_rem - empty_teus_40
            new_pend_df_upd_unsch = pd.concat([new_pend_df_upd_unsch,filt_pend_df_upd_unsch]).reset_index(drop = True)
            pend_df_upd_unsch = pd.concat([pend_df_upd_unsch,new_pend_df_upd_unsch]).reset_index(drop = True)
            pend_df_upd_unsch = pend_df_upd_unsch.groupby(["Source","Destination","odr_days","cont_size"]).agg({"Pendency":"sum","empty_pendency":"sum"}).reset_index()
            pend_df_upd_unsch.Pendency = pend_df_upd_unsch.Pendency.apply(lambda x: max(0,x))
            pend_df_upd_unsch.empty_pendency = pend_df_upd_unsch.empty_pendency.apply(lambda x: max(0,x))
            pend_df_upd_unsch = pend_df_upd_unsch[(pend_df_upd_unsch.Pendency > 0) | (pend_df_upd_unsch.empty_pendency > 0)]
        # if schedule2 exists then the following steps are taken
        schedule1_txr_rakes = list(schedule1[schedule1.STATUS_FLAG == -1].rake_name.unique())
        schedule2 = pd.concat([schedule2,schedule1[schedule1.rake_name.isin(schedule1_txr_rakes)]]).reset_index(drop = True)
        schedule1 = schedule1[~(schedule1.rake_name.isin(schedule1_txr_rakes))].reset_index(drop = True)
      else:
        # done to keep list of all txr rakes in schedule2
        schedule1_txr_rakes = list(schedule1[schedule1.STATUS_FLAG == -1].rake_name.unique())
        schedule2 = pd.DataFrame(columns = list(schedule1.columns))
        schedule2 = pd.concat([schedule2,schedule1[schedule1.rake_name.isin(schedule1_txr_rakes)]]).reset_index(drop = True)
        schedule1 = schedule1[~(schedule1.rake_name.isin(schedule1_txr_rakes))].reset_index(drop = True)

      # (STATUS_FLAG = -2)
      # Take all rakes which needs TXR but has no route to base (TXR-NO-ROUTE-TO-BASE, STATUS_FLAG = -2) and run with ignore cap constraint
      # Optimizer will try to schedule it with exactly 2 trips if possible, else it will be an unscheduled rake again
      # TXR-NO-ROUTE-TO-BASE schedule for all trains
      txr_no_route_tcs = train_current_status[train_current_status.rake_name.isin(list(schedule2[schedule2.STATUS_FLAG == -2].rake_name))]
      # train must go towards base as txr_remaining is -100 (no need to change due date)
      txr_no_route_tcs.TXR_Kms_Remaining = -100
      dist_time_df, pend_df, train_curr_plan_df, container_df, wagon_df = distance_data.copy().reset_index(drop = True), pend_df_upd_unsch.copy().reset_index(drop = True), txr_no_route_tcs.copy().reset_index(drop = True), container_df.copy(), wagon_df.copy() #update container_df and wagon_df as per remaining after implementation of payload
      # If Trips = 2 and up_to_trips = True then up to 2 trips optimizer will schedule (if false then exactly 2 trips will be scheduled)
      TRIPS, UP_TO_TRIPS = 2, False
      obj_flag = 0
      IGNORE_CAPACITY_CONSTRAINT, IGNORE_STRONG_MAINTENANCE_CONSTRAINT, IGNORE_CLOSED_ROUTE, PAYLOAD_FLAG, FORECAST_PEND = True, False, True, False, False
      forecast_date_var = (datetime.today().strftime("%d/%m/%Y"))
      df_out, df_out_1, final_unsch_trains, pend_df_upd_unsch = optimizer(dist_time_df, pend_df, train_curr_plan_df, container_df, wagon_df,
                                                                          TRIPS, obj_flag, UP_TO_TRIPS, IGNORE_CAPACITY_CONSTRAINT,
                                                                          IGNORE_STRONG_MAINTENANCE_CONSTRAINT, IGNORE_CLOSED_ROUTE,
                                                                          PAYLOAD_FLAG, FORECAST_PEND, forecast_date_var)
      df_out = concat_outputs(df_out)
      df_out = update_schedules(df_out)
      rakes_with_path = list(df_out[((df_out.loaded_TEUs_evacuated_20 > 0)|(df_out.loaded_TEUs_evacuated_40 > 0)|(df_out.empty_TEUs_evacuated_40 > 0)|(df_out.empty_TEUs_evacuated_20 > 0))].rake_name)
      df_out = df_out[df_out.rake_name.isin(rakes_with_path)]
      # Since now the rake has a route to move towards base (with pendency only) so the status is changed to -1 from -2
      df_out['STATUS_FLAG'] = -1
      # remove the scheduled rakes from schedule2
      schedule2 = schedule2[~schedule2.rake_name.isin(list(df_out.rake_name))]
      # concat the txr-no-route-to-base for which scheduling is done to schedule2
      schedule2 = pd.concat([schedule2,df_out]).reset_index(drop = True)

      # SCHEDULE FOR RAKES WITH AVAILABLE PENDENCY
      # concatenation of schedule1, schedule2 and schedule3 for the output
      SCHEDULE = pd.DataFrame()
      SCHEDULE = pd.concat([SCHEDULE,schedule1]).reset_index(drop = True)
      # del schedule1
      SCHEDULE = pd.concat([SCHEDULE,schedule2]).reset_index(drop = True)
      # del schedule2
      schedule_mail_analysis = SCHEDULE.copy().reset_index(drop = True)
      schedule_mail_analysis["next_trip"] = schedule_mail_analysis.origin_code + "-" + schedule_mail_analysis.destination_code
      schedule_mail_analysis[['loaded_TEUs_evacuated_20','loaded_TEUs_evacuated_40','empty_TEUs_evacuated_20','empty_TEUs_evacuated_40']] = schedule_mail_analysis[['loaded_TEUs_evacuated_20','loaded_TEUs_evacuated_40','empty_TEUs_evacuated_20','empty_TEUs_evacuated_40']].astype(int)
      train_current_status_copy1["current_trip"] = train_current_status_copy1["origin_code"] + "-" + train_current_status_copy1["destination_code"]
      schedule_mail_analysis = schedule_mail_analysis.merge(train_current_status_copy1[["rake_name","current_trip","FOIS_ETA","rake_status","base_depot_code","unts"]], on = "rake_name", how = "left")
      schedule_mail_analysis.rename(columns = {"FOIS_ETA":"currtrp_ETA"}, inplace = True)
      schedule_mail_analysis = schedule_mail_analysis.sort_values(by = ["next_trip","currtrp_ETA"]).reset_index(drop = True)
      for i in range(train_current_status_copy1.shape[0]):
        if train_current_status_copy1.loc[i,"origin_code"] == train_current_status_copy1.loc[i,"destination_code"]:
          train_current_status_copy1.loc[i,"TXR_KmsRem_CurrDest"] = train_current_status_copy1.loc[i,"TXR_Kms_Remaining"]
      schedule_mail_analysis = schedule_mail_analysis.merge(train_current_status_copy1[["rake_name","TXR_Due_Date","TXR_KmsRem_CurrDest"]], left_on = ["rake_name"], right_on = ["rake_name"], how = 'left').reset_index(drop = True)
      schedule_mail_analysis["loaded_TEUs_evacuated"], schedule_mail_analysis["empty_TEUs_evacuated"] = schedule_mail_analysis["loaded_TEUs_evacuated_20"] + schedule_mail_analysis["loaded_TEUs_evacuated_40"], schedule_mail_analysis["empty_TEUs_evacuated_20"] + schedule_mail_analysis["empty_TEUs_evacuated_40"]
      schedule_mail_analysis.currtrp_ETA = pd.to_datetime(schedule_mail_analysis["currtrp_ETA"]).apply(lambda x: x.strftime('%Y-%m-%d %H:%M'))
      schedule_mail_analysis.TXR_Due_Date = pd.to_datetime(schedule_mail_analysis["TXR_Due_Date"]).apply(lambda x: x.strftime('%Y-%m-%d'))
      schedule_mail_analysis.loc[schedule_mail_analysis["Trip_Num"] == 2, ["current_trip","currtrp_ETA","rake_status","TXR_KmsRem_CurrDest"]] = ''

      # Pendency Data to be merged with output
      final_pend = pendency_data[(pendency_data.odr_days < 0) & (pendency_data.flag == 1)].copy()
      final_pend["pendency"] = final_pend["pendency"] + final_pend["empty_pendency"]
      final_pend = final_pend.groupby(["booking_location_code","to_terminal_code"]).agg({"pendency":"sum"}).reset_index()
      final_pend['next_trip_trip1'] = final_pend['booking_location_code'] + "-" + final_pend["to_terminal_code"]

      # Final Output Prep
      try:
        final_df = schedule_mail_analysis.copy().reset_index(drop = True)
        final_df["TEUs_evacuated"] = final_df["loaded_TEUs_evacuated"] + final_df["empty_TEUs_evacuated"]
        cols = ["rake_name","current_trip","currtrp_ETA","rake_status","unts","base_depot_code","TXR_Due_Date","TXR_KmsRem_CurrDest"]
        cols1= ['rake_name', 'next_trip', 'loaded_TEUs_evacuated_20','loaded_TEUs_evacuated_40','empty_TEUs_evacuated_20','empty_TEUs_evacuated_40','loaded_TEUs_evacuated', 'empty_TEUs_evacuated',"STATUS_FLAG","AWAITING_FORECAST"]
        final_df1 = pd.merge(final_df[final_df.Trip_Num == 1][cols], final_df[final_df.Trip_Num == 1][cols1], on = "rake_name", how = 'outer') #pd.concat([schedule_mail1, schedule_mail2], axis = 1)
        final_df = pd.merge(final_df1, final_df[final_df.Trip_Num == 2][cols1], on = "rake_name", how = "outer")
        final_df.rename(columns = lambda x: x[:-2]+"_trip1" if x.endswith('_x') else x, inplace = True)
        final_df.rename(columns = lambda x: x[:-2]+"_trip2" if x.endswith('_y') else x, inplace = True)
        final_df['TEUs_trip1'], final_df['TEUs_trip2'] = final_df['loaded_TEUs_evacuated_trip1'] + final_df['empty_TEUs_evacuated_trip1'], final_df['loaded_TEUs_evacuated_trip2'] + final_df['empty_TEUs_evacuated_trip2']
        final_df['destination0'] = [l[0] if len(l) > 0 else np.nan for l in final_df['next_trip_trip1'].str.split("-")]
        final_df.next_trip_trip2 = final_df.next_trip_trip2.fillna("Not Suggested")
        final_df.TEUs_trip2 = final_df.TEUs_trip2.fillna(0)
        final_df = final_df.sort_values(by = ["destination0","currtrp_ETA"]).reset_index(drop = True)
        final_df = final_df.merge(final_pend[["next_trip_trip1","pendency"]], on = ["next_trip_trip1"], how = "left")
        final_df = update_pendency_in_ouput(final_df, 'pendency','TEUs_trip1') # defined in the function to consider next_trip1 only
        # final_df = final_df.sort_values(by = ["destination0","currtrp_ETA"]).reset_index(drop = True)
        final_df = final_df[['rake_name', 'current_trip', 'currtrp_ETA', 'rake_status', 'pendency','next_trip_trip1', 'TEUs_trip1', 'AWAITING_FORECAST_trip1','STATUS_FLAG_trip1',
                            'next_trip_trip2', 'TEUs_trip2', 'AWAITING_FORECAST_trip2', 'STATUS_FLAG_trip2',
                            'loaded_TEUs_evacuated_20_trip1', 'loaded_TEUs_evacuated_40_trip1', 'empty_TEUs_evacuated_20_trip1', 'empty_TEUs_evacuated_40_trip1',
                            # 'loaded_TEUs_evacuated_20_trip2', 'loaded_TEUs_evacuated_40_trip2', 'empty_TEUs_evacuated_20_trip2', 'empty_TEUs_evacuated_40_trip2',
                            'unts', 'base_depot_code', 'TXR_Due_Date', 'TXR_KmsRem_CurrDest']]

        final_df = final_df[['rake_name', 'current_trip', 'currtrp_ETA', 'rake_status', 'next_trip_trip1', 'AWAITING_FORECAST_trip1', 'STATUS_FLAG_trip1', 'AWAITING_FORECAST_trip2', 'STATUS_FLAG_trip2',#'pendency', 'TEUs_trip1',
                            'next_trip_trip2', #'TEUs_trip2',
                            # 'loaded_TEUs_evacuated_20_trip1', 'loaded_TEUs_evacuated_40_trip1', 'empty_TEUs_evacuated_20_trip1', 'empty_TEUs_evacuated_40_trip1',
                            # 'loaded_TEUs_evacuated_20_trip2', 'loaded_TEUs_evacuated_40_trip2', 'empty_TEUs_evacuated_20_trip2', 'empty_TEUs_evacuated_40_trip2',
                            'unts', 'base_depot_code', 'TXR_Due_Date', 'TXR_KmsRem_CurrDest']]
        final_df = final_df.fillna(0)

      except:
        final_df = pd.DataFrame(columns = ['rake_name', 'current_trip', 'currtrp_ETA', 'rake_status', 'next_trip_trip1', 'AWAITING_FORECAST_trip1', 'STATUS_FLAG_trip1', 'AWAITING_FORECAST_trip2', 'STATUS_FLAG_trip2', #'pendency', #'TEUs_trip1',
                            'next_trip_trip2', #'TEUs_trip2',
                            # 'loaded_TEUs_evacuated_20_trip1', 'loaded_TEUs_evacuated_40_trip1', 'empty_TEUs_evacuated_20_trip1', 'empty_TEUs_evacuated_40_trip1',
                            # 'loaded_TEUs_evacuated_20_trip2', 'loaded_TEUs_evacuated_40_trip2', 'empty_TEUs_evacuated_20_trip2', 'empty_TEUs_evacuated_40_trip2',
                            'unts', 'base_depot_code', 'TXR_Due_Date', 'TXR_KmsRem_CurrDest'])

      distance_data['router'] = distance_data.origin_code + "-" + distance_data.destination_code
      distance_data_1, distance_data_2 = distance_data.copy(), distance_data.copy()
      distance_data_1.rename(columns = lambda x: x+"_trip1", inplace = True)
      distance_data_2.rename(columns = lambda x: x+"_trip2", inplace = True)

      final_df = final_df.merge(distance_data_1[["router_trip1","rational_distance_trip1","r_tat_sla_trip1"]], left_on = ["next_trip_trip1"], right_on = ["router_trip1"], how = "left")
      final_df = final_df.merge(distance_data_2[["router_trip2","rational_distance_trip2","r_tat_sla_trip2"]], left_on = ["next_trip_trip2"], right_on = ["router_trip2"], how = "left")
      final_df[["rational_distance_trip1","rational_distance_trip2"]] = final_df[["rational_distance_trip1","rational_distance_trip2"]].astype('float')
      final_df = final_df.fillna(0)
      final_df_sched = final_df.copy()

      # PREPARE FORECAST TRAIN CURRENT STATUS DATASET

      # Original tcs remainingkms
      final_df = final_df.merge(train_current_status[["rake_name","TXR_Kms_Remaining"]], on = ["rake_name"], how = "left")

      # ETA at final destination
      final_df['last_ETA'] = None
      final_df.r_tat_sla_trip1 = pd.to_timedelta(final_df.r_tat_sla_trip1, unit = 'h')
      final_df.r_tat_sla_trip2 = pd.to_timedelta(final_df.r_tat_sla_trip2, unit = 'h')
      final_df.currtrp_ETA = pd.to_datetime(final_df.currtrp_ETA)
      final_df.last_ETA = final_df.currtrp_ETA + final_df.r_tat_sla_trip1 + final_df.r_tat_sla_trip2

      # find out the last route and last origin and destination as per last ETA
      final_df.last_route = ''
      for i in range(len(final_df)):
        if final_df.loc[i,'router_trip2'] != 0:
          final_df.loc[i,'last_route'] = final_df.loc[i,'router_trip2']
          continue
        if final_df.loc[i,'router_trip1'] != 0:
          final_df.loc[i,'last_route'] = final_df.loc[i,'router_trip1']
          continue
        final_df.loc[i,'last_route'] = final_df.loc[i,'current_trip']

      final_df[['last_origin_code','last_destination_code']] = final_df["last_route"].str.split("-", expand = True)

      # txr_kms_rem = kms remaining at last origin
      # txr_kms_currdest = kms remaining at beginning of first origin before planninig trip 1
      # new_txr_kms_rem = txr_kms_currdest
      # if kms_remaining_2 > 0, new_txr_kms_rem = txr_kms_currdest - kms_remaining_1, continue
      # if kms_remaining_1 > 0, new_txr_kms_rem = txr_kms_currdest, continue
      # if none of above, new_txr_kms_rem = txr_kms_currdest - txr_kms_rem (from tcs df)
      # calculate kms remaining after every trip is planned : kms_remaining_1, kms_remaining_2
      # reduce the last kms_remaining added : if kms_remaining_2 > 0 then

      final_df['last_TXR_Kms_Remaining'] = 0
      for i in range(len(final_df)):
        if final_df.loc[i, 'rational_distance_trip2'] > 0:
          final_df.loc[i, 'last_TXR_Kms_Remaining'] = final_df.loc[i, 'TXR_KmsRem_CurrDest']  - final_df.loc[i, "rational_distance_trip1"] - final_df.loc[i, "rational_distance_trip2"]
          continue
        if final_df.loc[i,'rational_distance_trip1'] > 0:
          final_df.loc[i, 'last_TXR_Kms_Remaining'] = final_df.loc[i, 'TXR_KmsRem_CurrDest'] - final_df.loc[i, "rational_distance_trip1"]
          continue
        final_df.loc[i,'last_TXR_Kms_Remaining'] = final_df.loc[i, 'TXR_KmsRem_CurrDest']

      # If a rake undergoes maintenance then re-calculation of ETA and kms remaining
      # number of kms added will change as per the kind of maintenance train is going through - can be 6500, 7500, 9000 etc.

      for i in range(len(final_df)):
        if ((final_df.loc[i,"STATUS_FLAG_trip1"] == -1) & (final_df.loc[i,"last_destination_code"] == final_df.loc[i,"base_depot_code"])):
          # 12 hours added to final ETA of rake as it goes for maintenance
          final_df.loc[i,"last_ETA"] = final_df.loc[i,"last_ETA"] + pd.Timedelta(hours = 12)
          final_df.loc[i,"TXR_Due_Date"] = pd.to_datetime(final_df.loc[i,"last_ETA"]) + pd.Timedelta(hours = 30*24) # 30 days added after TXR ETA
          final_df.loc[i,"last_TXR_Kms_Remaining"] = 9000
          final_df.loc[i,"TXR_KmsRem_CurrDest"] = 9000

      final_df["TXR_Due_Date"] = pd.to_datetime(final_df["TXR_Due_Date"])
      final_df["TXR_Due_Date"] = final_df["TXR_Due_Date"].dt.date
      forecast_train_current_status = final_df.copy()
      forecast_train_current_status.drop(columns = ["current_trip","currtrp_ETA","next_trip_trip1","STATUS_FLAG_trip1","STATUS_FLAG_trip2",
                                                    'AWAITING_FORECAST_trip1','AWAITING_FORECAST_trip2',
                                                    "next_trip_trip2","TXR_KmsRem_CurrDest","router_trip1","rational_distance_trip1",
                                                    "r_tat_sla_trip1","router_trip2","rational_distance_trip2","r_tat_sla_trip2","TXR_Kms_Remaining",
                                                    "last_route"], inplace = True)
      forecast_train_current_status.rename(columns = {"last_ETA":"FOIS_ETA","last_origin_code":"origin_code","last_destination_code":"destination_code",
                                                      "last_TXR_Kms_Remaining":"TXR_Kms_Remaining"}, inplace = True)

      forecast_train_current_status = forecast_train_current_status.merge(distance_data[["origin_code","destination_code","rational_distance"]], on = ["origin_code","destination_code"], how = "left")
      forecast_train_current_status.rational_distance = forecast_train_current_status.rational_distance.fillna(0)
      forecast_train_current_status["ETA_date"] = forecast_train_current_status["FOIS_ETA"].dt.date.apply(lambda x: x.strftime("%d/%m/%Y"))
      forecast_train_current_status_copy = forecast_train_current_status.copy()
      forecast_train_current_status

      # Add today's remaining pendency to each line of pendency for the same source and destination as per cont_size (let ODR remain same)
      forecast_pend = forecast_pend.reset_index(drop = True)
      new_new_pend_data = pend_df_upd_unsch.merge(forecast_pend,
                              left_on = ["Source","Destination","cont_size"],
                              right_on = ["booking_location_code","to_terminal_code","cont_size"], how = "outer")
      new_new_pend_data.Pendency = new_new_pend_data.Pendency.fillna(0)
      new_new_pend_data.pendency = new_new_pend_data.pendency.fillna(0)
      new_new_pend_data.empty_pendency_x = new_new_pend_data.empty_pendency_x.fillna(0)
      new_new_pend_data.empty_pendency_y = new_new_pend_data.empty_pendency_y.fillna(0)
      new_new_pend_data['odr_days'] = new_new_pend_data['odr_days_y']
      new_new_pend_data['odr_days'] = new_new_pend_data['odr_days'].fillna(new_new_pend_data['odr_days_x'])
      new_new_pend_data['Pendency'] = new_new_pend_data['Pendency'] + new_new_pend_data['pendency']
      new_new_pend_data['empty_pendency'] = new_new_pend_data['empty_pendency_x'] + new_new_pend_data['empty_pendency_y']
      new_new_pend_data['odr_days'] = new_new_pend_data['odr_days'].fillna(new_new_pend_data['odr_days_x'])
      new_new_pend_data['Source'] = new_new_pend_data['Source'].fillna(new_new_pend_data['booking_location_code'])
      new_new_pend_data['Destination'] = new_new_pend_data['Destination'].fillna(new_new_pend_data['to_terminal_code'])
      new_new_pend_data.drop(columns = ["odr_days_x","odr_days_y","empty_pendency_x","empty_pendency_y","booking_location_code","to_terminal_code","pendency"], inplace = True)
      # new_new_pend_data


      pend_exp=new_new_pend_data[['Source','Destination','Pendency','empty_pendency']]
      pend_exp=pend_exp.groupby(['Source','Destination']).agg({"Pendency":"sum", "empty_pendency":"sum" })
      pend_exp['tot_pend']=pend_exp['Pendency']+pend_exp['empty_pendency']
      forecast_train_current_status.unts=forecast_train_current_status.unts.astype(int)
      p=pend_exp[pend_exp["tot_pend"]>=(2*forecast_train_current_status.unts.min())]

      pendy=new_new_pend_data.merge(p, left_on=['Source','Destination'], right_on=['Source','Destination'], how= "outer")
      pendy = pendy.drop(columns=['empty_pendency_y', 'Pendency_y'])
      pendy=pendy.dropna(subset=['tot_pend'])
      pendy=pendy.drop(columns=['tot_pend'])
      pendy.reset_index(drop=True)
      pendy.rename(columns={'Pendency_x': 'Pendency', 'empty_pendency_x': 'empty_pendency'}, inplace=True)
      pendy.reset_index(drop=True, inplace=True)
      new_new_pend_data=pendy
      new_new_pend_data

      forecast_pend_data_final = new_new_pend_data.copy()
      forecast_pend_data_final = forecast_pend_data_final[forecast_pend_data_final.odr_days <= 7.0]
      forecast_pend_data_final['ETA'] = forecast_pend_data_final.ETA.fillna(forecast_pend_data_final[~forecast_pend_data_final.ETA.isna()].ETA.min()) #forecast_pend_data_final.ETA.fillna((datetime.today().strftime("%d/%m/%Y")))
      forecast_pend_data_final = forecast_pend_data_final.groupby(["Source","Destination","cont_size","ETA"]).agg({"Pendency":"sum","empty_pendency":"sum","odr_days":"min"}).reset_index()
      # forecast_pend_data_final['ETA'] = pd.to_datetime(forecast_pend_data_final['ETA'])
      forecast_pend_data_final.sort_values(by = ["ETA"], inplace = True)
      forecast_pend_data_final = forecast_pend_data_final.reset_index(drop = True)
      all_eta = (list(forecast_pend_data_final.ETA.unique()))
      forecast_pend_data_final["rank_eta"] = ''
      for idx in range(len(forecast_pend_data_final)):
        forecast_pend_data_final.loc[idx,"rank_eta"] = all_eta.index(forecast_pend_data_final.loc[idx,"ETA"])+1
      # forecast_pend_data_final['ETA'] = pd.to_datetime(forecast_pend_data_final["ETA"], format='%d/%m/%y %H:%M:%S') #.apply(lambda x: x.strftime("%d/%m/%Y"))

      dist_locs = set(list(distance_data.origin_code) + list(distance_data.destination_code))
      forecast_pend_data_final = forecast_pend_data_final[forecast_pend_data_final.Source.isin(dist_locs)&forecast_pend_data_final.Destination.isin(dist_locs)].reset_index(drop = True)



      forecast_pend_data_final=forecast_pend_data_final[forecast_pend_data_final.rank_eta<=4]
      forecast_pend_data_final_copy = forecast_pend_data_final.copy()
      forecast_pend_data_final



      # forecast_train_current_status = forecast_train_current_status_copy.copy()
      # forecast_pend_data_final = forecast_pend_data_final_copy.copy()

      ####################################################################################################################################
      ################################################## SCHEDULE FOR FORECAST PENDENCY ##################################################
      ####################################################################################################################################
      SCHEDULE_forecast = pd.DataFrame()
      remaining_forecast = pd.DataFrame()
      ranks_forecast_pend = list(set(forecast_pend_data_final.rank_eta))

      train_list = []
      # ranks_forecast_pend = [1] # TEST
      # pendency_data_daywise = pd.DataFrame()
      # rank wise scan the forecast pendency data and schedule


      for forecast_rank in ranks_forecast_pend:

        # Set Input Variables
        pend_df = forecast_pend_data_final.copy()
        pend_df = pend_df[pend_df.rank_eta == forecast_rank].reset_index(drop = True)
        forecast_date_var = pend_df.ETA[0] #.dt.date.apply(lambda x: x.strftime("%d/%m/%Y")) #(datetime.today().strftime("%d/%m/%Y"))
        print("Forecast Date: ", forecast_date_var)
        # pendency_data_daywise = pd.concat([pendency_data_daywise, pend_df])
        train_curr_plan_df = forecast_train_current_status[forecast_train_current_status.ETA_date <= forecast_date_var] # take only rakes whose ETA is <= forecast ETA to reduce the number of rakes

        # Set optimizer variables
        dist_time_df, pend_df, train_curr_plan_df, container_df, wagon_df = distance_data.copy().reset_index(drop = True), pend_df.copy().reset_index(drop = True), train_curr_plan_df.copy().reset_index(drop = True), container_df.copy(), wagon_df.copy()
        TRIPS, UP_TO_TRIPS, obj_flag = 2, True, 0 # If Trips = 2 and up_to_trips = True then up to 2 trips optimizer will schedule (if false then exactly 2 trips will be scheduled)
        IGNORE_CAPACITY_CONSTRAINT, IGNORE_STRONG_MAINTENANCE_CONSTRAINT, IGNORE_CLOSED_ROUTE, PAYLOAD_FLAG, FORECAST_PEND = False, False, True, False, True

        # # TEMPORARY CHECK UNTIL TXR FILTER ADDED- Check if the forecast pendency day should be considered (if enough number of containers are there to be moved), if not then only consider the trains with less TXR
        # min_wagons = train_curr_plan_df.unts.astype('int64').min()
        # pend_df_CHECK =  pend_df[((pend_df["Pendency"] + pend_df["empty_pendency"]) >= 2*min_wagons)]
        # if len(pend_df_CHECK) < 1:
        #   # take trains whose txr due date is within 1 days or rem kms is within 500 kms
        #   train_curr_plan_df = train_curr_plan_df[(train_curr_plan_df.TXR_Due_Date <= ((datetime.today() + timedelta(days = 1)).strftime("%d/%m/%Y")))|(train_curr_plan_df.TXR_Kms_Remaining <= 1000 )].reset_index(drop = True)
        #   IGNORE_CAPACITY_CONSTRAINT = True


        # Optimize
        df_out, df_out_1, final_unsch_trains, pend_df_upd_unsch = optimizer(dist_time_df, pend_df, train_curr_plan_df, container_df, wagon_df,
                                                                            TRIPS, obj_flag, UP_TO_TRIPS, IGNORE_CAPACITY_CONSTRAINT,
                                                                            IGNORE_STRONG_MAINTENANCE_CONSTRAINT, IGNORE_CLOSED_ROUTE,
                                                                            PAYLOAD_FLAG, FORECAST_PEND, forecast_date_var)

        # Interprete Output
        df_out = concat_outputs(df_out)
        df_out = update_schedules(df_out)
        df_out_copy = df_out.copy()

        # display(df_out)

        # Handle Forecast Pendency
        # adjust pendency data once the optimizer is run rank wise
        # remaining_forecast = pd.concat([remaining_forecast,pend_df_upd_unsch])
        pend_df_upd_unsch["forecast_date"] = forecast_date_var
        remaining_forecast = pd.concat([remaining_forecast,pend_df_upd_unsch])
        forecast_pend_data_final = forecast_pend_data_final[forecast_pend_data_final.rank_eta != forecast_rank].reset_index(drop = True) # remove forecast data for which schedule of pendency is done

        if len(forecast_pend_data_final) != 0:
          min_eta_forecast = forecast_pend_data_final.ETA.min()                 # take min eta forecast
          min_rank_forecast = forecast_pend_data_final.rank_eta.min()           # take min rank forecast
          pend_df_upd_unsch["ETA"] = min_eta_forecast                           # add eta to remaining pendency data which would be min eta in forecast_pend_data_final
          pend_df_upd_unsch["rank_eta"] = min_rank_forecast                     # add rank to remaining pendency data which would be min rank in forecast_pend_data_final
          pend_df_upd_unsch = pend_df_upd_unsch[pend_df.columns]                # set the column same as forecast_pend_data_final
        else:
          pend_df_upd_unsch["ETA"] = min_eta_forecast                           # add eta to remaining pendency data which would be min eta in forecast_pend_data_final
          pend_df_upd_unsch["rank_eta"] = min_rank_forecast
        forecast_pend_data_final = pd.concat([forecast_pend_data_final,pend_df_upd_unsch])
        # groupby to adjust the pendency for next date - the remaining pendency should be added to next date's pendency
        forecast_pend_data_final = forecast_pend_data_final.groupby(["Source","Destination","cont_size","ETA","rank_eta"]).agg({"Pendency":"sum","empty_pendency":"sum","odr_days":"min"}).reset_index()
        # forecast_pend_data_final["odr_days"] = 0 # create odr column to not have difference in data

        df_out['f_schedule_no'] = forecast_rank

        # Store the Forecast Result in a variable
        SCHEDULE_forecast = pd.concat([SCHEDULE_forecast,df_out]).reset_index(drop = True)
        #Update forecast_train_current_status_copy data
        # merge to get total distance travelled due to scheduling for forecast
        rake_travel_details = df_out.merge(distance_data[["origin_code","destination_code","rational_distance","r_tat_sla"]], on = ["origin_code","destination_code"], how = 'left')
        # groupby to calculate txr_kms_remaining as it doesn't include the last trip's kms
        rake_travel_details1 = rake_travel_details.groupby(["rake_name"]).agg({"rational_distance":"sum","r_tat_sla":"sum","Trip_Num":"max"}).reset_index()
        # merge based on last trip num and subtract the last trip's rational distance
        df_out_modified = rake_travel_details[["rake_name","Trip_Num","origin_code","destination_code"]].merge(rake_travel_details1, on = ["rake_name","Trip_Num"], how = 'inner')
        df_out_modified = df_out_modified.merge(distance_data[["origin_code","destination_code","rational_distance"]], on = ["origin_code","destination_code"], how = 'left')
        df_out_modified["subtract_TXR"] = df_out_modified["rational_distance_x"] - df_out_modified["rational_distance_y"]
        df_out_modified.drop(columns = ["rational_distance_x","Trip_Num"], inplace = True)
        # use r_tat_sla to add to ETA in forecast_train_current_status dataframe
        df_out_modified.rename(columns = {"r_tat_sla":"add_ETA","rational_distance_y":"rational_distance"}, inplace = True)
        df_out_modified = forecast_train_current_status_copy[["rake_name","FOIS_ETA","TXR_Kms_Remaining"]].merge(df_out_modified, on = "rake_name", how = "inner")
        df_out_modified['TXR_Kms_Remaining'] = df_out_modified['TXR_Kms_Remaining'] - df_out_modified['subtract_TXR']
        df_out_modified.add_ETA = pd.to_timedelta(df_out_modified.add_ETA, unit = 'h')
        # df_out_modified.FOIS_ETA = pd.to_datetime(final_df.FOIS_ETA)
        df_out_modified['FOIS_ETA'] = pd.to_datetime(df_out_modified.FOIS_ETA) + df_out_modified.add_ETA
        df_out_modified.drop(columns = ["add_ETA","subtract_TXR"], inplace = True)
        forecast_train_current_status = forecast_train_current_status.merge(df_out_modified, on = 'rake_name', how = 'left')
        forecast_train_current_status.rename(columns = {"TXR_Kms_Remaining_y":"TXR_Kms_Remaining", "origin_code_y":"origin_code", "destination_code_y":"destination_code", "rational_distance_y":"rational_distance","FOIS_ETA_y":"FOIS_ETA"}, inplace = True)
        # new_new_pend_data['odr_days'] = new_new_pend_data['odr_days'].fillna(new_new_pend_data['odr_days_x'])
        forecast_train_current_status["TXR_Kms_Remaining"] = forecast_train_current_status["TXR_Kms_Remaining"].fillna(forecast_train_current_status["TXR_Kms_Remaining_x"])
        forecast_train_current_status["origin_code"] = forecast_train_current_status["origin_code"].fillna(forecast_train_current_status["origin_code_x"])
        forecast_train_current_status["destination_code"] = forecast_train_current_status["destination_code"].fillna(forecast_train_current_status["destination_code_x"])
        forecast_train_current_status["rational_distance"] = forecast_train_current_status["rational_distance"].fillna(forecast_train_current_status["rational_distance_x"])
        forecast_train_current_status["TXR_KmsRem_CurrDest"] = forecast_train_current_status["TXR_Kms_Remaining"] # - forecast_train_current_status["rational_distance"]
        forecast_train_current_status["TXR_DueRem_CurrDest"] = pd.to_datetime(forecast_train_current_status["TXR_Due_Date"]) - pd.to_datetime(dt.datetime.strptime(min_eta_forecast, "%d/%m/%Y").strftime("%Y-%m-%d"))
        forecast_train_current_status["TXR_DueRem_CurrDest"] = forecast_train_current_status["TXR_DueRem_CurrDest"].apply(day_time_to_min)
        forecast_train_current_status["FOIS_ETA"] = forecast_train_current_status["FOIS_ETA"].fillna(forecast_train_current_status["FOIS_ETA_x"])
        forecast_train_current_status.drop(columns = ["FOIS_ETA_x","origin_code_x","destination_code_x","TXR_Kms_Remaining_x","rational_distance_x"], inplace = True)
        forecast_train_current_status["ETA_date"] = pd.to_datetime(forecast_train_current_status["FOIS_ETA"]).apply(lambda x: x.strftime("%d/%m/%Y"))

        train_status_dict2 = train_status_dict(final_unsch_trains,forecast_train_current_status[forecast_train_current_status.ETA_date <= forecast_date_var].reset_index(drop = True),origin_base_km_min_dict)
        for key,value in train_status_dict1.items():
          if value != "(PARK)":
            train_list.append(key)
        forecast_train_current_status = forecast_train_current_status[~forecast_train_current_status.rake_name.isin(train_list)].reset_index(drop = True)


        # if a rake is scheduled then it should get added to SCHEDULE
        # the rakes final ETA and source-destination everything should get updated in final_df
        # should happen in a loop

        # final forecast data is stored in SCHEDULE_forecast

      SCHEDULE_forecast

      #####################################################################################################################################
      ############ ADD FORECAST SCHEDULE OF RAKES TO THE NORMAL SCHEDULE WITH ADJUSTED TRIP NUMBER ########################################
      #####################################################################################################################################

      # Update trip numbers for rake's forecasted schedule
      final_forecast_df = pd.DataFrame(columns = SCHEDULE_forecast.columns)
      for rakes_no in list(SCHEDULE_forecast.rake_name.unique()):
        filtered_forecast_df = SCHEDULE_forecast[SCHEDULE_forecast.rake_name == rakes_no]
        filtered_forecast_df = filtered_forecast_df.reset_index(drop = True)
        filtered_forecast_df['Trip_Num'] = filtered_forecast_df.index + 1
        final_forecast_df = pd.concat([final_forecast_df, filtered_forecast_df])

      #####################################################################################################################################

      # If a rake is already scheduled before being scheduled again in final_forecast_df (forecast pendency) then update trip numbers accordingly in final_forecast_df
      all_forecast_scheduled_rakes = list(final_forecast_df.rake_name.unique())

      # if rake is parked (status_flag = 1) in SCHEDULE and scheduled in final_forecast_df then remove the rake from SCHEDULE
      # Remove the rakes which are parked and then scheduled for forecast - keep only the scheduled rake and remove the parking schedule line
      # SCHEDULE = SCHEDULE[~((SCHEDULE.rake_name.isin(all_forecast_scheduled_rakes))&(SCHEDULE.STATUS_FLAG == 1))].reset_index(drop = True)

      # Adjust trip number count for remaining rakes in SCHEDULE which are there in final_forecast_df as well
      for rakes in all_forecast_scheduled_rakes:
        count = SCHEDULE[(SCHEDULE.rake_name == rakes)].Trip_Num.max()
        if count > 0:
          final_forecast_df.loc[final_forecast_df.rake_name == rakes,"Trip_Num"] += count

      # if a rake is waiting at it's own terminal for forecast pendency then awaiting_forecast = yes
      final_forecast_df.loc[((final_forecast_df.loaded_TEUs_evacuated_20>0)|(final_forecast_df.loaded_TEUs_evacuated_20>0)|(final_forecast_df.loaded_TEUs_evacuated_20>0)|(final_forecast_df.loaded_TEUs_evacuated_20>0)),'AWAITING_FORECAST'] = "Yes"
      # if a rake is scheduled for forecast pendency then status flag = 5
      final_forecast_df.STATUS_FLAG = 5

      SCHEDULE2 = pd.concat([SCHEDULE,final_forecast_df])
      SCHEDULE2.sort_values(by = ["rake_name","Trip_Num"], inplace = True)
      SCHEDULE2 = SCHEDULE2.reset_index(drop = True)

      #####################################################################################################################################

      # If TXR-NO-ROUTE-TO-BASE case exists and that rake gets scheduled during forecast scheduling
      # then remove the trip where rake is parked at origin with -2 status.
      # The next trip onwards the trip should be considered
      txr_no_route_to_base_rakes = list(SCHEDULE2[SCHEDULE2.STATUS_FLAG == -2].rake_name.unique())

      for rakes in txr_no_route_to_base_rakes:
        # print(rakes)
        filtered_df = SCHEDULE2[SCHEDULE2.rake_name == rakes].reset_index(drop = True)
        if ((len(filtered_df) > 1) & (filtered_df.Trip_Num.max() > filtered_df[filtered_df.STATUS_FLAG == -2].Trip_Num[0])):
          SCHEDULE2 = SCHEDULE2[~((SCHEDULE2.rake_name == rakes) & (SCHEDULE2.STATUS_FLAG == -2))].reset_index(drop = True)
          SCHEDULE2.loc[SCHEDULE2.rake_name == rakes, "Trip_Num"] = SCHEDULE2.loc[SCHEDULE2.rake_name == rakes, "Trip_Num"] - 1
          ## status still shows that rake is txr-no-route-to-base
          # SCHEDULE2.loc[SCHEDULE2.rake_name == rakes, "STATUS_FLAG"] = -2

      SCHEDULE2

      # modify the final output in final display format
      # SCHEDULE2
      schedule_mail_analysis = SCHEDULE2.copy().reset_index(drop = True)
      schedule_mail_analysis["next_trip"] = schedule_mail_analysis.origin_code + "-" + schedule_mail_analysis.destination_code
      schedule_mail_analysis[['loaded_TEUs_evacuated_20','loaded_TEUs_evacuated_40','empty_TEUs_evacuated_20','empty_TEUs_evacuated_40']] = schedule_mail_analysis[['loaded_TEUs_evacuated_20','loaded_TEUs_evacuated_40','empty_TEUs_evacuated_20','empty_TEUs_evacuated_40']].astype(int)
      train_current_status_copy1["current_trip"] = train_current_status_copy1["origin_code"] + "-" + train_current_status_copy1["destination_code"]
      schedule_mail_analysis = schedule_mail_analysis.merge(train_current_status_copy1[["rake_name","current_trip","FOIS_ETA","rake_status","base_depot_code","unts"]], on = "rake_name", how = "left")
      schedule_mail_analysis.rename(columns = {"FOIS_ETA":"currtrp_ETA"}, inplace = True)
      schedule_mail_analysis = schedule_mail_analysis.sort_values(by = ["next_trip","currtrp_ETA"]).reset_index(drop = True)
      # for i in range(train_current_status_copy1.shape[0]):
      #   if train_current_status_copy1.loc[i,"origin_code"] == train_current_status_copy1.loc[i,"destination_code"]:
      #     train_current_status_copy1.loc[i,"TXR_KmsRem_CurrDest"] = train_current_status_copy1.loc[i,"TXR_Kms_Remaining"]
      schedule_mail_analysis = schedule_mail_analysis.merge(train_current_status_copy1[["rake_name","TXR_Due_Date","TXR_KmsRem_CurrDest"]], left_on = ["rake_name"], right_on = ["rake_name"], how = 'left').reset_index(drop = True)
      schedule_mail_analysis["loaded_TEUs_evacuated"], schedule_mail_analysis["empty_TEUs_evacuated"] = schedule_mail_analysis["loaded_TEUs_evacuated_20"] + schedule_mail_analysis["loaded_TEUs_evacuated_40"], schedule_mail_analysis["empty_TEUs_evacuated_20"] + schedule_mail_analysis["empty_TEUs_evacuated_40"]
      schedule_mail_analysis.currtrp_ETA = pd.to_datetime(schedule_mail_analysis["currtrp_ETA"]).apply(lambda x: x.strftime('%Y-%m-%d %H:%M'))
      schedule_mail_analysis.TXR_Due_Date = pd.to_datetime(schedule_mail_analysis["TXR_Due_Date"]).apply(lambda x: x.strftime('%Y-%m-%d'))
      schedule_mail_analysis.loc[schedule_mail_analysis["Trip_Num"] == 2, ["current_trip","currtrp_ETA","rake_status","TXR_KmsRem_CurrDest"]] = ''

      # Pendency Data to be merged with output
      final_pend = pendency_data[(pendency_data.odr_days < 0) & (pendency_data.flag == 1)].copy()
      final_pend["pendency"] = final_pend["pendency"] + final_pend["empty_pendency"]
      final_pend = final_pend.groupby(["booking_location_code","to_terminal_code"]).agg({"pendency":"sum"}).reset_index()
      final_pend['next_trip_trip1'] = final_pend['booking_location_code'] + "-" + final_pend["to_terminal_code"]

      # Final Output Prep
      try:
        final_df = schedule_mail_analysis.copy().reset_index(drop = True)
        final_df["TEUs_evacuated"] = final_df["loaded_TEUs_evacuated"] + final_df["empty_TEUs_evacuated"]
        cols = ["rake_name","current_trip","currtrp_ETA","rake_status","unts","base_depot_code","TXR_Due_Date","TXR_KmsRem_CurrDest"]
        cols1= ['rake_name', 'next_trip', 'loaded_TEUs_evacuated_20','loaded_TEUs_evacuated_40','empty_TEUs_evacuated_20','empty_TEUs_evacuated_40','loaded_TEUs_evacuated', 'empty_TEUs_evacuated',"STATUS_FLAG","AWAITING_FORECAST"]
        final_df1 = pd.merge(final_df[final_df.Trip_Num == 1][cols], final_df[final_df.Trip_Num == 1][cols1], on = "rake_name", how = 'outer') #pd.concat([schedule_mail1, schedule_mail2], axis = 1)
        final_df = pd.merge(final_df1, final_df[final_df.Trip_Num == 2][cols1], on = "rake_name", how = "outer")
        final_df.rename(columns = lambda x: x[:-2]+"_trip1" if x.endswith('_x') else x, inplace = True)
        final_df.rename(columns = lambda x: x[:-2]+"_trip2" if x.endswith('_y') else x, inplace = True)
        final_df['TEUs_trip1'], final_df['TEUs_trip2'] = final_df['loaded_TEUs_evacuated_trip1'] + final_df['empty_TEUs_evacuated_trip1'], final_df['loaded_TEUs_evacuated_trip2'] + final_df['empty_TEUs_evacuated_trip2']
        final_df['destination0'] = [l[0] if len(l) > 0 else np.nan for l in final_df['next_trip_trip1'].str.split("-")]
        final_df.next_trip_trip2 = final_df.next_trip_trip2.fillna("Not Suggested")
        final_df.TEUs_trip2 = final_df.TEUs_trip2.fillna(0)
        final_df = final_df.sort_values(by = ["destination0","currtrp_ETA"]).reset_index(drop = True)
        final_df = final_df.merge(final_pend[["next_trip_trip1","pendency"]], on = ["next_trip_trip1"], how = "left")
        final_df = update_pendency_in_ouput(final_df, 'pendency','TEUs_trip1') # defined in the function to consider next_trip1 only
        final_df = final_df[['rake_name', 'current_trip', 'currtrp_ETA', 'rake_status', 'pendency','next_trip_trip1', 'TEUs_trip1', 'AWAITING_FORECAST_trip1','STATUS_FLAG_trip1',
                            'next_trip_trip2', 'TEUs_trip2', 'AWAITING_FORECAST_trip2', 'STATUS_FLAG_trip2',
                            'loaded_TEUs_evacuated_20_trip1', 'loaded_TEUs_evacuated_40_trip1', 'empty_TEUs_evacuated_20_trip1', 'empty_TEUs_evacuated_40_trip1',
                            'loaded_TEUs_evacuated_20_trip2', 'loaded_TEUs_evacuated_40_trip2', 'empty_TEUs_evacuated_20_trip2', 'empty_TEUs_evacuated_40_trip2',
                            'unts', 'base_depot_code', 'TXR_Due_Date', 'TXR_KmsRem_CurrDest']]

        final_df = update_status_in_trip(final_df,'next_trip_trip1','STATUS_FLAG_trip1')
        final_df = update_status_in_trip(final_df,'next_trip_trip2','STATUS_FLAG_trip2')
        # final_df = update_via_rt_terminals(final_df, via_rt, 'next_trip_trip1')
        # final_df = update_via_rt_terminals(final_df, via_rt, 'next_trip_trip2')
        final_df = remove_duplicate_terminals_from_trips(final_df, 'next_trip_trip1')
        final_df = remove_duplicate_terminals_from_trips(final_df, 'next_trip_trip2')
        final_df = update_parking_spot(final_df,'next_trip_trip1','STATUS_FLAG_trip1')
        final_df = update_parking_spot(final_df,'next_trip_trip2','STATUS_FLAG_trip2')

        final_df = final_df[['rake_name', 'current_trip', 'currtrp_ETA', 'rake_status', 'next_trip_trip1', 'AWAITING_FORECAST_trip1', 'STATUS_FLAG_trip1',
                            'AWAITING_FORECAST_trip2',
                            'STATUS_FLAG_trip2','pendency', 'TEUs_trip1', 'next_trip_trip2', 'TEUs_trip2',
                            'loaded_TEUs_evacuated_20_trip1', 'loaded_TEUs_evacuated_40_trip1', 'empty_TEUs_evacuated_20_trip1', 'empty_TEUs_evacuated_40_trip1',
                            'loaded_TEUs_evacuated_20_trip2', 'loaded_TEUs_evacuated_40_trip2', 'empty_TEUs_evacuated_20_trip2', 'empty_TEUs_evacuated_40_trip2',
                            'unts', 'base_depot_code', 'TXR_Due_Date', 'TXR_KmsRem_CurrDest']]
      except:
        final_df = pd.DataFrame(columns = ['rake_name', 'current_trip', 'currtrp_ETA', 'rake_status', 'next_trip_trip1', 'AWAITING_FORECAST_trip1', 'STATUS_FLAG_trip1',
                                          'AWAITING_FORECAST_trip2',
                                          'STATUS_FLAG_trip2', 'pendency', 'TEUs_trip1', 'next_trip_trip2', 'TEUs_trip2',
                                          'loaded_TEUs_evacuated_20_trip1', 'loaded_TEUs_evacuated_40_trip1', 'empty_TEUs_evacuated_20_trip1', 'empty_TEUs_evacuated_40_trip1',
                                          'loaded_TEUs_evacuated_20_trip2', 'loaded_TEUs_evacuated_40_trip2', 'empty_TEUs_evacuated_20_trip2', 'empty_TEUs_evacuated_40_trip2',
                                          'unts', 'base_depot_code', 'TXR_Due_Date', 'TXR_KmsRem_CurrDest'])

      final_df = final_df.fillna(0)

      ####################################################################################################################################

      # If pendency is forecast pendency then set awaiting forecast column as "yes"
      for i in range(len(final_df)):
      # this condition is added for all forecast schedules
        if final_df.loc[i,"AWAITING_FORECAST_trip1"] == "Yes":
          continue
        else:
          final_df.loc[i,"AWAITING_FORECAST_trip1"] = "No"


      # If pendency is forecast pendency then set awaiting forecast column as "yes"
      for i in range(len(final_df)):
      # this condition is added for all forecast schedules
        if final_df.loc[i,"AWAITING_FORECAST_trip2"] == "Yes":
          continue
        else:
          final_df.loc[i,"AWAITING_FORECAST_trip2"] = "No"

      final_df.rename(columns = {"AWAITING_FORECAST_trip1":"AF_1","AWAITING_FORECAST_trip2":"AF_2"}, inplace = True)

      # Status Flag reflects the reason behind scheduling - 0 (scheduled), -1 (TXR), -2 (TXR-NO-ROUTE-TO-BASE)
      # AF_1 or AF_2 reflects whether rake is carrying pendency or awaiting forecast pendency

      final_df = final_df.reset_index(drop = True)

      atTrakes_prev_terminals1 = atTrakes_prev_terminals_copy.copy()
      atTrakes_prev_terminals1['current_trip_replace'] = atTrakes_prev_terminals1['prev_origin'] + "-" + atTrakes_prev_terminals1['prev_dest']
      final_df = final_df.merge(atTrakes_prev_terminals1, on = ["rake_name","rake_status"], how = "left")
      final_df.current_trip_replace = final_df.current_trip_replace.fillna(final_df.current_trip)
      final_df.current_trip = final_df.current_trip_replace
      final_df.drop(columns = ["prev_origin","prev_dest","crntdvsn","crntsttn","current_trip_replace"], inplace = True)




      final_df['STATUS_FLAG_trip1'] = final_df['STATUS_FLAG_trip1'].apply(lambda x: "BPC LICENSE EXPIRED" if x in ([-1]) else x)
      final_df['STATUS_FLAG_trip2'] = final_df['STATUS_FLAG_trip2'].apply(lambda x: "BPC LICENSE EXPIRED" if x in ([-1]) else x)
      final_df['STATUS_FLAG_trip1'] = final_df['STATUS_FLAG_trip1'].apply(lambda x: "LOW INVENTORY" if x in ([1]) else x)
      final_df['STATUS_FLAG_trip2'] = final_df['STATUS_FLAG_trip2'].apply(lambda x: "LOW INVENTORY" if x in ([1]) else x)
      final_df['STATUS_FLAG_trip1'] = final_df['STATUS_FLAG_trip1'].apply(lambda x: "NONE" if x in ([0]) else x)
      final_df['STATUS_FLAG_trip2'] = final_df['STATUS_FLAG_trip2'].apply(lambda x: "NONE" if x in ([0]) else x)
      final_df['STATUS_FLAG_trip1'] = final_df['STATUS_FLAG_trip1'].apply(lambda x: "BPC LICENSE EXPIRED/NO DIRECT ROUTE" if x in ([-2]) else x)
      final_df['STATUS_FLAG_trip2'] = final_df['STATUS_FLAG_trip2'].apply(lambda x: "BPC LICENSE EXPIRED/NO DIRECT ROUTE" if x in ([-2]) else x)
      final_df['STATUS_FLAG_trip1'] = final_df['STATUS_FLAG_trip1'].apply(lambda x: "FORECAST PENDENCY" if x in ([5]) else x)
      final_df['STATUS_FLAG_trip2'] = final_df['STATUS_FLAG_trip2'].apply(lambda x: "FORECAST PENDENCY" if x in ([5]) else x)

      for index, row in final_df.iterrows():
        if row.pendency<row.TEUs_trip1:
          final_df.at[index,'STATUS_FLAG_trip1'] = final_df.at[index,'STATUS_FLAG_trip1']+" AND HUB PENDENCY"
        if row.pendency<row.TEUs_trip2:
          final_df.at[index,'STATUS_FLAG_trip2'] = final_df.at[index,'STATUS_FLAG_trip2']+" AND HUB PENDENCY"
        
      final_df['pendency'] = final_df['pendency'].apply(lambda x:0  if x <0 else x)
      final_df
    
      print("***** Optimization DataFrame Generated *****")
      plan_id = email.split('@')[0].replace(".","")+'-'+email.split('@')[0].replace(".","")+'-'+opt_start_time.replace('-','').replace(':','').replace(" ","")
      if final_df.shape[0]==0:
          df_load_bq=pd.DataFrame(columns=['rake_name', 'current_trip', 'currtrp_ETA', 'rake_status', 'next_trip_trip1', 'pendency', 'TEUs_trip1',
                                            'next_trip_trip2', 'TEUs_trip2',
                                            'loaded_TEUs_evacuated_20_trip1', 'loaded_TEUs_evacuated_40_trip1', 'empty_TEUs_evacuated_20_trip1', 'empty_TEUs_evacuated_40_trip1',
                                            'loaded_TEUs_evacuated_20_trip2', 'loaded_TEUs_evacuated_40_trip2', 'empty_TEUs_evacuated_20_trip2', 'empty_TEUs_evacuated_40_trip2',
                                            'unts', 'base_depot_code', 'TXR_Due_Date', 'TXR_KmsRem_CurrDest','af1','af_2','status_flag_trip1','status_flag_trip2',
                                            'status'])
          df_load_bq['load_ts']=pd.Series(now)
          df_load_bq['email']=pd.Series(email)
          df_load_bq['optimization_type']='generic'
          df_load_bq['status']='Generated'
          #df_load_bq['email']=email
          
          opt_end_time = datetime.now(timezone("Asia/Kolkata")).strftime('%Y-%m-%d %H:%M:%S')
          df_load_bq['opt_start_time']=opt_start_time
          df_load_bq['opt_end_time']=opt_end_time
          df_load_bq['opt_start_time']=pd.to_datetime(df_load_bq['opt_start_time'])
          df_load_bq['opt_end_time']=pd.to_datetime(df_load_bq['opt_end_time'])
          
          df_load_bq['error']='No Optimization Plan Generated'
          df_load_bq['created_by'] = email
          df_load_bq['plan_id'] = plan_id

          print(df_load_bq)
          #schema=[{"name": "rake_name","type": "STRING"},{"name": "current_trip","type": "STRING"},{"name": "currtrp_eta","type": "TIMESTAMP"},{"name": "rake_status","type": "STRING"},{"name": "next_trip_trip1","type": "STRING"},{"name": "pendency","type": "INTEGER"},{"name": "teus_trip1","type": "INTEGER"},{"name": "next_trip_trip2","type": "STRING"},{"name": "teus_trip2","type": "INTEGER"},{"name": "loaded_teus_evacuated_20_trip1","type": "INTEGER"},{"name": "loaded_teus_evacuated_40_trip1","type": "INTEGER"},{"name": "empty_teus_evacuated_20_trip1","type": "INTEGER"},{"name": "empty_teus_evacuated_40_trip1","type": "INTEGER"},{"name": "loaded_teus_evacuated_20_trip2","type": "INTEGER"},{"name": "loaded_teus_evacuated_40_trip2","type": "INTEGER"},{"name": "empty_teus_evacuated_20_trip2","type": "INTEGER"},{"name": "empty_teus_evacuated_40_trip2","type": "INTEGER"},{"name": "unts","type": "STRING"},{"name": "base_depot_code","type": "STRING"},{"name": "txr_due_date","type": "STRING"},{"name": "txr_kmsrem_currdest","type": "INTEGER"},{"name": "pendency_empties","type": "INTEGER"},{"name": "pendency_loaded","type": "INTEGER"},{"name": "load_ts","type": "TIMESTAMP"},{"name": "plan_type","type": "STRING"},{"name": "email","type": "STRING"},{"name": "optimization_type","type": "STRING"},{"name": "error","type": "STRING"},{"name": "opt_start_time","type": "TIMESTAMP"},{"name": "opt_end_time","type": "TIMESTAMP"}]
          schema=[{"name": "rake_name","type": "STRING"},{"name": "current_trip","type": "STRING"},{"name": "currtrp_eta","type": "TIMESTAMP"},{"name": "rake_status","type": "STRING"},{"name": "next_trip_trip1","type": "STRING"},{"name": "pendency","type": "INTEGER"},{"name": "teus_trip1","type": "INTEGER"},{"name": "next_trip_trip2","type": "STRING"},{"name": "teus_trip2","type": "INTEGER"},{"name": "loaded_teus_evacuated_20_trip1","type": "INTEGER"},{"name": "loaded_teus_evacuated_40_trip1","type": "INTEGER"},{"name": "empty_teus_evacuated_20_trip1","type": "INTEGER"},{"name": "empty_teus_evacuated_40_trip1","type": "INTEGER"},{"name": "loaded_teus_evacuated_20_trip2","type": "INTEGER"},{"name": "loaded_teus_evacuated_40_trip2","type": "INTEGER"},{"name": "empty_teus_evacuated_20_trip2","type": "INTEGER"},{"name": "empty_teus_evacuated_40_trip2","type": "INTEGER"},{"name": "unts","type": "STRING"},{"name": "base_depot_code","type": "STRING"},{"name": "txr_due_date","type": "STRING"},{"name": "txr_kmsrem_currdest","type": "INTEGER"},{"name": "pendency_empties","type": "INTEGER"},{"name": "pendency_loaded","type": "INTEGER"},{"name": "load_ts","type": "TIMESTAMP"},{"name": "status","type": "STRING"},{"name": "email","type": "STRING"},{"name": "optimization_type","type": "STRING"},{"name": "error","type": "STRING"},{"name": "opt_start_time","type": "TIMESTAMP"},{"name": "opt_end_time","type": "TIMESTAMP"},{"name": "af_1","type": "STRING"},{"name": "af_2","type": "STRING"},{"name": "status_flg_trip1","type": "STRING"},{"name": "status_flag_trip2","type": "STRING"},{"name": "created_by","type": "STRING"},{"name": "plan_id","type": "STRING"}]
          df_load_bq.to_gbq('apsez-svc-prod-datalake.logistics_cleansed.layer2_route_optimization_plan_api',project_id='apsez-svc-prod-datalake',table_schema=schema,if_exists='append')
          #df_load_bq.to_gbq('apsez-svc-prod-datalake.logistics_cleansed.layer2_route_optimization_plan_api',project_id='apsez-svc-prod-datalake',if_exists='replace')
          print("Empty Data, No Optimization Plan Generated")
          return "No Optimization Plan Generated"
    
      print("**************** Rail Route optimization Plan Generated ***********")
      ####################################################
      data_df = final_df.copy()
      
    
      data_df[['TXR_KmsRem_CurrDest','loaded_TEUs_evacuated_20_trip1','loaded_TEUs_evacuated_40_trip1','empty_TEUs_evacuated_20_trip1','empty_TEUs_evacuated_40_trip1',
      'loaded_TEUs_evacuated_20_trip2','loaded_TEUs_evacuated_40_trip2','empty_TEUs_evacuated_20_trip2','empty_TEUs_evacuated_40_trip2']] = data_df[['TXR_KmsRem_CurrDest',
      'loaded_TEUs_evacuated_20_trip1','loaded_TEUs_evacuated_40_trip1','empty_TEUs_evacuated_20_trip1','empty_TEUs_evacuated_40_trip1',
      'loaded_TEUs_evacuated_20_trip2','loaded_TEUs_evacuated_40_trip2','empty_TEUs_evacuated_20_trip2','empty_TEUs_evacuated_40_trip2']].fillna(-99).astype(int)
    
      
      
      data_df.columns = data_df.columns.str.lower()
      if recalculate:
        data_df_fx=final_df_changed[final_df_changed.recalculate==1].reset_index(drop=True)
        data_df_fx=data_df_fx.drop(columns = ["recalculate"])
        data_df.columns = data_df.columns.str.lower()
        data_df=pd.concat([data_df_fx,data_df]).reset_index(drop=True)

      data_df[['pendency_empties','pendency_loaded']] = 0  

      data_df["timestamp"] = now
      data_df.rename(columns = {"timestamp":"load_ts"},inplace=True)
      data_df['load_ts'] = pd.to_datetime(data_df['load_ts'])
      data_df['currtrp_eta'] = pd.to_datetime(data_df['currtrp_eta'])
      data_df['txr_due_date'] = pd.to_datetime(data_df['txr_due_date']).dt.date.astype(str)
      
      print("***************LOAD BQ Table******************")
      df_load_bq = data_df.copy()
      df_load_bq.columns=df_load_bq.columns.str.lower()
      df_load_bq['email']=email
      df_load_bq['created_by'] = df_load_bq['email']
      df_load_bq['plan_id'] = plan_id
      df_load_bq['optimization_type']='generic'
      df_load_bq['error']=''
      df_load_bq['status'] = 'Generated'
      #if recalculate:
      #   df_load_bq['status'] = 'Recalculated'
      opt_end_time = datetime.now(timezone("Asia/Kolkata")).strftime('%Y-%m-%d %H:%M:%S')
      df_load_bq['opt_start_time']=opt_start_time
      df_load_bq['opt_end_time']=opt_end_time
      df_load_bq['opt_start_time']=pd.to_datetime(df_load_bq['opt_start_time'])
      df_load_bq['opt_end_time']=pd.to_datetime(df_load_bq['opt_end_time'])
      
      df_load_bq[['rake_name', 'current_trip', 'rake_status', 'next_trip_trip1', 'next_trip_trip2', 'unts', 'base_depot_code', 'txr_due_date', 'status', 'email', 'optimization_type', 'error','af_1','af_2']]=df_load_bq[['rake_name', 'current_trip', 'rake_status', 'next_trip_trip1', 'next_trip_trip2', 'unts', 'base_depot_code', 'txr_due_date', 'status', 'email', 'optimization_type', 'error','af_1','af_2']].astype(str)
      df_load_bq[['pendency', 'teus_trip1', 'teus_trip2', 'loaded_teus_evacuated_20_trip1', 'loaded_teus_evacuated_40_trip1', 'empty_teus_evacuated_20_trip1', 'empty_teus_evacuated_40_trip1', 'loaded_teus_evacuated_20_trip2', 'loaded_teus_evacuated_40_trip2', 'empty_teus_evacuated_20_trip2', 'empty_teus_evacuated_40_trip2', 'txr_kmsrem_currdest', 'pendency_empties', 'pendency_loaded']]=df_load_bq[['pendency', 'teus_trip1', 'teus_trip2', 'loaded_teus_evacuated_20_trip1', 'loaded_teus_evacuated_40_trip1', 'empty_teus_evacuated_20_trip1', 'empty_teus_evacuated_40_trip1', 'loaded_teus_evacuated_20_trip2', 'loaded_teus_evacuated_40_trip2', 'empty_teus_evacuated_20_trip2', 'empty_teus_evacuated_40_trip2', 'txr_kmsrem_currdest', 'pendency_empties', 'pendency_loaded']].astype(int)
      df_load_bq = df_load_bq[['rake_name', 'current_trip', 'currtrp_eta', 'rake_status', 'next_trip_trip1', 'pendency', 'teus_trip1', 'next_trip_trip2', 'teus_trip2', 'loaded_teus_evacuated_20_trip1', 'loaded_teus_evacuated_40_trip1', 'empty_teus_evacuated_20_trip1', 'empty_teus_evacuated_40_trip1', 'loaded_teus_evacuated_20_trip2', 'loaded_teus_evacuated_40_trip2', 'empty_teus_evacuated_20_trip2', 'empty_teus_evacuated_40_trip2', 'unts', 'base_depot_code', 'txr_due_date', 'txr_kmsrem_currdest', 'pendency_empties', 'pendency_loaded', 'load_ts', 'status', 'email', 'optimization_type', 'error', 'opt_start_time', 'opt_end_time', 'af_1', 'af_2', 'status_flag_trip1', 'status_flag_trip2', 'created_by', 'plan_id']]
      #schema=[{"name": "rake_name","type": "STRING"},{"name": "current_trip","type": "STRING"},{"name": "currtrp_eta","type": "TIMESTAMP"},{"name": "rake_status","type": "STRING"},{"name": "next_trip_trip1","type": "STRING"},{"name": "pendency","type": "INTEGER"},{"name": "teus_trip1","type": "INTEGER"},{"name": "next_trip_trip2","type": "STRING"},{"name": "teus_trip2","type": "INTEGER"},{"name": "loaded_teus_evacuated_20_trip1","type": "INTEGER"},{"name": "loaded_teus_evacuated_40_trip1","type": "INTEGER"},{"name": "empty_teus_evacuated_20_trip1","type": "INTEGER"},{"name": "empty_teus_evacuated_40_trip1","type": "INTEGER"},{"name": "loaded_teus_evacuated_20_trip2","type": "INTEGER"},{"name": "loaded_teus_evacuated_40_trip2","type": "INTEGER"},{"name": "empty_teus_evacuated_20_trip2","type": "INTEGER"},{"name": "empty_teus_evacuated_40_trip2","type": "INTEGER"},{"name": "unts","type": "STRING"},{"name": "base_depot_code","type": "STRING"},{"name": "txr_due_date","type": "STRING"},{"name": "txr_kmsrem_currdest","type": "INTEGER"},{"name": "pendency_empties","type": "INTEGER"},{"name": "pendency_loaded","type": "INTEGER"},{"name": "load_ts","type": "TIMESTAMP"},{"name": "plan_type","type": "STRING"},{"name": "email","type": "STRING"},{"name": "optimization_type","type": "STRING"},{"name": "error","type": "STRING"},{"name": "opt_start_time","type": "TIMESTAMP"},{"name": "opt_end_time","type": "TIMESTAMP"}]
      schema=[{"name": "rake_name","type": "STRING"},{"name": "current_trip","type": "STRING"},{"name": "currtrp_eta","type": "TIMESTAMP"},{"name": "rake_status","type": "STRING"},{"name": "next_trip_trip1","type": "STRING"},{"name": "pendency","type": "INTEGER"},{"name": "teus_trip1","type": "INTEGER"},{"name": "next_trip_trip2","type": "STRING"},{"name": "teus_trip2","type": "INTEGER"},{"name": "loaded_teus_evacuated_20_trip1","type": "INTEGER"},{"name": "loaded_teus_evacuated_40_trip1","type": "INTEGER"},{"name": "empty_teus_evacuated_20_trip1","type": "INTEGER"},{"name": "empty_teus_evacuated_40_trip1","type": "INTEGER"},{"name": "loaded_teus_evacuated_20_trip2","type": "INTEGER"},{"name": "loaded_teus_evacuated_40_trip2","type": "INTEGER"},{"name": "empty_teus_evacuated_20_trip2","type": "INTEGER"},{"name": "empty_teus_evacuated_40_trip2","type": "INTEGER"},{"name": "unts","type": "STRING"},{"name": "base_depot_code","type": "STRING"},{"name": "txr_due_date","type": "STRING"},{"name": "txr_kmsrem_currdest","type": "INTEGER"},{"name": "pendency_empties","type": "INTEGER"},{"name": "pendency_loaded","type": "INTEGER"},{"name": "load_ts","type": "TIMESTAMP"},{"name": "status","type": "STRING"},{"name": "email","type": "STRING"},{"name": "optimization_type","type": "STRING"},{"name": "error","type": "STRING"},{"name": "opt_start_time","type": "TIMESTAMP"},{"name": "opt_end_time","type": "TIMESTAMP"},{"name": "af_1","type": "STRING"},{"name": "af_2","type": "STRING"},{"name": "status_flg_trip1","type": "STRING"},{"name": "status_flag_trip2","type": "STRING"},{"name": "created_by","type": "STRING"},{"name": "plan_id","type": "STRING"}]
      print("df_load_bq columns : ",df_load_bq.columns, "\n shape : ",df_load_bq.shape)
      print("sample df_load_bq data : ",df_load_bq.head())
      df_load_bq.to_gbq('apsez-svc-prod-datalake.logistics_cleansed.layer2_route_optimization_plan_api',project_id='apsez-svc-prod-datalake',table_schema=schema,if_exists='append')
      df_load_bq.to_gbq('apsez-svc-prod-datalake.logistics_cleansed.layer2_route_optimization_plan_api_h',project_id='apsez-svc-prod-datalake',table_schema=schema,if_exists='append')
      #df_load_bq.to_gbq('apsez-svc-prod-datalake.logistics_cleansed.layer2_route_optimization_plan_api',project_id='apsez-svc-prod-datalake',if_exists='replace')
      
      # ans = json.dumps(json.loads(final_df.to_json(orient = 'index')))
      print("done")
      return "done"
    except Exception as e:
        print("Failed due to : ",e)
        plan_id = email.split('@')[0].replace(".","")+'-'+email.split('@')[0].replace(".","")+'-'+opt_start_time.replace('-','').replace(':','').replace(" ","")
        df_load_bq=pd.DataFrame(columns=['rake_name', 'current_trip', 'currtrp_ETA', 'rake_status', 'next_trip_trip1', 'pendency', 'TEUs_trip1',
                                              'next_trip_trip2', 'TEUs_trip2',
                                              'loaded_TEUs_evacuated_20_trip1', 'loaded_TEUs_evacuated_40_trip1', 'empty_TEUs_evacuated_20_trip1', 'empty_TEUs_evacuated_40_trip1',
                                              'loaded_TEUs_evacuated_20_trip2', 'loaded_TEUs_evacuated_40_trip2', 'empty_TEUs_evacuated_20_trip2', 'empty_TEUs_evacuated_40_trip2',
                                              'unts', 'base_depot_code', 'TXR_Due_Date', 'TXR_KmsRem_CurrDest','af1','af_2','status_flag_trip1','status_flag_trip2'])
        df_load_bq['email']=pd.Series(email)
        df_load_bq['load_ts']=now
        df_load_bq['load_ts'] = pd.to_datetime(df_load_bq['load_ts'])
        df_load_bq['optimization_type']='generic'
        #df_load_bq['email']=email
        
        opt_end_time = datetime.now(timezone("Asia/Kolkata")).strftime('%Y-%m-%d %H:%M:%S')
        df_load_bq['opt_start_time']=opt_start_time
        df_load_bq['opt_end_time']=opt_end_time
        df_load_bq['opt_start_time']=pd.to_datetime(df_load_bq['opt_start_time'])
        df_load_bq['opt_end_time']=pd.to_datetime(df_load_bq['opt_end_time'])
        df_load_bq['status']='Generated'
        
        df_load_bq['error']=str(e)
        df_load_bq['created_by'] = df_load_bq['email']
        df_load_bq['plan_id'] = plan_id
        print(df_load_bq)
        #schema=[{"name": "rake_name","type": "STRING"},{"name": "current_trip","type": "STRING"},{"name": "currtrp_eta","type": "TIMESTAMP"},{"name": "rake_status","type": "STRING"},{"name": "next_trip_trip1","type": "STRING"},{"name": "pendency","type": "INTEGER"},{"name": "teus_trip1","type": "INTEGER"},{"name": "next_trip_trip2","type": "STRING"},{"name": "teus_trip2","type": "INTEGER"},{"name": "loaded_teus_evacuated_20_trip1","type": "INTEGER"},{"name": "loaded_teus_evacuated_40_trip1","type": "INTEGER"},{"name": "empty_teus_evacuated_20_trip1","type": "INTEGER"},{"name": "empty_teus_evacuated_40_trip1","type": "INTEGER"},{"name": "loaded_teus_evacuated_20_trip2","type": "INTEGER"},{"name": "loaded_teus_evacuated_40_trip2","type": "INTEGER"},{"name": "empty_teus_evacuated_20_trip2","type": "INTEGER"},{"name": "empty_teus_evacuated_40_trip2","type": "INTEGER"},{"name": "unts","type": "STRING"},{"name": "base_depot_code","type": "STRING"},{"name": "txr_due_date","type": "STRING"},{"name": "txr_kmsrem_currdest","type": "INTEGER"},{"name": "pendency_empties","type": "INTEGER"},{"name": "pendency_loaded","type": "INTEGER"},{"name": "load_ts","type": "TIMESTAMP"},{"name": "plan_type","type": "STRING"},{"name": "email","type": "STRING"},{"name": "optimization_type","type": "STRING"},{"name": "error","type": "STRING"},{"name": "opt_start_time","type": "TIMESTAMP"},{"name": "opt_end_time","type": "TIMESTAMP"}]
        schema=[{"name": "rake_name","type": "STRING"},{"name": "current_trip","type": "STRING"},{"name": "currtrp_eta","type": "TIMESTAMP"},{"name": "rake_status","type": "STRING"},{"name": "next_trip_trip1","type": "STRING"},{"name": "pendency","type": "INTEGER"},{"name": "teus_trip1","type": "INTEGER"},{"name": "next_trip_trip2","type": "STRING"},{"name": "teus_trip2","type": "INTEGER"},{"name": "loaded_teus_evacuated_20_trip1","type": "INTEGER"},{"name": "loaded_teus_evacuated_40_trip1","type": "INTEGER"},{"name": "empty_teus_evacuated_20_trip1","type": "INTEGER"},{"name": "empty_teus_evacuated_40_trip1","type": "INTEGER"},{"name": "loaded_teus_evacuated_20_trip2","type": "INTEGER"},{"name": "loaded_teus_evacuated_40_trip2","type": "INTEGER"},{"name": "empty_teus_evacuated_20_trip2","type": "INTEGER"},{"name": "empty_teus_evacuated_40_trip2","type": "INTEGER"},{"name": "unts","type": "STRING"},{"name": "base_depot_code","type": "STRING"},{"name": "txr_due_date","type": "STRING"},{"name": "txr_kmsrem_currdest","type": "INTEGER"},{"name": "pendency_empties","type": "INTEGER"},{"name": "pendency_loaded","type": "INTEGER"},{"name": "load_ts","type": "TIMESTAMP"},{"name": "status","type": "STRING"},{"name": "email","type": "STRING"},{"name": "optimization_type","type": "STRING"},{"name": "error","type": "STRING"},{"name": "opt_start_time","type": "TIMESTAMP"},{"name": "opt_end_time","type": "TIMESTAMP"},{"name": "af_1","type": "STRING"},{"name": "af_2","type": "STRING"},{"name": "status_flg_trip1","type": "STRING"},{"name": "status_flag_trip2","type": "STRING"},{"name": "created_by","type": "STRING"},{"name": "plan_id","type": "STRING"}]
        df_load_bq.to_gbq('apsez-svc-prod-datalake.logistics_cleansed.layer2_route_optimization_plan_api',project_id='apsez-svc-prod-datalake',table_schema=schema,if_exists='append')
        df_load_bq.to_gbq('apsez-svc-prod-datalake.logistics_cleansed.layer2_route_optimization_plan_api_h',project_id='apsez-svc-prod-datalake',table_schema=schema,if_exists='append')
        #df_load_bq.to_gbq('apsez-svc-prod-datalake.logistics_cleansed.layer2_route_optimization_plan_api',project_id='apsez-svc-prod-datalake',if_exists='replace')
        print("Optimization failed with an Error")
        return "Optimization failed with an Error"
      
      
    

    
    ##################################################################################################################
    # APSEZ ANALYTICS CODE ENDS
    ##################################################################################################################
