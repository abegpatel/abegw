import pandas as pd
import io
import sqlalchemy as sql
from sqlalchemy.orm import sessionmaker
from datetime import date
from dateutil.relativedelta import *
import psycopg2

 
# Define database connection parameters

# analytics db
hostname = "10.90.96.17"
#hostname = "apsez-as1-analytics-prod-rds.cpjhdhjkpglj.ap-south-1.rds.amazonaws.com"

# real time db
#hostname = "10.90.96.22"
#hostname = "apsez-as1-analytics-prod-rds-speed.cpjhdhjkpglj.ap-south-1.rds.amazonaws.com"

username = "data_lake_user"
#password = 'Adani@12I356'

database = "analytics"
#database = "analytics_speed"


engine = sql.create_engine('postgresql+psycopg2://{0}:Adani"@"123456@{1}:5432/{2}?sslmode=require'.format(username, hostname, database))
print('postgresql+psycopg2://{0}:Adani@123456@{1}:5432/{2}?sslmode=require'.format(username, hostname, database))
Session = sessionmaker(bind=engine)
session = Session()
conn = engine.connect()
#cur = conn.cursor()
print("Connection with RDS Database `{0}` established successfully!!".format(database))

#conn = engine.connect()
#query = "select * from analytics_prod.ports_tbl_ctrmovement limit 10"
#query = "select * from analytics_prod.ports_tbl_ctrmovement_real_time limit 10"
#df = pd.read_sql(query,conn)
print(df)
conn.close()
