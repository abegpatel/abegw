import pandas as pd
import io
import sqlalchemy as sql
from sqlalchemy.orm import sessionmaker
from datetime import date
from dateutil.relativedelta import *
import psycopg2
import pandas_gbq as pdq

import logging

# Define database connection parameters

# analytics db
#hostname = "10.90.96.17"
#hostname = "apsez-as1-analytics-prod-rds.cpjhdhjkpglj.ap-south-1.rds.amazonaws.com"

# real time db
#hostname = 10.90.96.22
#hostname = "apsez-as1-analytics-prod-rds-speed.cpjhdhjkpglj.ap-south-1.rds.amazonaws.com"

#username = "data_lake_user"
#password = 'Adani@123456'

#database = "analytics"
#database = "analytics_speed"

hostname = "10.81.162.4"
username="test_user"
password="test_user"
database="test_db"

# With SSL Certificate
#engine = sql.create_engine('postgresql+psycopg2://{0}:"Adani123456"@{1}:5432/{2}?sslmode =require&sslrootcert=server-ca.pem&sslcert =client-cert.pem&sslkey=client-key.pem'.format(username, hostname, database))


# Without SSL Certificate

engine = sql.create_engine('postgresql+psycopg2://{0}:test_user@{1}:5432/{2}'.format(username, hostname, database))

print('postgresql+psycopg2://{0}:Adani@123456@{1}:5432/{2}'.format(username, hostname, database))

Session = sessionmaker(bind=engine)
session = Session()
conn = engine.raw_connection()
cur = conn.cursor()
print("Connection with RDS Database `{0}` established successfully!!".format(database))

conn = engine.connect()
query = "select * from demo.delta"
#query = "select * from analytics_prod.ports_tbl_ctrmovement_real_time limit 10"
rows = conn.execute(query)
#print("Rows:",rows)


project_id='apsez-svc-dev-datalake'
project='Test_Dev.ABC'
bigquery_schema=  [{'name': 'id','type': 'INTEGER'}, {'name': 'name','type': 'STRING'}]
ColumnsL= ['id', 'name']

chunk_size=500
batch_no=1
logging.info('Loading to  DataFrame....')
print("1")
try:
  print("2")
  for chunk in pd.read_sql(query,conn,chunksize=chunk_size):
     print("3")
     logging.info('Taking data into DataFrame....')
     df = pd.DataFrame(chunk,columns=ColumnsL,index=None)
     logging.info('Loading data in bq: %s',df)
     print(df)
     try:
         pdq.to_gbq(df,project,project_id,if_exists='append',table_schema=bigquery_schema)
         batch_no+=1
         logging.info('Data Loaded : %s for batch no :%s ',project,batch_no)
         logging.info('Job Run Complete:%s',project)
     except Exception as e:
         logging.info(e)
except:
    logging.info('connection loss')

