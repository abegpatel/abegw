import pandas as pd
import io
#import sqlalchemy as sql
#from sqlalchemy.orm import sessionmaker
from datetime import date
from dateutil.relativedelta import *
import psycopg2
import pandas_gbq as pdq

import logging

# Define database connection parameters

# analytics db
#hostname = "10.90.96.17"
#hostname = "apsez-as1-analytics-prod-rds.cpjhdhjkpglj.ap-south-1.rds.amazonaws.com"

# real time db
#hostname = 10.90.96.22
#hostname = "apsez-as1-analytics-prod-rds-speed.cpjhdhjkpglj.ap-south-1.rds.amazonaws.com"

#username = "data_lake_user"
#password = 'Adani@123456'

#database = "analytics"
#database = "analytics_speed"

hostname = "10.81.162.4"
username="test_user"
password="test_user"
database="test_db"

con = psycopg2.connect(
    dbname=database,
    user=username,
    password=password,
    host=hostname,
    port='5432',
)
query = "select * from demo.delta"
print('connection successfull')
project_id='apsez-svc-dev-datalake'
project='Test_Dev.ABC'
bigquery_schema=  [{'name': 'id','type': 'INTEGER'}, {'name': 'name','type': 'STRING'}]
ColumnsL= ['id', 'name']

chunk_size=500
batch_no=1
try:
    for chunk in pd.read_sql(query,con,chunksize=chunk_size):
        print('Taking data into DataFrame....')
        df = pd.DataFrame(chunk,columns=ColumnsL,index=None)
        print('Loading data in bq:',df)
        print(df)
        try:
            pdq.to_gbq(df,project,project_id,if_exists='append',table_schema=bigquery_schema)
            batch_no+=1
            print('Data Loaded: '+project+' for batch no.: '+batch_no)
            print('Job Run Complete')
        except Exception as e:
            print(e)
    con.close()
except:
    print('connection loss')
    con.close()

