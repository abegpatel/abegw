import pandas as pd
import io
import sqlalchemy as sql
from sqlalchemy.orm import sessionmaker
from datetime import date
from dateutil.relativedelta import *
import psycopg2

 
# Define database connection parameters

# analytics db
hostname = "10.81.162.4"
#hostname = "apsez-as1-analytics-prod-rds.cpjhdhjkpglj.ap-south-1.rds.amazonaws.com"

# real time db
#hostname = 10.90.96.22
#hostname = "apsez-as1-analytics-prod-rds-speed.cpjhdhjkpglj.ap-south-1.rds.amazonaws.com"

username = "test_user"
#password = 'Adani@12I356'

database = "test_db"
#database = "analytics_speed"

engine = sql.create_engine('postgresql+psycopg2://{0}:test_user@{1}:5432/{2}'.format(username, hostname, database))
print('postgresql+psycopg2://{0}:Adani@123456@{1}:5432/{2}?sslmode=require'.format(username, hostname, database))
Session = sessionmaker(bind=engine)
session = Session()
conn = engine.raw_connection()
cur = conn.cursor()
print("Connection with RDS Database `{0}` established successfully!!".format(database))

conn = engine.begin()
query = "select * from demo.delta limit 10"
#query = "select * from analytics_prod.ports_tbl_ctrmovement_real_time limit 10"
#rows = conn.execute(query).rowcount
#print("Rows:",rows)


