#import pandas as pd
import io
#import sqlalchemy as sql
#from sqlalchemy.orm import sessionmaker
from datetime import date
from dateutil.relativedelta import *
import psycopg2
#import pandas_gbq as pdq

import logging

# Define database connection parameters

# analytics db
def conn_Test():

    #hostname = "10.90.96.47"
    hostname = "10.90.96.22"

# real time db
#hostname = "10.90.96.22"

    username = "data_lake_user"
    password = 'Adani@123456'

    #database = "analytics"
    database = "analytics_speed"

# hostname = "10.81.162.4"
# username="test_user"
# password="test_user"
# database="test_db"

    con = psycopg2.connect(
    dbname=database,
    user=username,
    password=password,
    host=hostname,
    port='5432',
    )
    print('connection successfull')
    con.close()

if __name__=="__main__":
    conn_Test()

