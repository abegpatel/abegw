import pandas as pd
import io
import sqlalchemy as sql
from sqlalchemy.orm import sessionmaker
from datetime import date
from dateutil.relativedelta import *
import psycopg2
 
# Define database connection parameters
hostname = '10.90.96.17'
username = 'data_lake_user'
password = 'Adani@123456'
database = 'analytics'


# Connect with RDS
engine = sql.create_engine('postgresql+psycopg2://{0}:{1}@{2}:5432/{3}?sslmode=require'.format(username, password, hostname, database))
Session = sessionmaker(bind=engine)
session = Session()
conn = engine.raw_connection()
cur = conn.cursor()
print("Connection with RDS Database `{0}` established successfully!!".format(database))
