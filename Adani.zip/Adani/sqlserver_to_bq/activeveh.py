import pandas as pd
from datetime import datetime, timedelta
import boto3
#import pickle
import numpy as np
from datetime import date
from google.cloud import bigquery


#project = 'apsez-svc-dev-datalake'
#client = bigquery.Client(project=project)

#query_ins1 = """ select * from  apsez-svc-dev-datalake.logistics_cleansed.layer2_fareye_active_vehicles limit 2 """
#job = client.query(query_ins1)
#job.result()
#print(job.result())
#insrows=job.num_dml_affected_rows
#print(insrows)
    #for row in answer:
#print("layer2_fareye_active_vehicles: {0}".format(insrows))

myquery = "select * from `apsez-svc-dev-datalake.logistics_cleansed.layer2_fareye_active_vehicles`"
client = bigquery.Client()
job = client.query(myquery)
result = job.result()
#for row in result:
print("Total rows available: ",result.total_rows)
print("No. of updated rows:",result.num_dml_affected_rows)
