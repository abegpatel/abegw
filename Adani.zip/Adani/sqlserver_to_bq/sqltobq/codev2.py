import argparse
import pymssql
import logging
import pandas as pd
import pandas_gbq as pdq
import json
import glob
import os
import apache_beam as beam
from apache_beam.options.pipeline_options import PipelineOptions, StandardOptions
from google.cloud import storage
from google.cloud import bigquery
from apache_beam import window
from oauth2client.client import GoogleCredentials
from google.cloud import storage as gstorage



logging.basicConfig(level=logging.INFO)
logging.getLogger().setLevel(logging.INFO)





class sqltobq(beam.DoFn):
   def process(self,element):
    import pandas as pd
    import pandas_gbq as pdq
    import pymssql

    src1='gs://apsez_dataflow_test/dataflow_test_code/dataengineering-master'
    os.system('gsutil cp '+src1+'/job.json /tmp/')
    logging.info('JSON File copied to Instance..')
    
    with open('/tmp/job.json') as json_file:
           json_data = json.load(json_file)

    #print(json_data)
    #print(json_data['JOBID'][1]['ColumnsList'])
    
    #Table = json_data['JOBID'][0]['TableName']
    #print(Table)
    #ColumnsL = json_data['JOBID'][1]['ColumnsList']
    #print(ColumnsL)
    #SchemaData= json_data['JOBID'][2]['Schema']
    #IncrCol = json_data['JOBID'][3]['Inc_Col']
    #NDays = json_data['JOBID'][4]['NDays']
    #BQTable = json_data['JOBID'][5]['BQ_Table']
    #HistLoad = json_data['JOBID'][6]['histload']
    #histyear = json_data['JOBID'][7]['HistYear']
    
    BQTable= "Test_Dev.tblStorageCargoDetailsOracle"
    ColumnsL = ['ETLID', 'PORTID', 'INT_GP_NO', 'UNIT_CNT', 'TOT_WT', 'INT_IGM_CRG_SEQ_NO', 'INT_SO_NO', 'INT_EA_CRG_SEQ_NO', 'INT_TRAIN_NO', 'INT_SUB_DO_NO', 'TRUCK_CNT', 'TRUCK_NET_WT', 'MVMT_TYPE', 'FM_STRG_CD', 'TO_STRG_CD', 'TRUCK_REG_NO', 'PIPELINE_NO', 'ACTVTY_DTTM', 'CNTRCTR_CD', 'GRADE_CD', 'INDT_NO', 'LOAD_TYPE', 'WGN_TYPE', 'GAINLOSS_DTTM', 'PKG_TYPE', 'GRADE_DESCR', 'TO_ROW_NO', 'TO_COLUMN_NO', 'FM_ROW_NO', 'FM_COLUMN_NO', 'TP_NO', 'GRS_WGHMNT_DTTM', 'TARE_WGHMNT_DTTM', 'GRS_WT', 'TARE_WT', 'WEIGHBRIDGE_NO', 'SRC_DOC_REF_NO', 'REASON_CD', 'ADT_INS_DTTM', 'ADT_UPD_DTTM', 'RECORD_INS_DATE', 'STACKER_CD', 'SHIFT_DESC', 'GAIN_LOSS_EVENT', 'INDT_DTTM', 'liq_ctm_gp_no', 'dry_ctm_gp_no', 'sub_do_no', 'sub_csne_cd', 'sub_csne_nm', 'cstm_boe_no', 'cstm_boe_dttm', 'so_no', 'so_dttm', 'deleted', 'Timestamp', 'MAN_MECH_IND', 'EXIT_MODE', 'ENTRY_MODE', 'INT_TP_NO', 'SouceName']

    Schema = [{'name': 'ETLID','type': 'FLOAT'}, {'name': 'PORTID','type': 'FLOAT'}, {'name': 'INT_GP_NO','type': 'FLOAT'}, {'name': 'UNIT_CNT','type': 'FLOAT'}, {'name': 'TOT_WT','type': 'FLOAT'}, {'name': 'INT_IGM_CRG_SEQ_NO','type': 'FLOAT'}, {'name': 'INT_SO_NO','type': 'FLOAT'}, {'name': 'INT_EA_CRG_SEQ_NO','type': 'FLOAT'}, {'name': 'INT_TRAIN_NO','type': 'FLOAT'}, {'name': 'INT_SUB_DO_NO','type': 'FLOAT'}, {'name': 'TRUCK_CNT','type': 'FLOAT'}, {'name': 'TRUCK_NET_WT','type': 'FLOAT'}, {'name': 'MVMT_TYPE','type': 'STRING'}, {'name': 'FM_STRG_CD','type': 'STRING'}, {'name': 'TO_STRG_CD','type': 'STRING'}, {'name': 'TRUCK_REG_NO','type': 'STRING'}, {'name': 'PIPELINE_NO','type': 'STRING'}, {'name': 'ACTVTY_DTTM','type': 'TIMESTAMP'}, {'name': 'CNTRCTR_CD','type': 'STRING'}, {'name': 'GRADE_CD','type': 'STRING'}, {'name': 'INDT_NO','type': 'STRING'}, {'name': 'LOAD_TYPE','type': 'STRING'}, {'name': 'WGN_TYPE','type': 'STRING'}, {'name': 'GAINLOSS_DTTM','type': 'TIMESTAMP'}, {'name': 'PKG_TYPE','type': 'STRING'}, {'name': 'GRADE_DESCR','type': 'STRING'}, {'name': 'TO_ROW_NO','type': 'STRING'}, {'name': 'TO_COLUMN_NO','type': 'STRING'}, {'name': 'FM_ROW_NO','type': 'STRING'}, {'name': 'FM_COLUMN_NO','type': 'STRING'}, {'name': 'TP_NO','type': 'STRING'}, {'name': 'GRS_WGHMNT_DTTM','type': 'TIMESTAMP'}, {'name': 'TARE_WGHMNT_DTTM','type': 'TIMESTAMP'}, {'name': 'GRS_WT','type': 'FLOAT'}, {'name': 'TARE_WT','type': 'FLOAT'}, {'name': 'WEIGHBRIDGE_NO','type': 'STRING'}, {'name': 'SRC_DOC_REF_NO','type': 'STRING'}, {'name': 'REASON_CD','type': 'STRING'}, {'name': 'ADT_INS_DTTM','type': 'TIMESTAMP'}, {'name': 'ADT_UPD_DTTM','type': 'TIMESTAMP'}, {'name': 'RECORD_INS_DATE','type': 'TIMESTAMP'}, {'name': 'STACKER_CD','type': 'STRING'}, {'name': 'SHIFT_DESC','type': 'STRING'}, {'name': 'GAIN_LOSS_EVENT','type': 'STRING'}, {'name': 'INDT_DTTM','type': 'TIMESTAMP'}, {'name': 'liq_ctm_gp_no','type': 'STRING'}, {'name': 'dry_ctm_gp_no','type': 'STRING'}, {'name': 'sub_do_no','type': 'STRING'}, {'name': 'sub_csne_cd','type': 'STRING'}, {'name': 'sub_csne_nm','type': 'STRING'}, {'name': 'cstm_boe_no','type': 'STRING'}, {'name': 'cstm_boe_dttm','type': 'STRING'}, {'name': 'so_no','type': 'STRING'}, {'name': 'so_dttm','type': 'TIMESTAMP'}, {'name': 'deleted','type': 'BOOLEAN'}, {'name': 'Timestamp','type': 'TIMESTAMP'}, {'name': 'MAN_MECH_IND','type': 'STRING'}, {'name': 'EXIT_MODE','type': 'STRING'}, {'name': 'ENTRY_MODE','type': 'STRING'}, {'name': 'INT_TP_NO','type': 'FLOAT'}, {'name': 'SouceName','type': 'STRING'}] 

    username='analytics_user'
    passs='analytics$user'
    hostname='10.81.162.22'
    database_name='MercuryDB'

    mydb = pymssql.connect(
    host=hostname,
    user=username,
    password=passs,
    database=database_name)

    query_pattern = "select * from tblStorageCargoDetailsOracle"
           
    logging.info(query_pattern)
    project_id='apsez-svc-dev-datalake'
    project=str(BQTable)

    df = pd.read_sql(query_pattern,mydb)
    df1 = pd.DataFrame(df,columns=ColumnsL,index=None)
    logging.info(df1) 
    pdq.to_gbq(df1,project,project_id,if_exists='append',table_schema=Schema)

            


def run():
    parser = argparse.ArgumentParser()
    known_args, pipeline_args = parser.parse_known_args()
    # Creating pipeline options
    pipeline_options = PipelineOptions(pipeline_args)
    # Defining our pipeline and its steps
    with beam.Pipeline(options=pipeline_options) as p:
       lines = ( p | beam.Create(['1'])
                   | "SQL_TO_BQ_DATA_LOAD" >> beam.ParDo(sqltobq()))

if __name__ == "__main__":
     run()
