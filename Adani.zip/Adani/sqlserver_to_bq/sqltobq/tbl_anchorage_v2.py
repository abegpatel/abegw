import argparse
import logging
import glob
import os
import apache_beam as beam
from apache_beam.options.pipeline_options import PipelineOptions, StandardOptions
#from google.cloud import storage
#from google.cloud import bigquery
from apache_beam import window
#from oauth2client.client import GoogleCredentials
#from google.cloud import storage as gstorage
#from oauth2client.client import GoogleCredentials


logging.basicConfig(level=logging.INFO)
logging.getLogger().setLevel(logging.INFO)


class sqltobq(beam.DoFn):
    def process(self,element):
        #import pandas as pd
       #import jaydebeapi
        #import pandas_gbq as pdq
        #import pymssql
        import subprocess

        subprocess.run(['pip','install','wget'],Shell=True)
        #pip install subprocess;pip install os;wget https://files.pythonhosted.org/packages/23/38/efc6dd86957538ecf5ed94a4c2f444ac9cdcd5052ec5138474ea42d99cd0/apache-beam-2.41.0.zip

       # var2=subprocess.Popen(var1,stdout=subprocess.PIPE)
        #output,error=var2.communicate()
        #logging.info(output,error)



       
    




def run():
    try:
        parser = argparse.ArgumentParser()
        known_args, pipeline_args = parser.parse_known_args()
        pipeline_options = PipelineOptions(pipeline_args)
        pcoll=beam.Pipeline(options=pipeline_options)
        dummy= pcoll | 'Initializing..' >> beam.Create(['1'])
        dummy_env= (dummy |'Processing & loading to bigquery' >> beam.ParDo(sqltobq()))
        p=pcoll.run()
        p.wait_until_finish()
    except:  
        logging.exception('Failec to launch datapipeline')
        raise

        
if __name__ == "__main__":
     run()

