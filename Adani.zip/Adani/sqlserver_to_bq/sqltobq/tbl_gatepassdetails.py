import argparse
import pymssql
import logging
import pandas as pd
import pandas_gbq as pdq
import json
import glob
import os
import apache_beam as beam
from apache_beam.options.pipeline_options import PipelineOptions, StandardOptions
from google.cloud import storage
from google.cloud import bigquery
from apache_beam import window
from oauth2client.client import GoogleCredentials
from google.cloud import storage as gstorage
#from oauth2client.client import GoogleCredentials


logging.basicConfig(level=logging.INFO)
logging.getLogger().setLevel(logging.INFO)

class setenv(beam.DoFn):
    def process(self,context):
        #import jaydebeapi
        import pandas as pd

        scr1='gs://apsez_dataflow_test/dataflow_test_code/dataengineering-master'
        os.system('gsutil cp '+scr1+'/tblGatepassDetailsOracle.json /tmp/')
        logging.info('copying connction file..')
        scr2='gs://apsez_dataflow_test/dataflow_test_code/dataengineering-master'
        os.system('gsutil cp '+scr2+'/sqlserver_to_bq_connection_details.json /tmp/')
        logging.info('Environment Variable set..')
        return list("1")


class sqltobq(beam.DoFn):
   def process(self,element):
       import pandas as pd
       #import jaydebeapi
       import pandas_gbq as pdq
       import pymssql
       json_data= []
       try:
           logging.info('Reading config file')
           with open('/tmp/tblGatepassDetailsOracle.json') as json_file:
               json_data=json.load(json_file)
       except Exception as e:
           logging.error(e)
       connection_details=[]
       try:
           logging.info('Reading connection file')
           with open('/tmp/sqlserver_to_bq_connection_details.json') as json_file_1:
               connection_details=json.load(json_file_1)
       except Exception as e:
           logging.error(e)

       username = connection_details['MERCURY_DB'][0]['username']
       passs = connection_details['MERCURY_DB'][0]['passs']
       hostname = connection_details['MERCURY_DB'][0]['hostname']
       database_name = connection_details['MERCURY_DB'][0]['database_name']
        
       logging.info('connection starts')
       mydb = pymssql.connect(
       host=hostname,
       user=username,
       password=passs,
       database=database_name)
       logging.info('connection established')

       print('------')
       size=len(json_data['JOBID'])
       logging.info('Table count -%s', size)
       print('-------')
       Table = json_data['JOBID'][0]['TableName']
       ColumnsL = json_data['JOBID'][0]['ColumnsList']
       SchemaData= json_data['JOBID'][0]['Schema']
       IncrCol = json_data['JOBID'][0]['Inc_Col']
       NDays = json_data['JOBID'][0]['NDays']
       BQTable = json_data['JOBID'][0]['BQ_Table']
       loadStrategy = json_data['JOBID'][0]['LoadStrategy']
       histyear = json_data['JOBID'][0]['HistYear']

       print('Connecting to Source System....')

       logging.info('Quering table....')
       print(loadStrategy)
       if str(loadStrategy) == "Y" or str(loadStrategy) == "y":
           logging.info('Doing historying load') 
           query_pattern = "select INT_GP_NO,GP_NO,TRUCK_REG_NO,GP_TYPE,BASE_STATUS,PRE_GATE_GEN_DTTM,ENTRY_DTTM,EXIT_DTTM,PORTID,DRIVER_LCNSE_NO,DRIVER_NM,HAUL_CD,HAUL_NM,CNTRCTR_CD,CNTRCTR_NM,CANCEL_DTTM,ACCESS_CD,PRE_GATE_ID,IN_GATE_ID,OUT_GATE_ID,SLUDGE_RLS_DTTM,TOLL_AMT,INT_IGM_EA_CRG_SEQ_NO,INT_BO_SUB_DO_NO,SLUDGE_RQST_NO,INLAND_ORIGIN_DESCR,PTY_CD,PARTY,CMDT_CD,COMMODITY,CMDT_TYPE_CD,CMDT_TYPE_DESCR,YARD_IN_DTTM,YARD_OUT_DTTM,INT_VIA_NO,APPLN_NO,APPLN_DTTM,INLAND_ORIGIN_DEST,INT_DO_NO,INS_UPD_DTTM,TOT_PKG_LEN,max_alwd_grs_wt,sez_exit_dttm,int_user_id_gh,USER_NM_GH,base_sts,s_rmrk_gh,lorry_rcpt_no,pre_gate_int_user_id,pre_gate_int_user_nm,in_gate_int_user_id,in_gate_int_user_nm,out_gate_int_user_id,out_gate_int_user_nm,tentative_cmdt_cd,l_rmrk_gh,sludge_rls_flg,rfid_id,cancel_int_user_id,cancel_int_user_nm,cancel_gate_id,print_count,toll_pty_cd,rail_ind,ctr_tmnl_cd,print_dttm,PKG_CNT_gd,INVC_TOT_WT,INT_EQPT_ID,eqpt_reg_no,CSNE_CSNR_CD,PKG_TYPE,INVC_RCPT,SUPPLY_PTY_CD,TARE_WT_GD,GRS_WT_GD,TARE_WGHMNT_DTTM_GD,GRS_WGHMNT_DTTM_GD,WB_MVMT_FLG,CHALLAN_NO,CHALLAN_DTTM,BDL_CNT,INT_SLUDGE_RQST_NO,ITEM_CD,CTR_NO,CTR_TYPE,FE_IND,IO_IND,INT_BNKR_DLVY_NO,INT_BNKR_LINE_NO,CTR_RMRK,TRAIN_RMRK_GD,RD_IND,toll_pty_nm,tot_amt,intrnl_user_ind,TimeStamp,cast(Deleted as int) as Deleted,srvyor_cd,sez_entry_dttm,SouceName,ADVANCE_INDENT_FLAG,buyer_name,rls_doc_ref_no,tentative_do_qty from "+str(Table) + " where DATEPART(year,ENTRY_DTTM)='"+str(histyear)+"' "
           
       else:    
           logging.info('Incremental load..') 
           query_pattern = "select INT_GP_NO,GP_NO,TRUCK_REG_NO,GP_TYPE,BASE_STATUS,PRE_GATE_GEN_DTTM,ENTRY_DTTM,EXIT_DTTM,PORTID,DRIVER_LCNSE_NO,DRIVER_NM,HAUL_CD,HAUL_NM,CNTRCTR_CD,CNTRCTR_NM,CANCEL_DTTM,ACCESS_CD,PRE_GATE_ID,IN_GATE_ID,OUT_GATE_ID,SLUDGE_RLS_DTTM,TOLL_AMT,INT_IGM_EA_CRG_SEQ_NO,INT_BO_SUB_DO_NO,SLUDGE_RQST_NO,INLAND_ORIGIN_DESCR,PTY_CD,PARTY,CMDT_CD,COMMODITY,CMDT_TYPE_CD,CMDT_TYPE_DESCR,YARD_IN_DTTM,YARD_OUT_DTTM,INT_VIA_NO,APPLN_NO,APPLN_DTTM,INLAND_ORIGIN_DEST,INT_DO_NO,INS_UPD_DTTM,TOT_PKG_LEN,max_alwd_grs_wt,sez_exit_dttm,int_user_id_gh,USER_NM_GH,base_sts,s_rmrk_gh,lorry_rcpt_no,pre_gate_int_user_id,pre_gate_int_user_nm,in_gate_int_user_id,in_gate_int_user_nm,out_gate_int_user_id,out_gate_int_user_nm,tentative_cmdt_cd,l_rmrk_gh,sludge_rls_flg,rfid_id,cancel_int_user_id,cancel_int_user_nm,cancel_gate_id,print_count,toll_pty_cd,rail_ind,ctr_tmnl_cd,print_dttm,PKG_CNT_gd,INVC_TOT_WT,INT_EQPT_ID,eqpt_reg_no,CSNE_CSNR_CD,PKG_TYPE,INVC_RCPT,SUPPLY_PTY_CD,TARE_WT_GD,GRS_WT_GD,TARE_WGHMNT_DTTM_GD,GRS_WGHMNT_DTTM_GD,WB_MVMT_FLG,CHALLAN_NO,CHALLAN_DTTM,BDL_CNT,INT_SLUDGE_RQST_NO,ITEM_CD,CTR_NO,CTR_TYPE,FE_IND,IO_IND,INT_BNKR_DLVY_NO,INT_BNKR_LINE_NO,CTR_RMRK,TRAIN_RMRK_GD,RD_IND,toll_pty_nm,tot_amt,intrnl_user_ind,TimeStamp,cast(Deleted as int) as Deleted,srvyor_cd,sez_entry_dttm,SouceName,ADVANCE_INDENT_FLAG,buyer_name,rls_doc_ref_no,tentative_do_qty from "+str(Table)+" where "+str(IncrCol)+ ">= DATEADD(DAY,-"+str(NDays)+", CURRENT_TIMESTAMP)"
            
       logging.info(query_pattern)
       bigquery_schema=SchemaData
       BIGQUERY_TABLE = 'apsez-svc-dev-datalake.'+str(BQTable)
       logging.info('BQ Target table -%s',BIGQUERY_TABLE)
       try:
           print('Quering on a Table:')
           if str(loadStrategy) == 'Y' or str(loadStrategy) == 'y':
               sql1= "delete from "+str(BQTable)+" where extract(year from ENTRY_DTTM) = "+str(histyear)
           elif str(loadStrategy) =="FullLoad":
               sql1="truncate table apsez-svc-dev-datalake."+str(BQTable)
           else:    
               sql1="delete from apsez-svc-dev-datalake."+str(BQTable)+" where date("+str(IncrCol)+") >= DATE_SUB(current_date,interval "+str(NDays)+" DAY)"
           logging.info(sql1)
           client = bigquery.Client()
           query_job = client.query(sql1)
           query_job.result()
           #pd.read_gbq(sql1, project_id='apsez-svc-dev-datalake')
           logging.info('table is deleted!!')
       except:
           logging.info('Table is not created yet!!.Creating table....')
           pass
       project_id='apsez-svc-dev-datalake'
       project=str(BQTable)
            
       #df = pd.read_sql(query_pattern,mydb)
            
            #yield df
       chunk_size=500000
       batch_no=0
       logging.info('Loading to  DataFrame....')
       try:
           for chunk in pd.read_sql(query_pattern,mydb,chunksize=chunk_size):
               logging.info('Taking data into DataFrame....')
               df = pd.DataFrame(chunk,columns=ColumnsL,index=None)
               logging.info('Loading data in bq: %s',df)
               try:
                   pdq.to_gbq(df,project,project_id,if_exists='append',table_schema=bigquery_schema)
                   batch_no+=1
                   logging.info('Data Loaded : %s for batch no :%s ',BQTable,batch_no)
                   logging.info('Job Run Complete:%s',BIGQUERY_TABLE)
               except Exception as e:
                   logging.info(e)
       except:
           logging.info('connection loss')


def run():
    try:
        parser = argparse.ArgumentParser()
        known_args, pipeline_args = parser.parse_known_args()
        pipeline_options = PipelineOptions(pipeline_args)
        pcoll=beam.Pipeline(options=pipeline_options)
        dummy= pcoll | 'Initializing..' >> beam.Create(['1'])
        dummy_env= (dummy | 'Setting up instance ..' >> beam.ParDo(setenv()) | 'Processing & loading to bigquery' >> beam.ParDo(sqltobq()))
        p=pcoll.run()
        p.wait_until_finish()
    except:  
        logging.exception('Failec to launch datapipeline')
        raise

        
if __name__ == "__main__":
     run()

