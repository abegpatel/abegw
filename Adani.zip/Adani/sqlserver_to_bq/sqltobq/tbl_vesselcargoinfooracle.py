import argparse
import pymssql
import logging
import pandas as pd
import pandas_gbq as pdq
import json
import glob
import os
import apache_beam as beam
from apache_beam.options.pipeline_options import PipelineOptions, StandardOptions
from google.cloud import storage
from google.cloud import bigquery
from apache_beam import window
from oauth2client.client import GoogleCredentials
from google.cloud import storage as gstorage
#from oauth2client.client import GoogleCredentials


logging.basicConfig(level=logging.INFO)
logging.getLogger().setLevel(logging.INFO)

class setenv(beam.DoFn):
    def process(self,context):
        #import jaydebeapi
        import pandas as pd

        scr1='gs://apsez_dataflow_test/dataflow_test_code/dataengineering-master'
        os.system('gsutil cp '+scr1+'/tblVesselCargoInfoOracle.json /tmp/')
        logging.info('copying connction file..')
        scr2='gs://apsez_dataflow_test/dataflow_test_code/dataengineering-master'
        os.system('gsutil cp '+scr2+'/sqlserver_to_bq_connection_details.json /tmp/')
        logging.info('Environment Variable set..')
        return list("1")


class sqltobq(beam.DoFn):
   def process(self,element):
       import pandas as pd
       #import jaydebeapi
       import pandas_gbq as pdq
       import pymssql
       json_data= []
       try:
           logging.info('Reading config file')
           with open('/tmp/tblVesselCargoInfoOracle.json') as json_file:
               json_data=json.load(json_file)
       except Exception as e:
           logging.error(e)
       connection_details=[]
       try:
           logging.info('Reading connection file')
           with open('/tmp/sqlserver_to_bq_connection_details.json') as json_file_1:
               connection_details=json.load(json_file_1)
       except Exception as e:
           logging.error(e)

       username = connection_details['MERCURY_DB'][0]['username']
       passs = connection_details['MERCURY_DB'][0]['passs']
       hostname = connection_details['MERCURY_DB'][0]['hostname']
       database_name = connection_details['MERCURY_DB'][0]['database_name']
        
       logging.info('connection starts')
       mydb = pymssql.connect(
       host=hostname,
       user=username,
       password=passs,
       database=database_name)
       logging.info('connection established')

       print('------')
       size=len(json_data['JOBID'])
       logging.info('Table count -%s', size)
       print('-------')
       Table = json_data['JOBID'][0]['TableName']
       ColumnsL = json_data['JOBID'][0]['ColumnsList']
       SchemaData= json_data['JOBID'][0]['Schema']
       #IncrCol = json_data['JOBID'][0]['Inc_Col']
      # NDays = json_data['JOBID'][0]['NDays']
       BQTable = json_data['JOBID'][0]['BQ_Table']
       loadStrategy = json_data['JOBID'][0]['LoadStrategy']
      # histyear = json_data['JOBID'][0]['HistYear']

       print('Connecting to Source System....')

       logging.info('Quering table....')
       print(loadStrategy)
       if str(loadStrategy) == "Y" or str(loadStrategy) == "y":
           logging.info('Doing historying load') 
           query_pattern = "select * from "+str(Table) + " where DATEPART(year,Timestamp) = '"+str(histyear)+"' "
       elif str(loadStrategy) =="FullLoad":
           logging.info("Doing full load")
           query_pattern = "select ETLID,VSL_WK_COMPLT_USER_ID,VSL_WK_COMPLT_DTTM,VSL_NM,VSL_MAX_HT,VSL_CD,VOY_TRANSIT_FLG,VOY_REG_DTTM,VIA_NO,TUG_NRT,TUG_GRT,TPC,SENT_BERALT_FLG,SAILD_FLG,ROTATION_NO,ROTATION_DTTM,ROTATION_CSTM_SITE_CD,REC_TYPE,PCS_VSL_CAT_CD,PCS_CMN_REF_NO,MSG_HDR_ID,MRN_INVC_CLOSURE_INT_USER_ID,MRN_INVC_CLOSURE_DTTM,MRN_CLOSURE_INT_USER_ID,MRN_CLOSURE_FLG,MRN_CLOSURE_DTTM,MOTHER_FEEDER_BARGE_IND,MAIN_LINE_CD,MAIDEN_FLG,LEGACY_IMP_VOY_NO,LEGACY_EXP_VOY_NO,LD_VOY_NO,LD_TRADE_CD,LD_ROUTE_CD,LD_MNF_CLOSE_FLG,IS_VSL_DEFD_FLG,INT_VIA_NO,IGM_RMRK,IGM_DTTM,EXT_VOY_FLG,ETD_DTTM,ETA_DTTM,EGM_RMRK,EGM_DTTM,EDI_FLG,DUMMY_VOY_FLG,DSCH_VOY_NO,DSCH_TRADE_CD,DSCH_LD_BOTH_IND,DEFN_STAGE_IND,DECK_CRG_GRT,CNSRTM_CD,BU_CD,BU_DESCR,BUNKER_VSL_FLG,BERTH_TYPE,BERTH_PRIORITY,ATUB_DTTM,ATHWART_STOWED_FLG,ATD_DTTM,ATB_DTTM,ATA_DTTM,VSL_BEAM,VSL_WIDTH,VSL_OVR_LEN,PONT_MV_TM,MIN_DRAFT_FORE,SUB_VSL_CAT_CD,DEPTH_MOULDED,VSL_WK_AREA,VSL_APP_FLG,VSL_GEARLESS,REDU_GRT_FLG,REDU_GRT,CNTRY_CD,LOG_DTTM,MANUF_DTTM,VSL_GRP_CD,VSL_CAT_CD,CALL_SIGN,PORT_OF_REG,VSL_CLASS,AGENT_CD,VSL_CELL_TYPE,SATELLITE_ID,WT_CAT_DEFN_CD,ROUTE_CD,PREF_BERTH_TO_BLRD,PREF_BERTH_NO,VSL_BAY_DEFN_CD,VSL_TYPE,VSL_SHORT_NM,PREF_BERTH_SIDE,QUAY_CD,LINE_CD,IMO_NO,DISPLACEMENT,INT_VSL_CD,NRT,PREF_BERTH_TO_MM,VSL_HT,BERTH_TM,HEADERGRT,MAX_DRAFT_FORE,MAX_DRAFT_AFT,MAX_DRAFT,NT,GT,MIN_DRAFT,SC_TORSION,DIST_UD_ROW_PORTSD,DIST_UD_BAY_STERN,DIST_DK_ROW_STARSD,MIN_DRAFT_AFT,DECK_CRG,PORT_CD,NDC_AGENT_CD,DEAD_WT,NDC_DTTM,NDC_NO,SHORE_CRN_CNT,SHIP_CRN_CNT,DSCH_PORT_RMRK,LD_PORT_RMRK,NOR_DTTM,PHO_CLEAR_DTTM,CSTM_EGM_DTTM,NEXT_PORT_CD,LAST_PORT_CD,CSTM_EGM_NO,DSCH_VSL_AGENT_CD,LD_VSL_AGENT_CD,ARR_DRAFT,DRAFT,ACT_ARR_DRAFT_AFT,ACT_ARR_DRAFT_FORE,VSL_FREE_BOARD,VSL_NOR_DTTM,BASE_STS,CMDT_CD,CRG_TYPE,FOREIGN_COASTAL_IND,PKG_TYPE,RESTOW_TYPE,TOT_WT,UNIT_CNT,UNIT_WT,COMMODITY,COMMODITY_TYPE,COMMODITY_TYPE_CODE,GRT,HATCH,CHARTER_RATE,PORTID,SHIPPER_RECIEVER,AGENT,FIRST_PILOT_REQUEST_TIME,FLAG,CARGO_TYPE_DESCR,LAST_PORT_OF_CALL,INMARSAT,MMSI_NO,NEXT_PORT_OF_CALL,IGM_WT,EGM_WT,BUDGET_VSL_CNT,BUDGET_GRT,BUDGET_TOT_WT,BUDGET_TEUS,EFF_DTTM,VSL_CAT,UPD_DTTM,DECLARED_SBU,COUNTRY,DECLARED_SBU_DESCR,VSL_GROUP,SUB_VSL_CAT,SURVEYOR_BOARD_DTTM,SURVEYOR_UNBOARD_DTTM,Ullage_Fm_Dttm,Ullage_To_Dttm,CRG_SEQ_ID,CSTM_BOARD_DTTM,CSTM_CLEARED_DTTM,INSERT_DTTM,INS_UPD_DTTM,TimeStamp,cast (Deleted as INT) as Deleted,cast(Deleted_CMDT as int) as Deleted_CMDT,MRN_POC_CLOSURE_DTTM,MRN_POC_CLOSURE_INT_USER_NM,MRN_STVDR_CLOSURE_DTTM,Dsch_Port_Name,Ld_Port_Name,arr_draft_fore,arr_draft_aft,dep_draft_fore,dep_draft_aft,SouceName from "+str(Table)
           #query_pattern = "select * from "+str(Table)
       else:    
           logging.info('Incremental load..') 
           query_pattern = "select * from "+str(Table)+" where "+str(IncrCol)+ ">= DATEADD(DAY,-"+str(NDays)+", CURRENT_TIMESTAMP)" 
       logging.info(query_pattern)
       bigquery_schema=SchemaData
       BIGQUERY_TABLE = 'apsez-svc-dev-datalake.'+str(BQTable)
       logging.info('BQ Target table -%s',BIGQUERY_TABLE)
       try:
           print('Quering on a Table:')
           if str(loadStrategy) == 'Y' or str(loadStrategy) == 'y':
               sql1= "delete from "+str(BQTable)+" where extract(year from TimeStamp) = "+str(histyear)
           elif str(loadStrategy) =="FullLoad":
               sql1="truncate table apsez-svc-dev-datalake."+str(BQTable)
           else:    
               sql1="delete from apsez-svc-dev-datalake."+str(BQTable)+" where date("+str(IncrCol)+") >= DATE_SUB(current_date,interval "+str(NDays)+" DAY)"
           logging.info(sql1)
           pd.read_gbq(sql1, project_id='apsez-svc-dev-datalake')
           logging.info('table is deleted!!')
       except:
           logging.info('Table is not created yet!!.Creating table....')
           pass
       project_id='apsez-svc-dev-datalake'
       project=str(BQTable)
            
       df = pd.read_sql(query_pattern,mydb)
            
            #yield df
       chunk_size=100000
       batch_no=0
       logging.info('Loading to  DataFrame....')
       try:
           for chunk in pd.read_sql(query_pattern,mydb,chunksize=chunk_size):
               logging.info('Taking data into DataFrame....')
               df = pd.DataFrame(chunk,columns=ColumnsL,index=None)
              # df=df.astype(dtype={'Deleted':'INT64','Deleted_CMDT':'INT64'})
               logging.info('Loading data in bq: %s',df)
               try:
                   pdq.to_gbq(df,project,project_id,if_exists='append',table_schema=bigquery_schema,api_method="load_csv")
                   batch_no+=1
                   logging.info('Data Loaded : %s for batch no :%s ',BQTable,batch_no)
                   logging.info('Job Run Complete:%s',BIGQUERY_TABLE)
               except Exception as e:
                   logging.info(e)
       except:
           logging.info('connection loss')


def run():
    try:
        parser = argparse.ArgumentParser()
        known_args, pipeline_args = parser.parse_known_args()
        pipeline_options = PipelineOptions(pipeline_args)
        pcoll=beam.Pipeline(options=pipeline_options)
        dummy= pcoll | 'Initializing..' >> beam.Create(['1'])
        dummy_env= (dummy | 'Setting up instance ..' >> beam.ParDo(setenv()) | 'Processing & loading to bigquery' >> beam.ParDo(sqltobq()))
        p=pcoll.run()
        p.wait_until_finish()
    except:  
        logging.exception('Failec to launch datapipeline')
        raise

        
if __name__ == "__main__":
     run()

