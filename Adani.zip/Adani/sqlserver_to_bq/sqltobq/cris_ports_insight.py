import argparse
#import psycopg2-binary
#libpq = importlib.import_module("libpq-dev")
#import 'libpq-dev'
#import psycopg2
import importlib
import logging
import pandas as pd
import pandas_gbq as pdq
import json
import glob
import apache_beam as beam
from apache_beam.options.pipeline_options import PipelineOptions, StandardOptions
from google.cloud import storage
from google.cloud import bigquery
from apache_beam import window
from oauth2client.client import GoogleCredentials
from google.cloud import storage as gstorage
#from oauth2client.client import GoogleCredentials
import os
os.system('sudo apt-get install python-dev libpq-dev')
os.system('pip install psycopg2-binary')
#pgbinary =importlib.import_module("psycopg2-binary")

import psycopg2

logging.basicConfig(level=logging.INFO)
logging.getLogger().setLevel(logging.INFO)

class setenv(beam.DoFn):
    def process(self,context):
        scr1='gs://apsez_dataflow_test/dataflow_test_code/dataengineering-master'
        os.system('gsutil cp '+scr1+'/pgadmin_connection_details.json /tmp/')
        logging.info('copying connection file..')
        scr2='gs://apsez_dataflow_test/dataflow_test_code/dataengineering-master'
        os.system('gsutil cp '+scr2+'/cris_ports_insight.json /tmp/')
        logging.info('Environment Variable set..')
        return list("1")


class postgresqltobq(beam.DoFn):
   def process(self,element):
       import pandas as pd
       import pandas_gbq as pdq
       #pgbinary = importlib.import_module("psycopg2-binary")
       

       import psycopg2
       json_data= []
       try:
           logging.info('Reading config file')
           with open('/tmp/cris_ports_insight.json') as json_file:
               json_data=json.load(json_file)
       except Exception as e:
           logging.error(e)
       connection_details=[]
       try:
           logging.info('Reading connection file')
           with open('/tmp/pgadmin_connection_details.json') as json_file_1:
               connection_details=json.load(json_file_1)
       except Exception as e:
           logging.error(e)

       username = connection_details['PGADMIN_HIST'][0]['database_user']
       passs = connection_details['PGADMIN_HIST'][0]['database_password']
       hostname = connection_details['PGADMIN_HIST'][0]['database_host']
       db_port = connection_details['PGADMIN_HIST'][0]['database_port']
       db_name = connection_details['PGADMIN_HIST'][0]['database_name']
        
       logging.info('connection starts')
       mydb = psycopg2.connect(
       host=hostname,
       port=db_port,
       user=username,
       password=passs,
       database=db_name)
       logging.info('connection established')

       print('------')
       size=len(json_data['JOBID'])
       logging.info('Table count -%s', size)
       print('-------')
       Table = json_data['JOBID'][0]['TableName']
       ColumnsL = json_data['JOBID'][0]['ColumnsList']
       SchemaData= json_data['JOBID'][0]['Schema']
       IncrCol = json_data['JOBID'][0]['Inc_Col']
       NDays = json_data['JOBID'][0]['NDays']
       BQTable = json_data['JOBID'][0]['BQ_Table']
       loadStrategy = json_data['JOBID'][0]['loadstrategy']
       histyear = json_data['JOBID'][0]['HistYear']

       print('Connecting to Source System....')

       logging.info('Quering table....')
       print(loadStrategy)
       if str(loadStrategy) == "Y" or str(loadStrategy) == "y":
           logging.info('Doing historying load') 
           query_pattern = "select * from "+str(Table) + " where DATEPART(year,Timestamp) = '"+str(histyear)+"' "
       elif str(loadStrategy) =="FullLoad":
           logging.info("Doing full load")
           query_pattern = "select * from "+str(Table)+ " where date(in_dt)='2023-02-28' "
       else:    
           logging.info('Incremental load..') 
           query_pattern = "select * from "+str(Table)+" where "+str(IncrCol)+ ">= DATEADD(DAY,-"+str(NDays)+", CURRENT_TIMESTAMP)" 
       logging.info(query_pattern)
       bigquery_schema=SchemaData
       BIGQUERY_TABLE = 'apsez-svc-dev-datalake.'+str(BQTable)
       logging.info('BQ Target table -%s',BIGQUERY_TABLE)
       try:
           print('Quering on a Table:')
           if str(loadStrategy) == 'Y' or str(loadStrategy) == 'y':
               sql1= "delete from apsez-svc-dev-datalake."+str(BQTable)+" where extract(year from TimeStamp) = "+str(histyear)
           elif str(loadStrategy) =="FullLoad":
               sql1="truncate table apsez-svc-dev-datalake."+str(BQTable)
           else:    
               sql1="delete from apsez-svc-dev-datalake."+str(BQTable)+" where date("+str(IncrCol)+") >= DATE_SUB(current_date,interval "+str(NDays)+" DAY)"
           logging.info(sql1)
           pd.read_gbq(sql1, project_id='apsez-svc-dev-datalake')
           logging.info('table is deleted!!')
       except:
           logging.info('Table is not created yet!!.Creating table....')
           pass
       project_id='apsez-svc-dev-datalake'
       project=str(BQTable)
            
       df = pd.read_sql(query_pattern,mydb)
            
            #yield df
       chunk_size=500000
       batch_no=0
       logging.info('Loading to  DataFrame....')
       try:
           for chunk in pd.read_sql(query_pattern,mydb,chunksize=chunk_size):
               logging.info('Taking data into DataFrame....')
               df = pd.DataFrame(chunk,columns=ColumnsL,index=None)
               logging.info('Loading data in bq: %s',df)
               try:
                   pdq.to_gbq(df,project,project_id,if_exists='append',table_schema=bigquery_schema)
                   batch_no+=1
                   logging.info('Data Loaded : %s for batch no :%s ',BQTable,batch_no)
                   logging.info('Job Run Complete:%s',BIGQUERY_TABLE)
               except Exception as e:
                   logging.info(e)
       except:
           logging.info('connection loss')


def run():
    try:
        parser = argparse.ArgumentParser()
        known_args, pipeline_args = parser.parse_known_args()
        pipeline_options = PipelineOptions(pipeline_args)
        pcoll=beam.Pipeline(options=pipeline_options)
        dummy= pcoll | 'Initializing..' >> beam.Create(['1'])
        dummy_env= (dummy | 'Setting up instance ..' >> beam.ParDo(setenv()) | 'Processing & loading to bigquery' >> beam.ParDo(postgresqltobq()))
        p=pcoll.run()
        p.wait_until_finish()
    except:  
        logging.exception('Failec to launch datapipeline')
        raise

        
if __name__ == "__main__":
     run()

