import argparse
import pymssql
import logging
import pandas as pd
import pandas_gbq as pdq
import json
import glob
import os
import apache_beam as beam
from apache_beam.options.pipeline_options import PipelineOptions, StandardOptions
from google.cloud import storage
from google.cloud import bigquery
from apache_beam import window
from oauth2client.client import GoogleCredentials
from google.cloud import storage as gstorage
#from oauth2client.client import GoogleCredentials


logging.basicConfig(level=logging.INFO)
logging.getLogger().setLevel(logging.INFO)


class sqltobq(beam.DoFn):
   def process(self,element):
    import pandas as pd
    import pandas_gbq as pdq
    import pymssql

    src1='gs://apsez_dataflow_test/dataflow_test_code/dataengineering-master'
    os.system('gsutil cp '+src1+'/job3.json /tmp/')
    logging.info('JSON File copied to Instance..')

    logging.info('installing lib')
        
    json_data = []

    with open('/tmp/job3.json') as json_file:
             json_data = json.load(json_file)

    print('------')
    size=len(json_data['JOBID'])
    logging.info('Table count -%s', size)
    print('-------')

    username='analytics_user'
    passs='analytics$user'
    hostname='10.81.162.22'
    database_name='MercuryDB'

    mydb = pymssql.connect(
    host=hostname,
    user=username,
    password=passs,
    database=database_name)


    for i in range(len(json_data['JOBID'])):
            print('=========================================================================')
            logging.info('Load Job Parameters for Job ID -%s ', i)

            Table = json_data['JOBID'][i]['TableName']
            ColumnsL = json_data['JOBID'][i]['ColumnsList']
            SchemaData= json_data['JOBID'][i]['Schema']
            IncrCol = json_data['JOBID'][i]['Inc_Col']
            NDays = json_data['JOBID'][i]['NDays']
            BQTable = json_data['JOBID'][i]['BQ_Table']
            HistLoad = json_data['JOBID'][i]['histload']
            histyear = json_data['JOBID'][i]['HistYear']

            print('Connecting to Source System....')

            logging.info('Quering table....')
            print(HistLoad)
            if str(HistLoad) == "Y" or str(HistLoad) == "y":
               logging.info('Doing historying load') 
               query_pattern = "select * from "+str(Table) + " where DATEPART(year,Timestamp) = '"+str(histyear)+"' "
            else:    
               logging.info('Incremental load..') 
               query_pattern = "select * from "+str(Table)+" where "+str(IncrCol)+ ">= DATEADD(DAY,-"+str(NDays)+", CURRENT_TIMESTAMP)" 

            logging.info(query_pattern)

            bigquery_schema=SchemaData

            BIGQUERY_TABLE = 'apsez-svc-dev-datalake.'+str(BQTable)

            logging.info('BQ Target table -%s',BIGQUERY_TABLE)

            try:
                 print('Quering on a Table:')
                 if str(HistLoad) == 'Y' or str(HistLoad) == 'y':
                     sql1= "delete from "+str(BQTable)+" where extract(year from TimeStamp) = "+str(histyear)
                 else:    
                     sql1="delete from apsez-svc-dev-datalake."+str(BQTable)+" where date("+str(IncrCol)+") >= DATE_SUB(current_date,interval "+str(NDays)+" DAY)"
                 logging.info(sql1)
                 pd.read_gbq(sql1, project_id='apsez-svc-dev-datalake')
                 logging.info('table is deleted!!')
            except:
                logging.info('Table is not created yet!!.Creating table....')
                pass

            project_id='apsez-svc-dev-datalake'
            project=str(BQTable)
            
            df = pd.read_sql(query_pattern,mydb)
            
            #yield df
            
            chunk_size=500000
            batch_no=0
            logging.info('Loading to  DataFrame....')
            try:
              for chunk in pd.read_sql(query_pattern,mydb,chunksize=chunk_size):
                logging.info('Taking data into DataFrame....')
                df = pd.DataFrame(chunk,columns=ColumnsL,index=None)
                logging.info('Loading data in bq: %s',df)
                try:
                    pdq.to_gbq(df,project,project_id,if_exists='append',table_schema=bigquery_schema)
                    batch_no+=1
                    logging.info('Data Loaded : %s for batch no :%s ',BQTable,batch_no)
                    logging.info('Job Run Complete:%s',BIGQUERY_TABLE)
                except Exception as e:
                    logging.info(e)
            except:
                logging.info('connection loss')


def run():
    parser = argparse.ArgumentParser()
    known_args, pipeline_args = parser.parse_known_args()
    # Creating pipeline options
    pipeline_options = PipelineOptions(pipeline_args)
    # Defining our pipeline and its steps
    with beam.Pipeline(options=pipeline_options) as p:
       lines = ( p | beam.Create(['1']) 
                      | "SQL_TO_BQ_DATA_LOAD" >> beam.ParDo(sqltobq()))
        
if __name__ == "__main__":
     run()

