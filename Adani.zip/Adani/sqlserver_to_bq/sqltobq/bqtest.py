from google.cloud import bigquery

def my_update_function(context,data):

    BQ = bigquery.Client()
    query_job = BQ.query("""merge into apsez-svc-dev-datalake.logistics_cleansed.layer2_fareye_active_vehicles_1 T using
(
select * except(rn) from (select t1.*,row_number() over (partition by t1.reference_no, t1.ist_timestamp, t1.state order by t1.reference_no,t1.ist_timestamp desc) as rn from (
select vehicle_no, latitude, longitude, landmark, gps_timestamp, ist_timestamp, state,  IMEI, reference_no, retrieval_date_time, business_vertical, case when reference_no like '001-%%' or reference_no like '002-%%' then substring(reference_no,5)        else reference_no        end lr_no,        address, city        from gg_replica.layer1_fayeye_api_active_vehicles_staging) t1 ) where rn=1 ) S        ON        S.reference_no=T.reference_no AND S.state=T.state and S.ist_timestamp= T.ist_timestamp
WHEN NOT MATCHED THEN
INSERT(vehicle_no, latitude, longitude, landmark, gps_timestamp, ist_timestamp, state,IMEI,reference_no, retrieval_date_time, business_vertical,lr_no,address, city) VALUES(S.vehicle_no,S.latitude,S.longitude,S.landmark,S.gps_timestamp,S.ist_timestamp,S.state,S.IMEI,S.reference_no,S.retrieval_date_time,S.business_vertical,S.lr_no
,S.address,S.city)""")
    rows = query_job.result()
    #return (rows)
    print("Number of updated rows: " + str(job_query.num_dml_affected_rows))
    #print("")
