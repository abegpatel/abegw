import argparse
import pymssql
import logging
import pandas as pd
import pandas_gbq as pdq
import json
import glob
import os
import apache_beam as beam
from apache_beam.options.pipeline_options import PipelineOptions, StandardOptions
from google.cloud import storage
from google.cloud import bigquery
from apache_beam import window
from oauth2client.client import GoogleCredentials
from google.cloud import storage as gstorage
#from oauth2client.client import GoogleCredentials


logging.basicConfig(level=logging.INFO)
logging.getLogger().setLevel(logging.INFO)

class setenv(beam.DoFn):
    def process(self,context):
        #import jaydebeapi
        import pandas as pd

        scr1='gs://apsez_dataflow_test/dataflow_test_code/dataengineering-master'
        os.system('gsutil cp '+scr1+'/tblStorageCargoDetailsOracle.json /tmp/')
        logging.info('copying connction file..')
        scr2='gs://apsez_dataflow_test/dataflow_test_code/dataengineering-master'
        os.system('gsutil cp '+scr2+'/sqlserver_to_bq_connection_details.json /tmp/')
        logging.info('Environment Variable set..')
        return list("1")


class sqltobq(beam.DoFn):
   def process(self,element):
       import pandas as pd
       #import jaydebeapi
       import pandas_gbq as pdq
       import pymssql
       json_data= []
       try:
           logging.info('Reading config file')
           with open('/tmp/tblStorageCargoDetailsOracle.json') as json_file:
               json_data=json.load(json_file)
       except Exception as e:
           logging.error(e)
       connection_details=[]
       try:
           logging.info('Reading connection file')
           with open('/tmp/sqlserver_to_bq_connection_details.json') as json_file_1:
               connection_details=json.load(json_file_1)
       except Exception as e:
           logging.error(e)

       username = connection_details['MERCURY_DB'][0]['username']
       passs = connection_details['MERCURY_DB'][0]['passs']
       hostname = connection_details['MERCURY_DB'][0]['hostname']
       database_name = connection_details['MERCURY_DB'][0]['database_name']
        
       logging.info('connection starts')
       mydb = pymssql.connect(
       host=hostname,
       user=username,
       password=passs,
       database=database_name)
       logging.info('connection established')

       print('------')
       size=len(json_data['JOBID'])
       logging.info('Table count -%s', size)
       print('-------')
       Table = json_data['JOBID'][0]['TableName']
       ColumnsL = json_data['JOBID'][0]['ColumnsList']
       SchemaData= json_data['JOBID'][0]['Schema']
       IncrCol = json_data['JOBID'][0]['Inc_Col']
       NDays = json_data['JOBID'][0]['NDays']
       BQTable = json_data['JOBID'][0]['BQ_Table']
       loadStrategy = json_data['JOBID'][0]['LoadStrategy']
       histyear = json_data['JOBID'][0]['HistYear']

       print('Connecting to Source System....')

       logging.info('Quering table....')
       print(loadStrategy)
       if str(loadStrategy) == "Y" or str(loadStrategy) == "y":
           logging.info('Doing historying load') 
           query_pattern = "select ETLID,PORTID,INT_GP_NO,UNIT_CNT,TOT_WT,INT_IGM_CRG_SEQ_NO,INT_SO_NO, INT_EA_CRG_SEQ_NO,INT_TRAIN_NO,INT_SUB_DO_NO,TRUCK_CNT,TRUCK_NET_WT,MVMT_TYPE,FM_STRG_CD, TO_STRG_CD,TRUCK_REG_NO,PIPELINE_NO,ACTVTY_DTTM,CNTRCTR_CD,GRADE_CD,INDT_NO,LOAD_TYPE, WGN_TYPE,GAINLOSS_DTTM,PKG_TYPE,GRADE_DESCR,TO_ROW_NO,TO_COLUMN_NO,FM_ROW_NO,FM_COLUMN_NO, TP_NO,GRS_WGHMNT_DTTM,TARE_WGHMNT_DTTM,GRS_WT,TARE_WT,WEIGHBRIDGE_NO,SRC_DOC_REF_NO, REASON_CD,ADT_INS_DTTM,ADT_UPD_DTTM,RECORD_INS_DATE,STACKER_CD,SHIFT_DESC,GAIN_LOSS_EVENT, INDT_DTTM,liq_ctm_gp_no,dry_ctm_gp_no,sub_do_no,sub_csne_cd,sub_csne_nm,cstm_boe_no, cstm_boe_dttm,so_no,so_dttm,cast(deleted as INT) as deleted,Timestamp,MAN_MECH_IND, EXIT_MODE, ENTRY_MODE,INT_TP_NO,SouceName from "+str(Table) + " where DATEPART(year,TARE_WGHMNT_DTTM)='"+str(histyear)+"' "

           
       else:    
           logging.info('Incremental load..') 
           query_pattern = "select ETLID,PORTID,INT_GP_NO,UNIT_CNT,TOT_WT,INT_IGM_CRG_SEQ_NO,INT_SO_NO, INT_EA_CRG_SEQ_NO,INT_TRAIN_NO,INT_SUB_DO_NO,TRUCK_CNT,TRUCK_NET_WT,MVMT_TYPE,FM_STRG_CD, TO_STRG_CD,TRUCK_REG_NO,PIPELINE_NO,ACTVTY_DTTM,CNTRCTR_CD,GRADE_CD,INDT_NO,LOAD_TYPE, WGN_TYPE,GAINLOSS_DTTM,PKG_TYPE,GRADE_DESCR,TO_ROW_NO,TO_COLUMN_NO,FM_ROW_NO,FM_COLUMN_NO, TP_NO,GRS_WGHMNT_DTTM,TARE_WGHMNT_DTTM,GRS_WT,TARE_WT,WEIGHBRIDGE_NO,SRC_DOC_REF_NO, REASON_CD,ADT_INS_DTTM,ADT_UPD_DTTM,RECORD_INS_DATE,STACKER_CD,SHIFT_DESC,GAIN_LOSS_EVENT, INDT_DTTM,liq_ctm_gp_no,dry_ctm_gp_no,sub_do_no,sub_csne_cd,sub_csne_nm,cstm_boe_no, cstm_boe_dttm,so_no,so_dttm,cast(deleted as INT) as deleted,Timestamp,MAN_MECH_IND, EXIT_MODE, ENTRY_MODE,INT_TP_NO,SouceName from "+str(Table)+" where "+str(IncrCol)+ ">= DATEADD(DAY,-"+str(NDays)+", CURRENT_TIMESTAMP) or "+str(IncrCol)+ " is null"
 
       logging.info(query_pattern)
       bigquery_schema=SchemaData
       BIGQUERY_TABLE = 'apsez-svc-dev-datalake.'+str(BQTable)
       logging.info('BQ Target table -%s',BIGQUERY_TABLE)
       try:
           print('Quering on a Table:')
           if str(loadStrategy) == 'Y' or str(loadStrategy) == 'y':
               sql1= "delete from "+str(BQTable)+" where extract(year from TARE_WGHMNT_DTTM) = "+str(histyear)
           elif str(loadStrategy) =="FullLoad":
               sql1="truncate table apsez-svc-dev-datalake."+str(BQTable)
           else:    
               sql1="delete from apsez-svc-dev-datalake."+str(BQTable)+" where date("+str(IncrCol)+") >= DATE_SUB(current_date,interval "+str(NDays)+" DAY) or "+str(IncrCol)+" is null"
           logging.info(sql1)
           client = bigquery.Client()
           query_job = client.query(sql1)
           query_job.result()
           #pd.read_gbq(sql1, project_id='apsez-svc-dev-datalake')

           logging.info('Data deleted!!')

       except:
           logging.info('Table is not created yet!!.Creating table....')
           pass
       project_id='apsez-svc-dev-datalake'
       project=str(BQTable)
            
       df = pd.read_sql(query_pattern,mydb)
            
            #yield df
       chunk_size=500000
       batch_no=0
       logging.info('Loading to  DataFrame....')
       try:
           for chunk in pd.read_sql(query_pattern,mydb,chunksize=chunk_size):
               logging.info('Taking data into DataFrame....')
               df = pd.DataFrame(chunk,columns=ColumnsL,index=None)
               logging.info('Loading data in bq: %s',df)
               try:
                   pdq.to_gbq(df,project,project_id,if_exists='append',table_schema=bigquery_schema)
                   batch_no+=1
                   logging.info('Data Loaded : %s for batch no :%s ',BQTable,batch_no)
                   logging.info('Job Run Complete:%s',BIGQUERY_TABLE)
               except Exception as e:
                   logging.info(e)
       except:
           logging.info('connection loss')


def run():
    try:
        parser = argparse.ArgumentParser()
        known_args, pipeline_args = parser.parse_known_args()
        pipeline_options = PipelineOptions(pipeline_args)
        pcoll=beam.Pipeline(options=pipeline_options)
        dummy= pcoll | 'Initializing..' >> beam.Create(['1'])
        dummy_env= (dummy | 'Setting up instance ..' >> beam.ParDo(setenv()) | 'Processing & loading to bigquery' >> beam.ParDo(sqltobq()))
        p=pcoll.run()
        p.wait_until_finish()
    except:  
        logging.exception('Failec to launch datapipeline')
        raise

        
if __name__ == "__main__":
     run()

