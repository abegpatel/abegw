import setuptools

setuptools.setup(
    name='set_libs',
    version='0.1.1',
    packages=setuptools.find_packages(),
    install_requires=['psycopg2-binary','pandas','pandas_gbq','pymssql','jaydebeapi','SQLAlchemy','flask_sqlalchemy','google-cloud-bigquery','threaded']
    
)
