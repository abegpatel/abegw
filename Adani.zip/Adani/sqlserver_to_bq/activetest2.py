from google.cloud import bigquery

def my_update_function(context,data):

    BQ = bigquery.Client()
    query_job = BQ.query("delete from gg_replica.layer1_asset_tracking_active_vehicles where 1=1")
    rows = query_job.result()
    #return (rows)
    return("Number of updated rows: " + str(query_job.num_dml_affected_rows))
