import pymssql
import logging
import pandas as pd
import pandas_gbq as pdq
import json
import glob
import os


json_data = []

with open('job.json') as json_file:
     json_data = json.load(json_file)

print('------')
size=len(json_data['JOBID'])
print('Table count -', size)
print('-------')

username='analytics_user'
passs='analytics$user'
hostname='10.81.162.22'
database_name='MercuryDB'

mydb = pymssql.connect(
host=hostname,
user=username,
password=passs,
database=database_name
)



for i in range(len(json_data['JOBID'])):
    print('Load Job Parameters.....')      

    Table = json_data['JOBID'][i]['TableName']
    ColumnsL = json_data['JOBID'][i]['ColumnsList']
    SchemaData= json_data['JOBID'][i]['Schema']
    #IncrCol = json_data['JOBID'][i]['Inc_Col']
    BQTable = json_data['JOBID'][i]['BQ_Table']

    #res_value=" '2022-05-10' "

    print('Connecting to Source System....')

    print('Quering table....')


    #query_bq="select max(timestamp) as res from " +str(BQTable)

    #max_timestamp = pd.read_gbq(query_bq, project_id='apsez-svc-dev-datalake')
    
    #result = pd.DataFrame(max_timestamp,columns=['res'])



    query_pattern = "select top 1000 * from "+str(Table)

    #query_pattern = "select * from "+ str(Table) + " where " + str(IncrCol) + " > '" +str(result.iloc[0]['res']).split('.')[0] + "'"

    #print(query_pattern)



    chunk_size=1000000
    batch_no=1
    print('file creating in progress...')
    for chunk in pd.read_sql(query_pattern,mydb,chunksize=chunk_size):
        chunk.to_csv('chk'+str(batch_no)+'.csv',index=False)
        batch_no+=1
    
    sql_query = pd.read_sql(query_pattern, mydb)
    

    files = os.path.join("/sqlserver_to_bq", "chk*.csv")

    # list of merged files returned
    files = glob.glob(files)

    print("Resultant CSV after joining all CSV files at a particular location...");

    # joining files with concat and read_csv
    
    df = pd.concat(map(pd.read_csv, files), ignore_index=True)
   

    print('Loading to  DataFrame....')

    #df = pd.DataFrame(sql_query,columns=ColumnsL,index=None)

    #print(df)

    BIGQUERY_TABLE = 'apsez-svc-dev-datalake.Test_Dev.' +str(Table)
    
    sql1= "truncate table apsez-svc-dev-datalake.Test_Dev.tblStorageCargoDetailsOracle" 

    pd.read_gbq(sql1, project_id='apsez-svc-dev-datalake')
 
    print('Loading Data for -',BIGQUERY_TABLE)

    bigquery_schema=SchemaData

    print('Loading data to bq')
    
    #for file in glob.glob("../sqlserver_to_bq/abc*.csv"):
    #     df = pd.read_csv(file,ignore_index=True,dtype={'ACTVTY_DTTM':STRING,'CNTRCTR_CD':STRING,'GRADE_CD':STRING,'INDT_NO':STRING,'LOAD_TYPE':STRING,'WGN_TYPE':STRING,'GAINLOSS_DTTM':FLOAT,'PKG_TYPE':STRING,'GRADE_DESCR':STRING,'TO_ROW_NO':FLOAT,'TO_COLUMN_NO':STRING,'FM_ROW_NO':FLOAT,'FM_COLUMN_NO':STRING,'TP_NO':STRING,'GRS_WGHMNT_DTTM':STRING,'TARE_WGHMNT_DTTM':STRING,'GRS_WT':FLOAT,'TARE_WT':FLOAT,'WEIGHBRIDGE_NO':STRING,'SRC_DOC_REF_NO':STRING,'REASON_CD':FLOAT,'ADT_INS_DTTM':STRING,'ADT_UPD_DTTM':STRING,'RECORD_INS_DATE':STRING,'STACKER_CD':STRING,'SHIFT_DESC':FLOAT,'GAIN_LOSS_EVENT':FLOAT,'INDT_DTTM':STRING,'liq_ctm_gp_no':STRING,'dry_ctm_gp_no':STRING,'sub_do_no':STRING,'sub_csne_cd':STRING,'sub_csne_nm':STRING}) 
    #     print('file name-',file)
    #     print(df.dtypes)
    #     pdq.to_gbq(df,BIGQUERY_TABLE,if_exists='append',table_schema=bigquery_schema,api_method="load_csv")
    
    
    for file in glob.glob("../sqlserver_to_bq/chk*.csv"):
        os.remove(file)
    #chunk_size=1000000
    #batch_no=1
    #print('file creating in progress...')
    #for chunk in pd.read_sql(query_pattern,mydb,chunksize=chunk_size):
        #chunk.to_csv('abc'+str(batch_no)+'.csv',index=False)
    pdq.to_gbq(df,BIGQUERY_TABLE,if_exists='replace',table_schema=bigquery_schema,api_method="load_csv")
    # batch_no+=1

    #sql_query = pd.read_sql(query_pattern, mydb)

    print('Data Loaded.Job Run Complete!')
