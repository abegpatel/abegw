import pymssql
import logging
import pandas as pd
import pandas_gbq as pdq
import json
json_data = []

with open('job.json') as json_file:
     json_data = json.load(json_file)

print('------')
size=len(json_data['JOBID'])
print('Table count -', size)
print('-------')

username='analytics_user'
passs='analytics$user'
hostname='10.81.162.22'
database_name='MercuryDB'

mydb = pymssql.connect(
host=hostname,
user=username,
password=passs,
database=database_name
)



for i in range(len(json_data['JOBID'])):
    print('Load Job Parameters.....')      

    Table = json_data['JOBID'][i]['TableName']
    ColumnsL = json_data['JOBID'][i]['ColumnsList']
    SchemaData= json_data['JOBID'][i]['Schema']
    #IncrCol = json_data['JOBID'][i]['Inc_Col']
    BQTable = json_data['JOBID'][i]['BQ_Table']

    #res_value=" '2022-05-10' "

    print('Connecting to Source System....')

    print('Quering table....')

    #query_bq="select max(timestamp) as res from " +str(BQTable)

    #max_timestamp = pd.read_gbq(query_bq, project_id='apsez-svc-dev-datalake')
    
    #result = pd.DataFrame(max_timestamp,columns=['res'])

    #query_pattern="select Combo,PORTID,MVMT_TYPE,ROW_NO from (select Combo,PORTID,MVMT_TYPE,ROW_NUMBER() over(partition by combo order by combo) as row_no from (select distinct((case when fm_strg_cd like 'T-%' and FM_STRG_CD is not null then FM_STRG_CD else TO_STRG_CD end + convert(varchar,PORTID) + convert(varchar,tare_wghmnt_dttm,105))) as combo,PORTID,MVMT_TYPE  from tblStorageCargoDetailsOracle where PORTID in (1,3) and TARE_WGHMNT_DTTM>'2019-03-31' and PORTID in (1,3) and FM_STRG_CD like 'T-%' or TO_STRG_CD like 'T-%') as X ) as Y where row_no=1 and combo is not null"
    query_pattern = "select top 10 * from "+str(Table)

    #query_pattern = "select * from "+ str(Table) + " where " + str(IncrCol) + " > '" +str(result.iloc[0]['res']).split('.')[0] + "'"

    print(query_pattern)

    sql_query = pd.read_sql(query_pattern, mydb)

    print('Loading to  DataFrame....')

    df = pd.DataFrame(sql_query,columns=ColumnsL,index=None)

    #print(df)

    BIGQUERY_TABLE = 'apsez-svc-dev-datalake.Test_Dev.' +str(Table)
    

    print('Loading Data for -',BIGQUERY_TABLE)

    bigquery_schema=SchemaData

    print('Loading data to bq')

    pdq.to_gbq(df,BIGQUERY_TABLE,if_exists='replace',table_schema=bigquery_schema,api_method="load_csv")

    print('Data Loaded.Job Run Complete!')
