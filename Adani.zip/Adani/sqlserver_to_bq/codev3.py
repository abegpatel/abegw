import pymssql
import logging
import pandas as pd
import pandas_gbq as pdq
import json
import glob
import os


json_data = []

with open('job2.json') as json_file:
     json_data = json.load(json_file)

print('------')
size=len(json_data['JOBID'])
print('Table count -', size)
print('-------')

username='analytics_user'
passs='analytics$user'
hostname='10.81.162.22'
database_name='MercuryDB'

mydb = pymssql.connect(
host=hostname,
user=username,
password=passs,
database=database_name
)



for i in range(len(json_data['JOBID'])):
    print('Load Job Parameters.....')

    Table = json_data['JOBID'][i]['TableName']
    ColumnsL = json_data['JOBID'][i]['ColumnsList']
    SchemaData= json_data['JOBID'][i]['Schema']
    #IncrCol = json_data['JOBID'][i]['Inc_Col']
    #BQTable = json_data['JOBID'][i]['BQ_Table']


    print(ColumnsL)

    print('Connecting to Source System....')

    print('Quering table....')


    query_pattern = "select top 100 * from "+str(Table)

    print(query_pattern)
    
    bigquery_schema=SchemaData
    
    BIGQUERY_TABLE = 'apsez-svc-dev-datalake.CLEANSED.layer2_MercuryDB_' +str(Table)
    
    print('truncat table -',BIGQUERY_TABLE)

    try:
      sql1= 'truncate table apsez-svc-dev-datalake.CLEANSED.layer2_MercuryDB_'+str(Table)
      pd.read_gbq(sql1, project_id='apsez-svc-dev-datalake')
    except Exception as e:
        print('Table is not created yet!!.Creating table....')

    chunk_size=100000
    batch_no=0
    print('Loading to  DataFrame....')
    for chunk in pd.read_sql(query_pattern,mydb,chunksize=chunk_size):
        #chunk.to_csv('chk'+str(batch_no)+'.csv',index=False)
        df = pd.DataFrame(chunk,columns=ColumnsL,index=None)
        #print(df)
        pdq.to_gbq(df,BIGQUERY_TABLE,if_exists='append',table_schema=bigquery_schema)
        batch_no+=1
        print('loaded data for batch no-',batch_no)
   

    print('Data Loaded.Job Run Complete!')

