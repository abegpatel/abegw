import argparse
import pymssql
import logging
import pandas as pd
import pandas_gbq as pdq
import json
import glob
import os
import apache_beam as beam
from apache_beam.options.pipeline_options import PipelineOptions, StandardOptions
from google.cloud import storage
from google.cloud import bigquery
from apache_beam import window

logging.basicConfig(level=logging.INFO)
logging.getLogger().setLevel(logging.INFO)



class CustomParsing(beam.DoFn):
    """ Custom ParallelDo class to apply a custom transformation """
    def to_runner_api_parameter(self, unused_context):
        return "beam:transforms:custom_parsing:custom_v0", None
    def process(self, element: bytes, timestamp=beam.DoFn.TimestampParam, window=beam.DoFn.WindowParam):
        import pandas as pd
        import pandas_gbq as pdq
        import pymssql
        logging.info('installing lib')
        
        json_data = []

        with open('job.json') as json_file:
             json_data = json.load(json_file)

        print('------')
        size=len(json_data['JOBID'])
        print('Table count -', size)
        print('-------')

        username='analytics_user'
        passs='analytics$user'
        hostname='10.81.162.22'
        database_name='MercuryDB'



        mydb = pymssql.connect(
        host=hostname,
        user=username,
        password=passs,
        database=database_name
        )



        for i in range(len(json_data['JOBID'])):
            print('=========================================================================')
            print('Load Job Parameters for Job ID - ', i)

            Table = json_data['JOBID'][i]['TableName']
            ColumnsL = json_data['JOBID'][i]['ColumnsList']
            SchemaData= json_data['JOBID'][i]['Schema']
            #IncrCol = json_data['JOBID'][i]['Inc_Col']
            #BQTable = json_data['JOBID'][i]['BQ_Table']

            print('Connecting to Source System....')

            print('Quering table....')

            query_pattern = "select * from "+str(Table)+" "

            print(query_pattern)

            bigquery_schema=SchemaData

            BIGQUERY_TABLE = 'apsez-svc-dev-datalake.CLEANSED.layer2_MercuryDB_'+str(Table)

            print('truncat table -',BIGQUERY_TABLE)

            try:
                print('Quering on a Table:')
                sql1= 'truncate table apsez-svc-dev-datalake.CLEANSED.layer2_MercuryDB_'+str(Table)
                pd.read_gbq(sql1, project_id='apsez-svc-dev-datalake')
                print('table truncated!!')
            except:
                print('Table is not created yet!!.Creating table....')
                pass

            project_id='apsez-svc-dev-datalake'
            project='CLEANSED.layer2_MercuryDB_'+str(Table)
            
            df = pd.read_sql(query_pattern,mydb)
            
            #yield df
            
            chunk_size=5000000
            batch_no=0
            print('Loading to  DataFrame....')
            try:
              for chunk in pd.read_sql(query_pattern,mydb,chunksize=chunk_size):
                print('Taking data into DataFrame....')
                df = pd.DataFrame(chunk,columns=ColumnsL,index=None)
                print('Loading data in bq....',df)
                try:
                    pdq.to_gbq(df,project,project_id,if_exists='replace',table_schema=bigquery_schema)
                    batch_no+=1
                    print('Data Loaded : ',BIGQUERY_TABLE,' for batch no : ',batch_no)
                    print('Job Run Complete:',BIGQUERY_TABLE)
                except Exception as e:
                    print(e)
            except:
                print('connection loss')

def run():
    # Parsing arguments
    known_args, pipeline_args = parser.parse_known_args()
    # Creating pipeline options
    pipeline_options = PipelineOptions(pipeline_args=None)
    # Defining our pipeline and its steps
    with beam.Pipeline(options=pipeline_options) as p:
    Write_To_STG = (p| "SQL_TO_BQ_DATA_LOAD" >> beam.Map(CustomParsing())
        
if __name__ == "__main__":
    run()
