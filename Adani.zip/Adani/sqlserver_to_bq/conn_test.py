import pymssql
import logging
import pandas as pd
import pandas_gbq as pdq
import json
import glob
import os

username='analytics_user'
passs='analytics$user'
hostname='10.82.162.22'
database_name='MercuryDB'



mydb = pymssql.connect(
host=hostname,
user=username,
password=passs,
database=database_name
)

def main():
        schema = ["ETLID","PortID","INT_OPRN_NO","INT_VIA_NO","OPRN_DTTM","TONNAGE_HNDLD","PKG_HNDLD","AVG_RATE","SHORE_CRANE_CNT","VOY_CRN_CNT","CRANE_CNT","CMDT_CD","OPRN_START_DTTM","OPRN_END_DTTM","BAL_TONNAGE","NET_TANK_RCPT_QTY","TARGET_QTY","ROB","BNKR_RQST_NO","INDT_NO","MVMT_TYPE","MVMT_BNKR_DLVY_MODE","INT_IGM_CRG_SEQ_NO","INT_EA_CRG_SEQ_NO","PORT_CD","BU_CD","COMMODITY","COMMODITY_TYPE","COMMODITY_TYPE_CODE","INT_SO_NO","INT_SUB_DO_NO","INT_GP_NO","FM_STRG_CD","TimeStamp","Deleted","SouceName"]
        query_pattern = "select top 5 * from tblVesselCargoInfoOracle"
        df=pd.read_sql(query_pattern,mydb,chunksize=200)
        #print(pd.DataFrame(df,columns=schema,index=None))

if __name__=="__main__":
    main()
