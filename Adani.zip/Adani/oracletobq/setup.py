import setuptools

setuptools.setup(
    name='set_libs',
    version='1.0',
    packages=setuptools.find_packages(),	
    install_requires=['pandas','apache-beam==2.43.0','cx-Oracle']
)    
