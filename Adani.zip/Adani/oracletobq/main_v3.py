import apache_beam as beam
from google.cloud import bigquery
#from google.cloud import dbapi
import cx_Oracle
import logging
from oauth2client.client import GoogleCredentials
from apache_beam.options.pipeline_options import PipelineOptions, StandardOptions
import argparse
from google.cloud import storage

logging.basicConfig(level=logging.INFO)
logging.getLogger().setLevel(logging.INFO)

class orasetup(beam.DoFn):
 def process(self,query):
       
   import cx_Oracle
   import argparse

   try: 
     conn = cx_Oracle.connect('analytics.user1/analyticsuser1@10.6.160.113:1521/IPOSDR')
     cursor = conn.cursor()
     logging.info(query)
     print(query)
     print('firing query')
     logging.info('firing query')
     cursor.execute(query)
     rows = cursor.fetchall()
     return rows
   except cx_Oracle.DatabaseError as e:
     print(e)
     logging.info(e)


 def process(self,rows,project_id,dataset_id,table_id):
    
   from google.cloud import bigquery
   from oauth2client.client import GoogleCredentials
   import argparse
   from google.cloud import storage

   client = bigquery.Client(project=project_id)
   table_ref = client.dataset(dataset_id).table(table_id)
   table = client.get_table(table_ref)
   logging.info('loading data to bq')
   print('loading into bq table')
   errors = client.insert_rows(table,rows)
   if errors == []:
     print('data loaded successfully')
   else:
     print('Error occured')

def run():
 try:
   project_id="apsez-svc-dev-datalake"
   dataset_id="Test_Dev"
   table_id="gatepass_details_da_080223"
   #query="select * from tos_usr.gatepass_details_da FETCH FIRST 10 ROWS ONLY"
   query="select * from tos_usr.gatepass_details_da where to_char(PRE_GATEPASS_GENERATION_DATE,'YYYY')=2022"

   parser = argparse.ArgumentParser()
   known_args, pipeline_args = parser.parse_known_args()
   pipeline_options = PipelineOptions(pipeline_args)
   pcoll=beam.Pipeline(options=pipeline_options)
   #pcoll = beam.Pipeline()
   dummy = pcoll | 'Initializing..' >> beam.Create(['1'])
   rows = (dummy | "Read from Oracle" >> beam.ParDo(orasetup(query)) 
                 | "Mapping" >> beam.Map(lambda x :  )
                 | "Write to BigQuery" >> beam.ParDo(bqsetup(x,project_id,dataset_id,table_id)))
   #pipeline.run().wait_until_finish()
   p=pcoll.run()
   p.wait_until_finish()
 except:  
   logging.exception('Failec to launch datapipeline')
   raise

if __name__=="__main__":
    run()   
