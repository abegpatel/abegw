import argparse
import json
import os
import logging
import apache_beam as beam
from apache_beam.options.pipeline_options import PipelineOptions, StandardOptions
from google.cloud import storage



client = storage.Client()

logging.basicConfig(level=logging.INFO)
logging.getLogger().setLevel(logging.INFO)

# Service account key path
#os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = "/home/akash_yadav042119/PythonScripts/project-python-330110-8a147dea0659.json"
# INPUT_SUBSCRIPTION = "projects/project-python-330110/subscriptions/streaming_topic_1-sub"
INPUT_SUBSCRIPTION = "projects/apsez-svc-dev-datalake/subscriptions/ENIPPRD.TOS_USR.CTRDTLS_O-sub"
# BIGQUERY_TABLE = "project-python-330110:stream_dataset.streaming_table_1"


BIGQUERY_TABLE = "apsez-svc-dev-datalake:debezium_stg.ctrdtls_o2"
# BIGQUERY_SCHEMA = "timestamp:TIMESTAMP,attr1:FLOAT,msg:STRING"
BIGQUERY_SCHEMA = "CTR_NO:STRING,LIFE_NO:INTEGER,ACTIVE_FLG:STRING,AGGRT_CONN_FLG:STRING,BASE_STS:STRING,BDL_IND:STRING,CHK_DIGIT_FAIL_FLG:STRING,CTR_HT:INTEGER,CTR_NO_CHNGD_FLG:STRING,CTR_SIZE:INTEGER,CTR_TARE_WT:DECIMAL,CTR_TYPE:STRING,CTR_WT:DECIMAL,DMG_FLG:STRING,FCL_LCL_IND:STRING,FE_IND:STRING,HOLD_FLG:STRING,HZ_FLG:STRING,ISO_CD:STRING,ITT_TO_MNR_RSTRCT_FLG:STRING,LD_MNF_FLG:STRING,LINE_CD:STRING,MAX_GRS_WT:DECIMAL,NON_CTR_FLG:STRING,OOG_FLG:STRING,OWN_FOREIGN_IND:STRING,RFR_FLG:STRING,RSTRCT_FLG:STRING,VSL_DLVRY_RSTRCT_FLG:STRING,TURN_IN_NO_RQRD_FLG:STRING,STRIP_OPRN_RQRD_FLG:STRING,CTR_RFR_FLG:STRING,SPL_EQPT_FLG:STRING,CSC_CD:STRING,INTER_CHNG_NO:INTEGER,DMG_SVRTY_CD:STRING,CTR_MTRL:STRING,ADT_INS_DTTM:INTEGER,ADT_UPD_DTTM:INTEGER,CTR_VOL:DECIMAL,ACT_CTR_WT:DECIMAL,PTY_ACCT_CD:STRING,DOC_RQRD_FLG:STRING,ACCESSRY_FLG:STRING,ACT_ARR_IND:STRING,PLAND_ENTRY_INT_TMNL_NO:INTEGER,PLAND_EXIT_INT_TMNL_NO:INTEGER,CHSS_ATTCHD_FLG:STRING,CTR_WD:STRING,DIR_MVMT_IND:STRING,DISP_MD:STRING,GRS_ALLOWB_WT:DECIMAL,GRS_ALLOWB_WT_UOM:STRING,HZ_REQRD_INFO_STS:STRING,INT_CNSGN_NO:INTEGER,RESTOW_REASON_CD:STRING,RESTOW_TYPE:STRING,SEAL_AVLB_IND:STRING,WT_UOM:STRING,INT_CTR_NO:INTEGER,ADT_VER_STAMP:INTEGER,ADT_INS_USR_CD:STRING,ADT_UPD_USR_CD:STRING,ADT_TXN_CD:STRING,ADT_TXN_NO:INTEGER,ADT_INS_EXT_USR_FLG:STRING,ADT_UPD_EXT_USR_FLG:STRING,DSCH_POD:STRING,LD_POD:STRING,SB_NO:STRING,SB_DTTM:INTEGER,CFS_EXIT_DTTM:INTEGER,MAIN_LINE_CD:STRING,PRINT_COUNT:INTEGER,EIR_PROCESSED_FLG:STRING,DISP_LINE_CD:STRING,CTR_CAT_CD:STRING,EIR_NO:STRING,DLVRY_APPRVD_FLG:STRING,BOE_NO:STRING,BOE_DTTM:INTEGER,CRG_WT:DECIMAL,EIR_PROCESSED_DTTM:INTEGER,BAR_CD:STRING,DRF_BAR_CD:STRING,DLVRY_EIR_NO:STRING,RCPT_EIR_NO:STRING,OOC_NO:STRING,OOC_DTTM:INTEGER,SHPMNT_TYPE:STRING,UCN:STRING,FUMIGATION_RQRD_FLG:STRING,NO_MTY_DLVRY_FLG:STRING,GEN_SET_RQRD_FLG:STRING,EXP_START_OVERRIDE_FLG:STRING,MTY_DLVRY_START_OVERRIDE_FLG:STRING,EXPORT_CUTOFF_OVERRIDE_FLG:STRING,USDA_RLS_FLG:STRING,IMP_CSTM_CLRNC_FLG:STRING,FRT_RLS_FLG:STRING,CARR_RLS_FLG:STRING,PTT_FLG:STRING,CSTM_RMRKS:STRING,WHEELED_GRND_IND:STRING,PREV_BASE_STS:STRING,PLNG_HOLD_FLG:STRING,USER_CTR_WT:DECIMAL,USER_CTR_TARE_WT:DECIMAL,VGM_VER_FLG:STRING,DCLRD_CTR_WT:DECIMAL,RESIDUE_FLG:STRING,WHEELED_SLOTS_RQRD_FLG:STRING,operation:STRING,msg_published_time:TIMESTAMP"

class CustomParsing(beam.DoFn):
    """ Custom ParallelDo class to apply a custom transformation """
    def to_runner_api_parameter(self, unused_context):
        # Not very relevant, returns a URN (uniform resource name) and the payload
        return "beam:transforms:custom_parsing:custom_v0", None

    def process(self, element: bytes, timestamp=beam.DoFn.TimestampParam, window=beam.DoFn.WindowParam):
        import pandas as pd

        parsed = json.loads(element.decode("utf-8"))
        payload_data = parsed['payload']
        
        intermediate_data = {}
        if payload_data['before'] == None or 'before' not in payload_data:
            intermediate_data = payload_data['after']
            intermediate_data['operation'] = "INSERT"
        elif payload_data['after'] == None or 'after' not in payload_data:
            intermediate_data = payload_data['before']
            intermediate_data['operation'] = "DELETE"    
        else:
            intermediate_data = payload_data['after']
            intermediate_data['operation'] = "UPDATE-INSERT"
            
        df = pd.json_normalize(intermediate_data).to_dict(orient='records')[0]
        df['msg_published_time'] = timestamp.to_rfc3339()

        print(df)
        yield df

def run():
    # Parsing arguments
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--input_subscription",
        help='Input PubSub subscription of the form "projects/<PROJECT>/subscriptions/<SUBSCRIPTION>."',
        default=INPUT_SUBSCRIPTION,
    )
    parser.add_argument(
        "--output_table", help="Output BigQuery Table", default=BIGQUERY_TABLE
    )
    parser.add_argument(
        "--output_schema",
        help="Output BigQuery Schema in text format",
        default=BIGQUERY_SCHEMA,
    )
    known_args, pipeline_args = parser.parse_known_args()

    # Creating pipeline options
    pipeline_options = PipelineOptions(pipeline_args)
    pipeline_options.view_as(StandardOptions).streaming = True

    # Defining our pipeline and its steps
    with beam.Pipeline(options=pipeline_options) as p:
        (
            p
            | "ReadFromPubSub" >> beam.io.gcp.pubsub.ReadFromPubSub(
                subscription=known_args.input_subscription, timestamp_attribute=None
            )
            | "CustomParse" >> beam.ParDo(CustomParsing())
            # | "WriteToGCS" >>  beam.io.WriteToText(file_path_prefix="gs://apsez_dataflow_test/sqlserver_files/original_bq_dbz",file_name_suffix='.txt')
            | "WriteToBigQuery" >> beam.io.WriteToBigQuery(
                known_args.output_table,
                schema=known_args.output_schema,
                write_disposition=beam.io.BigQueryDisposition.WRITE_APPEND,
            )
        )


if __name__ == "__main__":
    run()