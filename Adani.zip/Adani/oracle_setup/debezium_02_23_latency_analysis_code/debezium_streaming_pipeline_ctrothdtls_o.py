import argparse
import json
import os
import logging
import apache_beam as beam
from apache_beam.options.pipeline_options import PipelineOptions, StandardOptions
from google.cloud import storage



client = storage.Client()

logging.basicConfig(level=logging.INFO)
logging.getLogger().setLevel(logging.INFO)

# Service account key path
#os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = "/home/akash_yadav042119/PythonScripts/project-python-330110-8a147dea0659.json"
# INPUT_SUBSCRIPTION = "projects/project-python-330110/subscriptions/streaming_topic_1-sub"
INPUT_SUBSCRIPTION = "projects/apsez-svc-dev-datalake/subscriptions/ENIPPRD.TOS_USR.CTROTHDTLS_O-sub"
# BIGQUERY_TABLE = "project-python-330110:stream_dataset.streaming_table_1"


BIGQUERY_TABLE = "apsez-svc-dev-datalake:debezium_stg.CTROTHDTLS_O"
# BIGQUERY_SCHEMA = "timestamp:TIMESTAMP,attr1:FLOAT,msg:STRING"
BIGQUERY_SCHEMA ="CTR_NO:string,LIFE_NO:integer,CTR_WEIGH_FLG:string,BKNG_NO:string,ENTRY_MODE:string,EXIT_MODE:string,EXPT_LD_VSL_CD:string,FPD:string,POD:string,POL:string,INSIDE_CHK_DONE_FLG:string,RORO_LOLO_IND:string,ENTRY_MODE_TYPE:string,EXIT_MODE_TYPE:string,INVC_RQRD_FLG:string,INVC_FLG:string,CMDT_CD:string,EMPTY_CTR_CHK_STS:string,LD_INSTR_CD:string,LINER_TERM:string,SPL_USE_CD:string,STUFF_STRP_CD:integer,TRANSSHIP_IND:string,WATER_HZ_CLS:string,ENTRY_DTTM:integer,EXIT_DTTM:integer,STUFF_STRP_DTTM:integer,INVC_LINE_CD:string,ENTRY_INT_YD_TMNL_NO:integer,EXIT_INT_YD_TMNL_NO:integer,ADT_INS_DTTM:integer,ADT_UPD_DTTM:integer,INT_BKNG_NO:integer,TRNSPT_DOC_NO:string,DUS_NO:string,CSTM_AGENT_CD:string,BL_RMRKS:string,BKNG_SEQ_NO:integer,WEIGHBRIDGE_WT:float64,IMP_DOC_WT:float64,IMP_DOC_NO:string,IMP_DOC_DESCR:string,IMP_DOC_DTTM:integer,INLAND_ORIGIN:string,HAUL_CD:string,EDI_FLG:string,SPL_ATTRIB_FLG:string,ITT_FLG:string,URGENT_DLVRY_FLG:string,INLAND_DEST:string,CSTM_REF_NO:string,BL_NO:string,CNSGN_S_DESCR:string,CTR_LEAKG_FLG:string,CTR_PIN:integer,DELVRY_GRP_CD:string,EXT_INBOUND_INT_VCN_NO:integer,EXT_OUTBOUND_INT_VCN_NO:integer,FRWDR_S_DESCR:string,GRP_CD:string,INBOUND_TRAIN_NO:string,INFO_STS:string,INHLN_HZ_FLG:string,INSTR_CD:string,INT_DO_NO:integer,INT_EARLY_LATE_RECVL_NO:integer,OUTBOUND_TRAIN_NO:string,PLAND_CHSS_NO:string,PLAND_DRVR_ID:string,PLAND_TRUCK_REGN_NO:string,RECVL_GRP_CD:string,REGULARISED_IND:string,RESPONB_PTY:string,SHPR_S_DESCR:string,SMTP_DTTM:integer,SMTP_NO:string,S_REM:string,WGN_NO:string,INT_CTR_NO:integer,INT_DG_REG_NO:integer,ADT_VER_STAMP:integer,ADT_INS_USR_CD:string,ADT_UPD_USR_CD:string,ADT_TXN_CD:string,ADT_TXN_NO:integer,ADT_INS_EXT_USR_FLG:string,ADT_UPD_EXT_USR_FLG:string,INT_BL_NO:integer,DEPOT_CD:string,STEVEDORE_RMRK:string,PRIO_RMRK:string,POO:string,DEPOT_ORIGIN_CD:string,DEPOT_DEST_CD:string,OTH_ITT_FLG:string,SPL_STS:string,DRF_PRINT_SEQ_CD:string,SUB_LINE_NO:integer,CRG_DESCR:string,CSNE_NM:string,CSNE_ADDR:string,RLS_UNTIL_DT:integer,DRAY_FLG:string,RF_TAG_ID:string,DLVRY_OTH_ITT_FLG:string,IGM_NO:string,IGM_DTTM:integer,SPL_STK_CD:string,LCL_SHARE_FLG:string,OT_DSCH_DTTM:integer,PRE_GATE_FLG:string,PIN_NO:string,EXP_CSTM_CLRNCE_FLG:string,DUMMY_FLG:string,CHRGBL_PTY:string,GCR_FLG:string,MAIDEN_FLG:string,IMCO_LBL_EXISTS:string,DO_EXP_OVERRIDE_DATE:integer,NON_INV_AGE:float64,TRNS_ADVICE_DTTM:integer,MANIFEST_FLG:string,VOY_SEP_CD:string,CUST_APPROVAL_STS:string,CUST_PROCESSED_DTTM:integer,LINE_NO:string,CUSTOM_FLAG:string,CUSTOM_PRCNT:integer,DPD_FLAG:string,DLVRBLE_PTY:string,SCAN_FLG:string,SCAN_TYPE:string,PALLET_CNT:integer,QTY:integer,CRG_CONDITION:string,TNE_BOND_REF_NO:string,BORDER_SECURITY_POINT:string,FRWDR_NM:string,DPE_FLG:string,DPE_RPCT_PTY:string,operation:string,msg_published_time:TIMESTAMP"
class CustomParsing(beam.DoFn):
    """ Custom ParallelDo class to apply a custom transformation """
    def to_runner_api_parameter(self, unused_context):
        # Not very relevant, returns a URN (uniform resource name) and the payload
        return "beam:transforms:custom_parsing:custom_v0", None

    def process(self, element: bytes, timestamp=beam.DoFn.TimestampParam, window=beam.DoFn.WindowParam):
        import pandas as pd

        parsed = json.loads(element.decode("utf-8"))
        payload_data = parsed['payload']
        
        intermediate_data = {}
        if payload_data['before'] == None or 'before' not in payload_data:
            intermediate_data = payload_data['after']
            intermediate_data['operation'] = "INSERT"
        elif payload_data['after'] == None or 'after' not in payload_data:
            intermediate_data = payload_data['before']
            intermediate_data['operation'] = "DELETE"    
        else:
            intermediate_data = payload_data['after']
            intermediate_data['operation'] = "UPDATE-INSERT"
            
        df = pd.json_normalize(intermediate_data).to_dict(orient='records')[0]
        df['msg_published_time'] = timestamp.to_rfc3339()
        
        
       
        print(df)
        yield df

def run():
    # Parsing arguments
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--input_subscription",
        help='Input PubSub subscription of the form "projects/<PROJECT>/subscriptions/<SUBSCRIPTION>."',
        default=INPUT_SUBSCRIPTION,
    )
    parser.add_argument(
        "--output_table", help="Output BigQuery Table", default=BIGQUERY_TABLE
    )
    parser.add_argument(
        "--output_schema",
        help="Output BigQuery Schema in text format",
        default=BIGQUERY_SCHEMA,
    )
    known_args, pipeline_args = parser.parse_known_args()

    # Creating pipeline options
    pipeline_options = PipelineOptions(pipeline_args)
    pipeline_options.view_as(StandardOptions).streaming = True

    # Defining our pipeline and its steps
    with beam.Pipeline(options=pipeline_options) as p:
        (
            p
            | "ReadFromPubSub" >> beam.io.gcp.pubsub.ReadFromPubSub(
                subscription=known_args.input_subscription, timestamp_attribute=None
            )
            | "CustomParse" >> beam.ParDo(CustomParsing())
            # | "WriteToGCS" >>  beam.io.WriteToText(file_path_prefix="gs://apsez_dataflow_test/sqlserver_files/original_bq_dbz",file_name_suffix='.txt')
            | "WriteToBigQuery" >> beam.io.WriteToBigQuery(
                known_args.output_table,
                schema=known_args.output_schema,
                write_disposition=beam.io.BigQueryDisposition.WRITE_APPEND,
            )
        )


if __name__ == "__main__":
    run()