import argparse
import json
import os
import logging
import apache_beam as beam
from apache_beam.options.pipeline_options import PipelineOptions, StandardOptions
from google.cloud import storage



client = storage.Client()

logging.basicConfig(level=logging.INFO)
logging.getLogger().setLevel(logging.INFO)

# Service account key path
#os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = "/home/akash_yadav042119/PythonScripts/project-python-330110-8a147dea0659.json"
# INPUT_SUBSCRIPTION = "projects/project-python-330110/subscriptions/streaming_topic_1-sub"
INPUT_SUBSCRIPTION = "projects/apsez-svc-dev-datalake/subscriptions/ENIPPRD.TOS_USR.BTHDTLS_O-sub"

# BIGQUERY_TABLE = "project-python-330110:stream_dataset.streaming_table_1"


BIGQUERY_TABLE = "apsez-svc-dev-datalake:debezium_stg.BTHDTLS_O"
# BIGQUERY_SCHEMA = "timestamp:TIMESTAMP,attr1:FLOAT,msg:STRING"
BIGQUERY_SCHEMA = "ID:INT64,VERSION:INT64,DEL_FLG:STRING,INT_VIA_NO:INT64,CALL_NO:INT64,BERTH_FLG:STRING,UNBERTH_FLG:STRING,MANUAL_ATB_FLG:STRING,MANUAL_ATUB_FLG:STRING,ARR_DRAFT:NUMERIC,DEP_DRAFT:NUMERIC,INT_YD_TMNL_NO:INT64,FM_MM:NUMERIC,TO_MM:NUMERIC,SHIFT_INT_VIA_NO:INT64,FM_BLRD:STRING,TO_BLRD:STRING,BERTH_NO:STRING,BERTH_SIDE:STRING,QUAY_CD:STRING,UNBERTH_REASON_CD:STRING,CMDT_CD:STRING,INVC_LINE_CD:STRING,INT_QUAY_NO:INT64,BERTH_TUG_CNT:INT64,UNBERTH_TUG_CNT:INT64,BERTH_RMRK:STRING,UNBERTH_RMRK:STRING,BERTH_TIDE_LEVEL:NUMERIC,UNBERTH_TIDE_LEVEL:NUMERIC,ARR_DRAFT_FORE:NUMERIC,ARR_DRAFT_AFT:NUMERIC,DEP_DRAFT_FORE:NUMERIC,DEP_DRAFT_AFT:NUMERIC,ATB_DTTM:INT64,ATUB_DTTM:INT64,FIRST_LINE_OUT_DTTM:INT64,LAST_LINE_IN_DTTM:INT64,GANGWAY_UP_DTTM:INT64,GANGWAY_DOWN_DTTM:INT64,ACT_LOCK_ARR_DTTM:INT64,ACT_LOCK_DEP_DTTM:INT64,ADT_INS_DTTM:INT64,ADT_UPD_DTTM:INT64,SPL_EQPT_USED_FLG:STRING,BTH_INVC_DTTM:INT64,PTY_ACCT_CD:STRING,BERTH_DELAY_IND:STRING,ARR_PILOT_OFFBOARD_DTTM:INT64,ARR_PILOT_ONBOARD_DTTM:INT64,ATB_ATUB_DTTM:INT64,BTHG_SIDE_IND:STRING,BTHG_UNBTHG_IND:STRING,FM_LOC:STRING,FM_POS:NUMERIC,FRM_INT_QUAY_NO:INT64,QUAY_SIDE_FLG:STRING,REASON_CD:STRING,TO_INT_QUAY_NO:INT64,TO_LOC:STRING,TO_POS:NUMERIC,TUGS_USED:INT64,ADT_VER_STAMP:INT64,ADT_INS_USR_CD:STRING,ADT_UPD_USR_CD:STRING,ADT_TXN_CD:STRING,ADT_TXN_NO:INT64,ADT_INS_EXT_USR_FLG:STRING,ADT_UPD_EXT_USR_FLG:STRING,DIST_PRPNDCLR_TO_QUAY:NUMERIC,FM_POS_UOM:STRING,TO_POS_UOM:STRING,DIST_PRPNDCLR_TO_QUAY_UOM:STRING,ADT_FUNCTION_CD:STRING,ADT_MODULE_CD:STRING,ADT_INS_USER_NM:STRING,ADT_UPD_USER_NM:STRING,ARCH_IND:STRING,NOR_DTTM:INT64,operation:STRING,msg_published_time:TIMESTAMP"

class CustomParsing(beam.DoFn):
    """ Custom ParallelDo class to apply a custom transformation """
    def to_runner_api_parameter(self, unused_context):
        # Not very relevant, returns a URN (uniform resource name) and the payload
        return "beam:transforms:custom_parsing:custom_v0", None

    def process(self, element: bytes, timestamp=beam.DoFn.TimestampParam, window=beam.DoFn.WindowParam):
        import pandas as pd

        parsed = json.loads(element.decode("utf-8"))
        payload_data = parsed['payload']
        
        intermediate_data = {}
        if payload_data['before'] == None or 'before' not in payload_data:
            intermediate_data = payload_data['after']
            intermediate_data['operation'] = "INSERT"
        elif payload_data['after'] == None or 'after' not in payload_data:
            intermediate_data = payload_data['before']
            intermediate_data['operation'] = "DELETE"    
        else:
            intermediate_data = payload_data['after']
            intermediate_data['operation'] = "UPDATE-INSERT"
            
        df = pd.json_normalize(intermediate_data).to_dict(orient='records')[0]
        df['msg_published_time'] = timestamp.to_rfc3339()
        
        
       
        print(df)
        yield df

def run():
    # Parsing arguments
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--input_subscription",
        help='Input PubSub subscription of the form "projects/<PROJECT>/subscriptions/<SUBSCRIPTION>."',
        default=INPUT_SUBSCRIPTION,
    )
    parser.add_argument(
        "--output_table", help="Output BigQuery Table", default=BIGQUERY_TABLE
    )
    parser.add_argument(
        "--output_schema",
        help="Output BigQuery Schema in text format",
        default=BIGQUERY_SCHEMA,
    )
    known_args, pipeline_args = parser.parse_known_args()

    # Creating pipeline options
    pipeline_options = PipelineOptions(pipeline_args)
    pipeline_options.view_as(StandardOptions).streaming = True

    # Defining our pipeline and its steps
    with beam.Pipeline(options=pipeline_options) as p:
        (
            p
            | "ReadFromPubSub" >> beam.io.gcp.pubsub.ReadFromPubSub(
                subscription=known_args.input_subscription, timestamp_attribute=None
            )
            | "CustomParse" >> beam.ParDo(CustomParsing())
            # | "WriteToGCS" >>  beam.io.WriteToText(file_path_prefix="gs://apsez_dataflow_test/sqlserver_files/original_bq_dbz",file_name_suffix='.txt')
            | "WriteToBigQuery" >> beam.io.WriteToBigQuery(
                known_args.output_table,
                schema=known_args.output_schema,
                write_disposition=beam.io.BigQueryDisposition.WRITE_APPEND,
            )
        )


if __name__ == "__main__":
    run()