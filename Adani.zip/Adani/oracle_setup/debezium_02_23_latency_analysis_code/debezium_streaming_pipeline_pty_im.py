import argparse
import json
import os
import logging
import apache_beam as beam
from apache_beam.options.pipeline_options import PipelineOptions, StandardOptions
from google.cloud import storage



client = storage.Client()

logging.basicConfig(level=logging.INFO)
logging.getLogger().setLevel(logging.INFO)

# Service account key path
#os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = "/home/akash_yadav042119/PythonScripts/project-python-330110-8a147dea0659.json"
# INPUT_SUBSCRIPTION = "projects/project-python-330110/subscriptions/streaming_topic_1-sub"
INPUT_SUBSCRIPTION = "projects/apsez-svc-dev-datalake/subscriptions/ENIPPRD.TOS_USR.PTY_IM-sub"
# BIGQUERY_TABLE = "project-python-330110:stream_dataset.streaming_table_1"


BIGQUERY_TABLE = "apsez-svc-dev-datalake:debezium_stg.PTY_IM"
# BIGQUERY_SCHEMA = "timestamp:TIMESTAMP,attr1:FLOAT,msg:STRING"
BIGQUERY_SCHEMA ="ID:INT64,VERSION:INT64,CMPNY_CD:INT64,PTY_CD:STRING,SHIPPING_AGENT_FLG:STRING,CTR_OPR_FLG:STRING,FRWDR_AGENT_FLG:STRING,CONSHIP_FLG:STRING,HAUL_FLG:STRING,CASH_PTY_FLG:STRING,SEND_EDI_FLG:STRING,DEL_FLG:STRING,INT_EXT_USER_IND:STRING,CRG_AGENT_FLG:STRING,STVDR_FLG:STRING,CSNR_FLG:STRING,SEND_EMAIL_FLG:STRING,SEND_FAX_FLG:STRING,PTY_NM:STRING,ADDR_1:STRING,ADDR_2:STRING,ADDR_3:STRING,ADDR_4:STRING,TEL_NO:STRING,PO_BOX:STRING,FAX_NO:STRING,MOBILE_NO:STRING,EMAIL_ADDR:STRING,CONTACT_PRSN_NM:STRING,CRNCY_CD:STRING,LN_RMRK:STRING,EDI_PTY_CD:STRING,BANK_ACCNT_NO:STRING,BANK_NM:STRING,BANK_EMAIL_ADDR:STRING,BANK_GURANTEE:NUMERIC,DOC_REF_NO:STRING,DOC_S_RMRK:STRING,CRDT_LIMIT:NUMERIC,CRDT_TERM_CD:STRING,CRDT_TERM:INT64,DOC_EXPIRY_DATE:INT64,ADT_INS_DTTM:INT64,ADT_UPD_DTTM:INT64,CSTM_FLG:STRING,MAIN_PTY_CD:STRING,LINE_FLG:STRING,PTY_CLR:INT64,PTY_RESIDENCE_IND:STRING,PTY_ACCT_CD:STRING,TEL_NO_2:STRING,CNTCT_PRSN_NM:STRING,SAP_ACCT_CD:STRING,MARK_DOC_VLDTY_FLG:STRING,INVC_RQRD_FLG:STRING,ADT_VER_STAMP:INT64,ADT_INS_USR_CD:STRING,ADT_UPD_USR_CD:STRING,ADT_FUNCTION_CD:STRING,ADT_MODULE_CD:STRING,ADT_INS_USER_NM:STRING,ADT_UPD_USER_NM:STRING,ADT_TXN_CD:STRING,ADT_TXN_NO:INT64,ADT_INS_EXT_USR_FLG:STRING,ADT_UPD_EXT_USR_FLG:STRING,RFR_CONTRCTR_ID:STRING,RAIL_OPR_FLG:STRING,LOCL_AGENT_FLG:STRING,DEPOT_OPR_FLG:STRING,BANK_CD:STRING,RENTAL_PTY_FLG:STRING,OTH_EMAIL_ADDR:STRING,PAN_NO:STRING,TAN_NO:STRING,SRV_TAX_EXMPT_FLG:STRING,CMPNY_ADDR_1:STRING,CMPNY_ADDR_2:STRING,CMPNY_ADDR_3:STRING,CMPNY_ADDR_4:STRING,CMPNY_PO_BOX:STRING,FINANCIAL_PTY_CD:STRING,PCS_PTY_CD:STRING,PCS_SNDR_CD:STRING,NOTIFY_PTY_FLG:STRING,BASE_STS_SEPARATE_FLG:STRING,FE_IND_SEPARATE_FLG:STRING,PO_BOX_ZIP:STRING,PO_BOX_STATE:STRING,PO_BOX_CITY:STRING,L_RMRK:STRING,CRG_HNDL_INVC_IND:STRING,PYMNT_MODE:STRING,CHECK_LIMIT:NUMERIC,STATE:STRING,COUNTRY:STRING,CMPNY_STATE:STRING,CMPNY_COUNTRY:STRING,LEGAL_ENTITY:STRING,CNTRY_CD:STRING,CMPNY_CNTRY_CD:STRING,MISCPTY_HAULIER_FLG:STRING,SEZ_FLG:STRING,GST_STATE_CD:STRING,GSTIN:STRING,PTY_TYPE:STRING,COMPETITOR_FLG:STRING,LOCL_AGENT_CD:STRING,PD_PTY_FLG:STRING,EXTRA_ADDR:STRING,VAT_CNTRY_CD:STRING,VAT_COUNTRY:STRING,operation:STRING,msg_published_time:STRING"

class CustomParsing(beam.DoFn):
    """ Custom ParallelDo class to apply a custom transformation """
    def to_runner_api_parameter(self, unused_context):
        # Not very relevant, returns a URN (uniform resource name) and the payload
        return "beam:transforms:custom_parsing:custom_v0", None

    def process(self, element: bytes, timestamp=beam.DoFn.TimestampParam, window=beam.DoFn.WindowParam):
        import pandas as pd

        parsed = json.loads(element.decode("utf-8"))
        payload_data = parsed['payload']
        
        intermediate_data = {}
        if payload_data['before'] == None or 'before' not in payload_data:
            intermediate_data = payload_data['after']
            intermediate_data['operation'] = "INSERT"
        elif payload_data['after'] == None or 'after' not in payload_data:
            intermediate_data = payload_data['before']
            intermediate_data['operation'] = "DELETE"    
        else:
            intermediate_data = payload_data['after']
            intermediate_data['operation'] = "UPDATE-INSERT"
            
        df = pd.json_normalize(intermediate_data).to_dict(orient='records')[0]
        df['msg_published_time'] = timestamp.to_rfc3339()
        
        
       
        print(df)
        yield df

def run():
    # Parsing arguments
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--input_subscription",
        help='Input PubSub subscription of the form "projects/<PROJECT>/subscriptions/<SUBSCRIPTION>."',
        default=INPUT_SUBSCRIPTION,
    )
    parser.add_argument(
        "--output_table", help="Output BigQuery Table", default=BIGQUERY_TABLE
    )
    parser.add_argument(
        "--output_schema",
        help="Output BigQuery Schema in text format",
        default=BIGQUERY_SCHEMA,
    )
    known_args, pipeline_args = parser.parse_known_args()

    # Creating pipeline options
    pipeline_options = PipelineOptions(pipeline_args)
    pipeline_options.view_as(StandardOptions).streaming = True

    # Defining our pipeline and its steps
    with beam.Pipeline(options=pipeline_options) as p:
        (
            p
            | "ReadFromPubSub" >> beam.io.gcp.pubsub.ReadFromPubSub(
                subscription=known_args.input_subscription, timestamp_attribute=None
            )
            | "CustomParse" >> beam.ParDo(CustomParsing())
            # | "WriteToGCS" >>  beam.io.WriteToText(file_path_prefix="gs://apsez_dataflow_test/sqlserver_files/original_bq_dbz",file_name_suffix='.txt')
            | "WriteToBigQuery" >> beam.io.WriteToBigQuery(
                known_args.output_table,
                schema=known_args.output_schema,
                write_disposition=beam.io.BigQueryDisposition.WRITE_APPEND,
            )
        )


if __name__ == "__main__":
    run()