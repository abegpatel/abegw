import argparse
import json
import os
import logging
import apache_beam as beam
from apache_beam.options.pipeline_options import PipelineOptions, StandardOptions
from google.cloud import storage



client = storage.Client()

logging.basicConfig(level=logging.INFO)
logging.getLogger().setLevel(logging.INFO)

# Service account key path
#os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = "/home/akash_yadav042119/PythonScripts/project-python-330110-8a147dea0659.json"
# INPUT_SUBSCRIPTION = "projects/project-python-330110/subscriptions/streaming_topic_1-sub"
INPUT_SUBSCRIPTION = "projects/apsez-svc-dev-datalake/subscriptions/ENIPPRD.TOS_USR.OPRNLEQPT_OCM-sub"
# BIGQUERY_TABLE = "project-python-330110:stream_dataset.streaming_table_1"


BIGQUERY_TABLE = "apsez-svc-dev-datalake:debezium_stg.OPRNLEQPT_OCM"
# BIGQUERY_SCHEMA = "timestamp:TIMESTAMP,attr1:FLOAT,msg:STRING"
BIGQUERY_SCHEMA ="INT_OPRNL_EQPT_NO:integer,OPRNL_EQPT_NM:string,OPRNL_EQPT_TYPE:string,OPRNL_EQPT_STS:string,MAX_LIFTG_HT:integer,MAX_LIFTG_HT_UOM:string,MAX_PULG_CPCTY:integer,MAX_PULG_CPCTY_UOM:string,MAX_WT_LIFT_CPCTY:integer,MAX_WT_LIFT_CPCTY_UOM:string,TRVL_SPEED:integer,TRVL_SPEED_UOM:string,TL_FLG:string,QUAY_CRANE_RLTV_POS:integer,ADJ_HT_SPRDR_FLG:string,BOOM_DOWN_TM:integer,BOOM_DOWN_TM_UOM:string,BOOM_UP_TM:integer,BOOM_UP_TM_UOM:string,OUTREACH:float64,OUTREACH_UOM:string,DIST_BTWN_LEGS:float64,DIST_BTWN_LEGS_UOM:string,FM_POS:float64,FM_POS_UOM:string,TO_POS:float64,TO_POS_UOM:string,OVR_BUFF_LEN:float64,OVR_BUFF_LEN_UOM:string,INT_PARENT_OPRNL_EQPT_NO:integer,MAX_SPRDR_HT_DIFF:float64,MAX_SPRDR_HT_DIFF_UOM:string,MAX_SPRDR_WT_DIFF:float64,MAX_SPRDR_WT_DIFF_UOM:string,TL_SPRDR_FLG:string,TL_ONLY_FE_IND:string,TL_DK_FLG:string,DEL_FLG:string,INT_TMNL_NO:integer,ADT_VER_STAMP:integer,ADT_INS_USR_CD:string,ADT_INS_DTTM:integer,ADT_INS_EXT_USR_FLG:string,ADT_UPD_USR_CD:string,ADT_UPD_DTTM:integer,ADT_UPD_EXT_USR_FLG:string,ADT_TXN_CD:string,ADT_TXN_NO:integer,AVLBL_FLG:string,CHASSIS_SIZE:integer,CMPNY_CD:integer,CNTRCTR_CD:string,EQPT_CHRG_RATE:float64,EQPT_POSN:string,EQPT_RATE:integer,EQPT_REG_NO:string,INTRNL_EXT_IND:string,INT_CMPNY_NO:integer,IN_PORT_FLG:string,LIFTING_CPCTY:float64,MACHINE_HT:float64,MACHINE_LEN:float64,MACHINE_WD:float64,MACHINE_WT:float64,MAX_STKNG:integer,PURCHASE_DTTM:integer,SIZE_IND:string,S_DESCR:string,S_RMRK:string,TRIP_CNT:integer,UOM_CD:string,OPRNL_EQPT_S_DESCR:string,RDT_DEVICE_NM:string,MAKE:string,MODEL:string,RF_TAG_ID:string,IS_RMG_FLG:string,RDT_DEVICE_NM_2:string,RDT_INSTLN_IND:string,RDT_INSTLN_IND_2:string,LANE_ID:string,SPL_INT_OPRNL_EQPT_NO:integer,SPL_OPRNL_EQPT_TYPE:string,EQPT_TWIN_RATE:integer,ID:integer,VERSION:integer,ORG_EQPT_TYPE:string,RENT_EQPT_FLG:string,PDS_INF_FLG:string,WT_BRDG_INTFC:string,operation:string,msg_published_time:TIMESTAMP"

class CustomParsing(beam.DoFn):
    """ Custom ParallelDo class to apply a custom transformation """
    def to_runner_api_parameter(self, unused_context):
        # Not very relevant, returns a URN (uniform resource name) and the payload
        return "beam:transforms:custom_parsing:custom_v0", None

    def process(self, element: bytes, timestamp=beam.DoFn.TimestampParam, window=beam.DoFn.WindowParam):
        import pandas as pd

        parsed = json.loads(element.decode("utf-8"))
        payload_data = parsed['payload']
        
        intermediate_data = {}
        if payload_data['before'] == None or 'before' not in payload_data:
            intermediate_data = payload_data['after']
            intermediate_data['operation'] = "INSERT"
        elif payload_data['after'] == None or 'after' not in payload_data:
            intermediate_data = payload_data['before']
            intermediate_data['operation'] = "DELETE"    
        else:
            intermediate_data = payload_data['after']
            intermediate_data['operation'] = "UPDATE-INSERT"
            
        df = pd.json_normalize(intermediate_data).to_dict(orient='records')[0]
        df['msg_published_time'] = timestamp.to_rfc3339()
        
        
       
        print(df)
        yield df

def run():
    # Parsing arguments
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--input_subscription",
        help='Input PubSub subscription of the form "projects/<PROJECT>/subscriptions/<SUBSCRIPTION>."',
        default=INPUT_SUBSCRIPTION,
    )
    parser.add_argument(
        "--output_table", help="Output BigQuery Table", default=BIGQUERY_TABLE
    )
    parser.add_argument(
        "--output_schema",
        help="Output BigQuery Schema in text format",
        default=BIGQUERY_SCHEMA,
    )
    known_args, pipeline_args = parser.parse_known_args()

    # Creating pipeline options
    pipeline_options = PipelineOptions(pipeline_args)
    pipeline_options.view_as(StandardOptions).streaming = True

    # Defining our pipeline and its steps
    with beam.Pipeline(options=pipeline_options) as p:
        (
            p
            | "ReadFromPubSub" >> beam.io.gcp.pubsub.ReadFromPubSub(
                subscription=known_args.input_subscription, timestamp_attribute=None
            )
            | "CustomParse" >> beam.ParDo(CustomParsing())
            # | "WriteToGCS" >>  beam.io.WriteToText(file_path_prefix="gs://apsez_dataflow_test/sqlserver_files/original_bq_dbz",file_name_suffix='.txt')
            | "WriteToBigQuery" >> beam.io.WriteToBigQuery(
                known_args.output_table,
                schema=known_args.output_schema,
                write_disposition=beam.io.BigQueryDisposition.WRITE_APPEND,
            )
        )


if __name__ == "__main__":
    run()