import argparse
import json
import os
import logging
import apache_beam as beam
from apache_beam.options.pipeline_options import PipelineOptions, StandardOptions
from google.cloud import storage



client = storage.Client()

logging.basicConfig(level=logging.INFO)
logging.getLogger().setLevel(logging.INFO)

# Service account key path
#os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = "/home/akash_yadav042119/PythonScripts/project-python-330110-8a147dea0659.json"
# INPUT_SUBSCRIPTION = "projects/project-python-330110/subscriptions/streaming_topic_1-sub"
INPUT_SUBSCRIPTION = "projects/apsez-svc-dev-datalake/subscriptions/ENIPPRD.TOS_USR.VOYDTLS_O-sub"
# BIGQUERY_TABLE = "project-python-330110:stream_dataset.streaming_table_1"


BIGQUERY_TABLE = "apsez-svc-dev-datalake:debezium_stg.VOYDTLS_O"
# BIGQUERY_SCHEMA = "timestamp:TIMESTAMP,attr1:FLOAT,msg:STRING"
BIGQUERY_SCHEMA ="ID:integer,VERSION:integer,DEL_FLG:string,ATHWART_STOWED_FLG:string,BERTH_PRIORITY:string,CNSRTM_CD:string,DSCH_LD_BOTH_IND:string,DSCH_TRADE_CD:string,EXT_VOY_FLG:string,IS_VSL_DEFD_FLG:string,LD_MNF_CLOSE_FLG:string,LD_ROUTE_CD:string,LD_TRADE_CD:string,MAIN_LINE_CD:string,SAILD_FLG:string,VIA_NO:string,VSL_CD:string,VSL_NM:string,VSL_OVR_LEN:float64,VSL_TYPE:string,VSL_WK_COMPLT_INT_USER_ID:integer,MAIDEN_FLG:string,MOTHER_FEEDER_BARGE_IND:string,DEFN_STAGE_IND:string,VSL_MAX_HT:float64,MRN_CLOSURE_INT_USER_ID:integer,VOY_TRANSIT_FLG:string,INT_YD_TMNL_NO:integer,MRN_CLOSURE_FLG:string,LD_VOY_NO:string,DSCH_VOY_NO:string,ATA_DTTM:integer,ATB_DTTM:integer,ATD_DTTM:integer,ATUB_DTTM:integer,ETA_DTTM:integer,ETD_DTTM:integer,VOY_REG_DTTM:integer,VSL_WK_COMPLT_DTTM:integer,MRN_CLOSURE_DTTM:integer,CFS_CLOSURE_DTTM:integer,LEGACY_IMP_VOY_NO:string,LEGACY_EXP_VOY_NO:string,CFS_CLOSURE_INT_USER_ID:integer,ADT_INS_DTTM:integer,ADT_UPD_DTTM:integer,MOORNG_START_DTTM:integer,MOORNG_END_DTTM:integer,UNMOORNG_START_DTTM:integer,UNMOORNG_END_DTTM:integer,EBF_PLN_FLG:string,WT_VLDT_FLG:string,ROAD_RCPT_FLG:string,CHRGBL_DWT:integer,DEAD_WT:integer,GT:integer,VSL_BEAM:integer,DISPLACEMENT:integer,CHRGBL_QTY_IND:string,CRG_INVC_CLOSURE_DTTM:integer,CRG_INVC_CLOSURE_INT_USER_ID:integer,CRG_VSL_WK_COMPLT_DTTM:integer,CRG_VSL_WK_COMPLT_INT_USER_ID:integer,CTR_INVC_CLOSURE_DTTM:integer,CTR_INVC_CLOSURE_INT_USER_ID:integer,IC_INVC_CLOSURE_DTTM:integer,IC_INVC_CLOSURE_INT_USER_ID:integer,MRN_INVC_CLOSURE_DTTM:integer,MRN_INVC_CLOSURE_INT_USER_ID:integer,OPRN_COMPLT_DTTM:integer,OPRN_COMPLT_INT_USER_ID:integer,QUALIFIER_CD:string,VSL_CAT_CD:string,INT_VSL_CD:integer,VSL_OPR:string,EIB_IND:string,ARR_DFT_AFT_UOM:string,ARR_DFT_FRWD:float64,ARR_DFT_FRWD_UOM:string,CFS_CUT_OFF_DTTM:integer,CFS_START_RECVL_DTTM:integer,CMPRMT_COUNT:integer,CMPRMT_DIRN:string,CRG_CUT_OFF_DTTM:integer,CRG_START_RECVL_DTTM:integer,CRG_STRG_START_DTTM:integer,CRUISE_TYPE:string,CTR_FREE_STRG_DTTM:integer,DELVRY_OFF_CD:string,DEP_DFT_AFT:float64,DEP_DFT_AFT_UOM:string,DEP_DFT_FWD:float64,DEP_DFT_FWD_UOM:string,DOC_REF_NO:string,ETA_CUT_OFF_DTTM:integer,FIRST_AVLB_DT:integer,GATE_RECVL_CUT_OFF_DTTM:integer,INT_PAC_NO:integer,MAX_CRANE_COUNT:integer,RECVL_OFF_CD:string,RECVL_PRE_ADVICE_CUT_OFF_DTTM:integer,SRV_CD:string,START_RECVL_DTTM:integer,SH_RMRK:string,SH_REM:string,TEL_NO:string,TRAIN_CUT_OFF_HRS:float64,USE_SHP_CRANE_FLG:string,VOY_PRIO:integer,VOY_SKPR:string,VOY_STS_IND:string,VSL_CATY:string,VSL_OPRN_TYPE:string,VSL_REGY_NO:string,VWR_CRG_DTTM:integer,WT_CATY_GRP_CD:string,YELLOW_FVR_FLG:string,ADT_VER_STAMP:integer,ADT_INS_USR_CD:string,ADT_UPD_USR_CD:string,ADT_TXN_CD:string,ADT_TXN_NO:integer,ADT_INS_EXT_USR_FLG:string,ADT_UPD_EXT_USR_FLG:string,VSL_WK_UNMARK_INT_USER_ID:integer,VSL_WK_UNMARK_DTTM:integer,VSL_WK_UNMARK_RMRK:string,BERTH_SIDE:string,CTR_WT:float64,TOT_EIR_CNT:integer,TOT_EIR_TEU:integer,INBOUND_FOREIGN_COASTAL_IND:string,OUTBOUND_FOREIGN_COASTAL_IND:string,EGM_ROT_NO:string,IGM_ROT_NO:string,PRESTOW_PLN_FLG:string,CTR_PLNG_FLG:string,ISPS_LEVEL:string,FLAP_NO:integer,LN_RMRK:string,ADT_FUNCTION_CD:string,ADT_MODULE_CD:string,ADT_INS_USER_NM:string,ADT_UPD_USER_NM:string,INT_VIA_NO:integer,ARR_DFT_AFT:float64,INT_ETA_QUALIFIER:integer,L_RMRK:string,ARCH_IND:string,CSTM_VIA_NO:string,PLN_LOCK_FLG:string,PLN_LOCK_RQRD_FLG:string,EXP_RESTOW_CNT:integer,EXP_LOAD_RFR_CNT:integer,EXP_LOAD_CNT:integer,EXP_DSCH_CNT:integer,EXP_DSCH_RFR_CNT:integer,MOORING_SRV_RQRD_FLG:string,ID_USERDDTLS_AWR_CNFM:integer,AWR_CNFM_RMRK:string,AWR_CNFM_DTTM:integer,WIN_DAY:string,WIN_TM:string,BUNKER_VSL_FLG:string,EGM_DTTM:integer,EGM_RMRK:string,IGM_DTTM:integer,IGM_RMRK:string,DUMMY_VOY_FLG:string,TUG_GRT:integer,TUG_NRT:integer,TUG_GRT_NRT_UOM:string,TPC:float64,BAND_NM:string,operation:string,msg_published_time:TIMESTAMP"

class CustomParsing(beam.DoFn):
    """ Custom ParallelDo class to apply a custom transformation """
    def to_runner_api_parameter(self, unused_context):
        # Not very relevant, returns a URN (uniform resource name) and the payload
        return "beam:transforms:custom_parsing:custom_v0", None

    def process(self, element: bytes, timestamp=beam.DoFn.TimestampParam, window=beam.DoFn.WindowParam):
        import pandas as pd

        parsed = json.loads(element.decode("utf-8"))
        payload_data = parsed['payload']
        
        intermediate_data = {}
        if payload_data['before'] == None or 'before' not in payload_data:
            intermediate_data = payload_data['after']
            intermediate_data['operation'] = "INSERT"
        elif payload_data['after'] == None or 'after' not in payload_data:
            intermediate_data = payload_data['before']
            intermediate_data['operation'] = "DELETE"    
        else:
            intermediate_data = payload_data['after']
            intermediate_data['operation'] = "UPDATE-INSERT"
            
        df = pd.json_normalize(intermediate_data).to_dict(orient='records')[0]
        df['msg_published_time'] = timestamp.to_rfc3339()
        
        
       
        print(df)
        yield df

def run():
    # Parsing arguments
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--input_subscription",
        help='Input PubSub subscription of the form "projects/<PROJECT>/subscriptions/<SUBSCRIPTION>."',
        default=INPUT_SUBSCRIPTION,
    )
    parser.add_argument(
        "--output_table", help="Output BigQuery Table", default=BIGQUERY_TABLE
    )
    parser.add_argument(
        "--output_schema",
        help="Output BigQuery Schema in text format",
        default=BIGQUERY_SCHEMA,
    )
    known_args, pipeline_args = parser.parse_known_args()

    # Creating pipeline options
    pipeline_options = PipelineOptions(pipeline_args)
    pipeline_options.view_as(StandardOptions).streaming = True

    # Defining our pipeline and its steps
    with beam.Pipeline(options=pipeline_options) as p:
        (
            p
            | "ReadFromPubSub" >> beam.io.gcp.pubsub.ReadFromPubSub(
                subscription=known_args.input_subscription, timestamp_attribute=None
            )
            | "CustomParse" >> beam.ParDo(CustomParsing())
            # | "WriteToGCS" >>  beam.io.WriteToText(file_path_prefix="gs://apsez_dataflow_test/sqlserver_files/original_bq_dbz",file_name_suffix='.txt')
            | "WriteToBigQuery" >> beam.io.WriteToBigQuery(
                known_args.output_table,
                schema=known_args.output_schema,
                write_disposition=beam.io.BigQueryDisposition.WRITE_APPEND,
            )
        )


if __name__ == "__main__":
    run()