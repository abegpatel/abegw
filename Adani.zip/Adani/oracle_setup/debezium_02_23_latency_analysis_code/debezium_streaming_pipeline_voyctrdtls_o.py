import argparse
import json
import os
import logging
import apache_beam as beam
from apache_beam.options.pipeline_options import PipelineOptions, StandardOptions
from google.cloud import storage



client = storage.Client()

logging.basicConfig(level=logging.INFO)
logging.getLogger().setLevel(logging.INFO)

# Service account key path
#os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = "/home/akash_yadav042119/PythonScripts/project-python-330110-8a147dea0659.json"
# INPUT_SUBSCRIPTION = "projects/project-python-330110/subscriptions/streaming_topic_1-sub"
INPUT_SUBSCRIPTION = "projects/apsez-svc-dev-datalake/subscriptions/ENIPPRD.TOS_USR.VOYCTRDTLS_O-sub"
# BIGQUERY_TABLE = "project-python-330110:stream_dataset.streaming_table_1"


BIGQUERY_TABLE = "apsez-svc-dev-datalake:debezium_stg.VOYCTRDTLS_O"
# BIGQUERY_SCHEMA = "timestamp:TIMESTAMP,attr1:FLOAT,msg:STRING"
BIGQUERY_SCHEMA ="CTR_NO:string,DSCH_LD_LST_PRINT_FLG:string,DSCH_LD_ROB_IND:string,INT_VIA_NO:integer,LIFE_NO:integer,RESTOW_FLG:string,RESTOW_TYPE:string,VSL_BAY_NO:string,VSL_ROW_NO:string,VSL_SUB_TIER_NO:integer,VSL_TIER_NO:string,WT_CAT_DEFN_CD:string,WT_CAT:string,DK_UD_IND:string,ATHWART_STOWED_FLG:string,CONFIRM_FLG:string,MNF_DTTM:integer,ADT_INS_DTTM:integer,ADT_UPD_DTTM:integer,SHIP_CRN_FLG:string,ADT_VER_STAMP:integer,ADT_INS_USR_CD:string,ADT_UPD_USR_CD:string,ADT_TXN_CD:string,ADT_TXN_NO:integer,ADT_INS_EXT_USR_FLG:string,ADT_UPD_EXT_USR_FLG:string,INT_CTR_NO:integer,EQPT_IND:string,INVC_PTY_CD:string,RFR_INVC_PTY_CD:string,INVC_BASE_STS:integer,operation:string,msg_published_time:TIMESTAMP"
class CustomParsing(beam.DoFn):
    """ Custom ParallelDo class to apply a custom transformation """
    def to_runner_api_parameter(self, unused_context):
        # Not very relevant, returns a URN (uniform resource name) and the payload
        return "beam:transforms:custom_parsing:custom_v0", None

    def process(self, element: bytes, timestamp=beam.DoFn.TimestampParam, window=beam.DoFn.WindowParam):
        import pandas as pd

        parsed = json.loads(element.decode("utf-8"))
        payload_data = parsed['payload']
        
        intermediate_data = {}
        if payload_data['before'] == None or 'before' not in payload_data:
            intermediate_data = payload_data['after']
            intermediate_data['operation'] = "INSERT"
        elif payload_data['after'] == None or 'after' not in payload_data:
            intermediate_data = payload_data['before']
            intermediate_data['operation'] = "DELETE"    
        else:
            intermediate_data = payload_data['after']
            intermediate_data['operation'] = "UPDATE-INSERT"
            
        df = pd.json_normalize(intermediate_data).to_dict(orient='records')[0]
        df['msg_published_time'] = timestamp.to_rfc3339()
        
        
       
        print(df)
        yield df

def run():
    # Parsing arguments
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--input_subscription",
        help='Input PubSub subscription of the form "projects/<PROJECT>/subscriptions/<SUBSCRIPTION>."',
        default=INPUT_SUBSCRIPTION,
    )
    parser.add_argument(
        "--output_table", help="Output BigQuery Table", default=BIGQUERY_TABLE
    )
    parser.add_argument(
        "--output_schema",
        help="Output BigQuery Schema in text format",
        default=BIGQUERY_SCHEMA,
    )
    known_args, pipeline_args = parser.parse_known_args()

    # Creating pipeline options
    pipeline_options = PipelineOptions(pipeline_args)
    pipeline_options.view_as(StandardOptions).streaming = True

    # Defining our pipeline and its steps
    with beam.Pipeline(options=pipeline_options) as p:
        (
            p
            | "ReadFromPubSub" >> beam.io.gcp.pubsub.ReadFromPubSub(
                subscription=known_args.input_subscription, timestamp_attribute=None
            )
            | "CustomParse" >> beam.ParDo(CustomParsing())
            # | "WriteToGCS" >>  beam.io.WriteToText(file_path_prefix="gs://apsez_dataflow_test/sqlserver_files/original_bq_dbz",file_name_suffix='.txt')
            | "WriteToBigQuery" >> beam.io.WriteToBigQuery(
                known_args.output_table,
                schema=known_args.output_schema,
                write_disposition=beam.io.BigQueryDisposition.WRITE_APPEND,
            )
        )


if __name__ == "__main__":
    run()