import argparse
import json
import os
import logging
import apache_beam as beam
from apache_beam.options.pipeline_options import PipelineOptions, StandardOptions
from google.cloud import storage
from google.cloud import bigquery
import pandas as pd

from google.cloud import bigquery_storage_v1
from google.cloud.bigquery_storage_v1 import types
from google.cloud.bigquery_storage_v1 import writer
from google.protobuf import descriptor_pb2

#import test_employee_pb2


logging.basicConfig(level=logging.INFO)
logging.getLogger().setLevel(logging.INFO)

os.environ["GOOGLE_APPLICATION_CREDENTIALS"]="apsez-svc-dev-datalake.json"
INPUT_SUBSCRIPTION = "projects/apsez-svc-dev-datalake/subscriptions/CT1IPUAT.ANALYTICS_USER1.TEST_TABLES1-sub"



# Storage API Code

class CustomParsing(beam.DoFn):
    """ Custom ParallelDo class to apply a custom transformation """
    def to_runner_api_parameter(self, unused_context):
        return "beam:transforms:custom_parsing:custom_v0", None
    def setup(self):
        try:
            logging.info('copying files')
            from google.cloud import bigquery_storage_v1
            from google.cloud.bigquery_storage_v1 import types
            from google.cloud.bigquery_storage_v1 import writer
            from google.protobuf import descriptor_pb2
            import pandas as pd
            import test_employee_pb2
            import test_customers_pb2

            table_list = ['test_employee','test_customers'] 
            for table_name_list in table_list:
                logging.info('Setup file- copying .py files on machine')   
                os.environ["var"] = table_name_list 
                os.system('if [ ! -f ${var}_pb2.py ]; then gsutil cp gs://apsez_dataflow_test/dataflow_test_code/${var}_pb2.py . && chmod 777 ${var}_pb2.py; fi')
                #os.system('if [ ! -f test_employee_pb2.py ]; then gsutil cp gs://apsez_dataflow_test/dataflow_test_code/test_employee_pb2.py . && chmod 777 test_employee_pb2.py; fi')
                #os.system('if [ ! -f test_customers_pb2.py ]; then gsutil cp gs://apsez_dataflow_test/dataflow_test_code/test_customers_pb2.py . && chmod 777 test_customers_pb2.py; fi')
                logging.info('File Copied')
        except Exception as e:
            logging.exception(e)
            raise
    def process(self, element: bytes, timestamp=beam.DoFn.TimestampParam):
        from google.cloud import bigquery_storage_v1
        from google.cloud.bigquery_storage_v1 import types
        from google.cloud.bigquery_storage_v1 import writer
        from google.protobuf import descriptor_pb2
        import pandas as pd

        #BQ TABLE NAME CREATIOn
        
        parsed = json.loads(element.decode("utf-8"))
        payload_data = parsed['payload']
        dataset_id = payload_data['source']['schema']
        table_id = payload_data['source']['table']
        project_id = "apsez-svc-dev-datalake"
        
        #import_pb2_files=['test_employee','test_customers']
        #import test_employee_pb2
        #import test_customers_pb2
        #for i in import_pb2_files: 
        #   logging.info('start importing files....')  
        #   import_file=i+'_pb2'
        #   exec('import '+str(import_file))		
        #   logging.info('import files command executed')

	#Create a write stream, write some sample data, and commit the stream.

        write_client = bigquery_storage_v1.BigQueryWriteClient()
        parent = write_client.table_path(project_id, dataset_id, table_id)
        write_stream = types.WriteStream()
        
        write_stream.type_ = types.WriteStream.Type.PENDING
        write_stream = write_client.create_write_stream(parent=parent, write_stream=write_stream)
        stream_name = write_stream.name

	# Create a template wiith fields needed for the first request.
        request_template = types.AppendRowsRequest()

	# The initial request must contain the stream name.
        request_template.write_stream = stream_name

	# So that BigQuery knows how to parse the serialized_rows, generate a
	# protocol buffer representation of your message descriptor.
        proto_schema = types.ProtoSchema()
        proto_descriptor = descriptor_pb2.DescriptorProto()
        

        #tablename = []
        #for j in import_pb2_files:
        
        tablefullname = str(table_id).lower()+'_pb2.'+str(table_id)+'_RECORD'
        logging.info(tablefullname)
        eval(str(tablefullname)+'.DESCRIPTOR.CopyToProto(proto_descriptor)')
        

        proto_schema.proto_descriptor = proto_descriptor
        proto_data = types.AppendRowsRequest.ProtoData()
        proto_data.writer_schema = proto_schema
        request_template.proto_rows = proto_data
        append_rows_stream = writer.AppendRowsStream(write_client, request_template)
        proto_rows = types.ProtoRows()

	# DATA EXTRACTION
		
        intermediate_data = {}
        if payload_data['before'] == None or 'before' not in payload_data:
            intermediate_data = payload_data['after']
            intermediate_data['OPERATION'] = "INSERT"
        elif payload_data['after'] == None or 'after' not in payload_data:
            intermediate_data = payload_data['before']
            intermediate_data['OPERATION'] = "DELETE"
        else:
            intermediate_data = payload_data['after']
            intermediate_data['OPERATION'] = "UPDATE-INSERT"

        

	# DATA INSERATION
        row = eval(str(tablefullname)+'()')
        logging.info(row)
        for k,v in intermediate_data.items():
            exec('row.'+str(k)+'='+'v')


        row.MSG_PUBLISHED_TIME = int(timestamp)
 
        proto_rows.serialized_rows.append(row.SerializeToString())

	# PROTO BUFFER
        request = types.AppendRowsRequest()
        request.offset = 0
        proto_data = types.AppendRowsRequest.ProtoData()
        proto_data.rows = proto_rows
        request.proto_rows = proto_data
        
        response_future_1 = append_rows_stream.send(request)

        #append_rows_stream.close()
        
        write_client.finalize_write_stream(name=write_stream.name)

	# Commit the stream you created earlier.
        
        batch_commit_write_streams_request = types.BatchCommitWriteStreamsRequest()
        batch_commit_write_streams_request.parent = parent
        batch_commit_write_streams_request.write_streams = [write_stream.name]
        write_client.batch_commit_write_streams(batch_commit_write_streams_request)
        logging.info(f"Writes to stream: '{write_stream.name}' have been committed.")
def run():
    # Parsing arguments
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--input_subscription",
        help='Input PubSub subscription of the form "projects/<PROJECT>/subscriptions/<SUBSCRIPTION>."',
        default=INPUT_SUBSCRIPTION,
    )
   
    known_args, pipeline_args = parser.parse_known_args()
    # Creating pipeline options
    pipeline_options = PipelineOptions(pipeline_args)
    pipeline_options.view_as(StandardOptions).streaming = True
    # Defining our pipeline and its steps
    with beam.Pipeline(options=pipeline_options) as p:
      input_data = ( p | "ReadFromPubSub" >> beam.io.gcp.pubsub.ReadFromPubSub(subscription=known_args.input_subscription, timestamp_attribute=None))
      Stagging_Table  = ( input_data | "StaggingTable" >> beam.ParDo(CustomParsing()))
                                     
if __name__ == "__main__":
    run()

