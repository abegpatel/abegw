from google.cloud import bigquery
import apache_beam as beam
from apache_beam.options.pipeline_options import StandardOptions,PipelineOptions
import logging
#client = bigquery.Client()
#query = """CALL debezium_replica.debezium_test_replica_creator_ctrdtls_o()"""
#job = client.query(query)
#print("Executed")

class setenv(beam.DoFn): 
    def process(self,element):
        os.system('pip3 install google-cloud-bigquery')
        from google.cloud import bigquery
        client = bigquery.Client()
        query = """CALL debezium_replica.debezium_test_replica_creator_ctrdtls_o()"""
        job = client.query(query)
        print("Executed")

def run():
    try:
        options = PipelineOptions()
        pcoll = beam.Pipeline(options = options)
        dummy = pcoll | 'Initializing..' >> beam.Create(['1'])
        Data = (dummy | 'Setting up Instance..' >> beam.ParDo(setenv())  )

    except:
        logging.exception('Failed to launch datapipeline')
        raise

def main():
    logging.getLogger().setLevel(logging.INFO)
    run()
    
if __name__ == '__main__':
    main()
