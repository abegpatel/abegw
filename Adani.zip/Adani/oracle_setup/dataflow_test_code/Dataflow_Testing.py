import apache_beam as beam
from apache_beam.options.pipeline_options import PipelineOptions, StandardOptions
import logging
import requests


class readfromdatabase(beam.DoFn):
    def process(self,element):
        import requests
        x = requests.get('https://files.pythonhosted.org/packages/cc/fe/2dd1079087f8cd41a915ad96bcf3f4af81aec6554e4041d2b9e04662b02e/pymssql-2.2.3.tar.gz')
        print(f"URL ACCESSED : {x}")

        
def run():
    try:    
        options = PipelineOptions()
        pcoll = beam.Pipeline(options = options)
        dummy = pcoll | 'Initializing..' >> beam.Create(['1'])
        Data = (dummy | 'Extracting_Data_From_MSSQL' >> beam.ParDo(readfromdatabase())
                )
        # Write_To_GCS = (Data 
        #                 | 'WriteToGCS' >>  beam.io.WriteToText(file_path_prefix="gs://apsez_dataflow_test/sqlserver_files/test",file_name_suffix='.txt')
        #                 #   | 'WiteToGcs' >> beam.io.WriteToFiles(path=tgt_gcs_location,file_naming=tgt_table_pattern+DT+'.txt')
        #                )
        # Write_To_BQ = (Data 
        #                | 'WriteToBQ' >> beam.io.WriteToBigQuery(tgt_table_pattern,project = "" ,dataset = tgt_dataset_pattern,schema=tgt_schema_pattern,custom_gcs_temp_location='gs://example_project_python/temp',create_disposition=beam.io.BigQueryDisposition.CREATE_IF_NEEDED,write_disposition=beam.io.BigQueryDisposition.WRITE_APPEND)
        #                )
        p = pcoll.run()
        logging.info('Job Run Successfully!')
        p.wait_until_finish()
    except:
        logging.exception('Failed to launch datapipeline')
        raise

def main():
    logging.getLogger().setLevel(logging.INFO)
    run()
    
if __name__ == '__main__':
    main()