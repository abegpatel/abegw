import apache_beam as beam
import cx_Oracle
import argparse
import pandas as pd
from oauth2client.client import GoogleCredentials
from apache_beam.options.pipeline_options import PipelineOptions, StandardOptions
import json
import logging
import os
import datetime


class readfromdatabase(beam.DoFn):
    def process(self,element):
            import cx_Oracle
            import pandas as pd
        
     
 
            con = cx_Oracle.connect('ANALYTICS_USER1/analytics#user1@10.6.63.212:1521/AMCTDR')
            print(con.version)
        
            # Now execute the sqlquery
            cursor = con.cursor()
        
            # Creating a table employee
            cursor.execute("select * from tos_usr.ACGRP_YP fetch first 5 rows only")
        
            data = cursor.fetchall()
            logging.info('printing data')
            print(data)   
            logging.info(data)
            #sql_query = pd.read_sql(query_pattern, mydb)
            df = pd.DataFrame(data,index=None)
            df2 = df.to_dict('records')
            print(df2)
            return df2
          
       

def run():
    try:    
        options = PipelineOptions()
        pcoll = beam.Pipeline(options = options)
        dummy = pcoll | 'Initializing..' >> beam.Create(['1'])
        Data = (dummy | 'Extracting_Data_From_Oracle' >> beam.ParDo(readfromdatabase())
                )
        Write_To_GCS = (Data 
                        | 'WriteToGCS' >>  beam.io.WriteToText(file_path_prefix="gs://apsez_dataflow_test/sqlserver_files/oracle",file_name_suffix='.txt')
                        #   | 'WiteToGcs' >> beam.io.WriteToFiles(path=tgt_gcs_location,file_naming=tgt_table_pattern+DT+'.txt')
                       )
        # Write_To_BQ = (Data 
        #                | 'WriteToBQ' >> beam.io.WriteToBigQuery(tgt_table_pattern,project = "" ,dataset = tgt_dataset_pattern,schema=tgt_schema_pattern,custom_gcs_temp_location='gs://example_project_python/temp',create_disposition=beam.io.BigQueryDisposition.CREATE_IF_NEEDED,write_disposition=beam.io.BigQueryDisposition.WRITE_APPEND)
        #                )
        p = pcoll.run()
        logging.info('Job Run Successfully!')
        p.wait_until_finish()
    except:
        logging.exception('Failed to launch datapipeline')
        raise

def main():
    logging.getLogger().setLevel(logging.INFO)
    run()
    
if __name__ == '__main__':
    main()
