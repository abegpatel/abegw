from google.cloud import bigquery
import re

client = bigquery.Client()

query = "Select table_name from `apsez-svc-dev-datalake`.gg_staging_dev.INFORMATION_SCHEMA.TABLES"
query_job = client.query(query)

print("The Query Data:")

table_list = []
for row in query_job:
    table_list.append(row["table_name"])

ddl_list = []

for table in table_list:
    query = f"Select ddl from `apsez-svc-dev-datalake`.gg_staging_dev.INFORMATION_SCHEMA.TABLES where table_name = '{table}'"
    tblname = table.split('IPOS_CT2_')[1].lower()
    print(tblname)
    query_job = client.query(query)
    for row in query_job:
        ddl = row["ddl"]
        print(type(ddl))
        ddl = re.sub(r";","PARTITION BY DATE(timestamp);",ddl)
        ddl = re.sub(r"apsez-svc-dev-datalake.gg_staging_dev.","apsez-svc-dev-datalake.gg_staging.",ddl)
        ddl = re.sub(r"CREATE TABLE","CREATE TABLE IF NOT EXISTS",ddl)
        ddl = ddl.replace("timestamp STRING","timestamp TIMESTAMP")
        ddl = re.sub(r"IPOS_CT2_[A-Z]*[_]?[A-Z]*?[`]",f"gg_ct2_{tblname}`",ddl)
        ddl_list.append(ddl)

for ddl in ddl_list:
    print(ddl)
    query_job = client.query(ddl)
    print(query_job)
#print(ddl_list)
