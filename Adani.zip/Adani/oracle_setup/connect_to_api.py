import requests
import json
import csv
import pandas as pd
from pandas.io.json import json_normalize
from datetime import date
import base64
import requests
import sqlalchemy as sql
from datetime import datetime
import pytz
import traceback
#import boto3
from datetime import datetime, timedelta

hostname = 'apsez-as1-analytics-prod-rds.cpjhdhjkpglj.ap-south-1.rds.amazonaws.com'
username = 'pgadmin'
password = 'Adani$#390'
database = 'analytics'

def connect_to_api():
    client_id="BPhJuiDitbGiGcUrlLmb1BFppYYa"
    client_secret="3qIfyuY2Zkf4LlXJfUCDrFpfYVca"

    auth = f"{client_id}:{client_secret}"
    auth = auth.encode("ascii")
    auth_bytes = base64.b64encode(auth)
    encoded_auth = auth_bytes.decode("ascii")

    url2 = "https://gw.crisapis.indianrail.gov.in/token"

    payload2='grant_type=client_credentials'
    headers2 = {
    'Authorization': f'Basic {encoded_auth}',
    'Content-Type': 'application/x-www-form-urlencoded'
    }

    response2 = requests.request("POST", url2, headers=headers2, data=payload2)
    data_from_api2 = response2.json()
    df2 = pd.json_normalize(data_from_api2)
    token_a = df2['access_token'][0]
    print(token_a)


    print('Bearer '+token_a)

    dt = datetime.now(pytz.timezone('Asia/Kolkata'))
    dt2 = dt-timedelta(days=1)
    dt3 = dt2.strftime('%d-%m-%Y')
    print(dt3)


    url_r = "https://gw.crisapis.indianrail.gov.in/t/fois.cris.in/FoisADIL/1.0/rrdata?rrdate={0}".format(dt3)
    print(url_r)


    headers_r = {
    'accept': '*/*',
    'userid': 'adildownload@ecust',
    'password': 'adilonline@123',
    'Authorization': 'Bearer '+token_a
      
    }

    response_r =  requests.get(url_r, headers=headers_r)
      
    data_from_api_r = response_r.json()
    print(f"This is data from API - {data_from_api_r}")


    df_container_details = pd.DataFrame(data_from_api_r[0]['containerDtls'])
        

connect_to_api()


