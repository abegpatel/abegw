import argparse
import json
import os
import logging
import apache_beam as beam
from apache_beam.options.pipeline_options import PipelineOptions, StandardOptions
from google.cloud import storage
from google.cloud import bigquery
from apache_beam import window


from google.cloud import bigquery_storage_v1
from google.cloud.bigquery_storage_v1 import types
from google.cloud.bigquery_storage_v1 import writer
from google.protobuf import descriptor_pb2

import customer_record_pb2


logging.basicConfig(level=logging.INFO)
logging.getLogger().setLevel(logging.INFO)

os.environ["GOOGLE_APPLICATION_CREDENTIALS"]="apsez-svc-dev-datalake.json"
#INPUT_SUBSCRIPTION = "projects/apsez-svc-dev-datalake/subscriptions/CT1IPUAT.ANALYTICS_USER1.TEST_TABLES-sub"

import pandas as pd
import pytz
from google.cloud import bigquery  
    

 # Storage API Code
project_id='apsez-svc-dev-datalake'
dataset_id='ANALYTICS_USER1'
table_id='testtable1'

def create_row_data(row_num: int, name: str):
            row = customer_record_pb2.CustomerRecord()
            row.row_num = row_num
            row.customer_name = name
            return row.SerializeToString()

def append_rows_pending():
            """Create a write stream, write some sample data, and commit the stream."""
            write_client = bigquer