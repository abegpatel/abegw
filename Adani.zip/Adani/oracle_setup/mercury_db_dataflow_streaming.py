import argparse
import json
import os
import logging
import apache_beam as beam
from apache_beam.options.pipeline_options import PipelineOptions, StandardOptions

logging.basicConfig(level=logging.INFO)
logging.getLogger().setLevel(logging.INFO)

# Service account key path
#os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = "/home/akash_yadav042119/PythonScripts/project-python-330110-8a147dea0659.json"
# INPUT_SUBSCRIPTION = "projects/project-python-330110/subscriptions/streaming_topic_1-sub"
INPUT_SUBSCRIPTION = "projects/apsez-svc-dev-datalake/subscriptions/MercuryDB.dbo.tblVesselCargoInfoOracle-sub"
BIGQUERY_TABLE = "apsez-svc-dev-datalake:MercuryDB_Replica.tblVesselCargoInfoOracle"
BIGQUERY_SCHEMA = "ETLID:NUMERIC,VSL_WK_COMPLT_USER_ID:NUMERIC,VSL_WK_COMPLT_DTTM:STRING,VSL_NM:STRING,VSL_MAX_HT:NUMERIC,VSL_CD:STRING,VOY_TRANSIT_FLG:STRING,VOY_REG_DTTM:STRING,VIA_NO:STRING,TUG_NRT:FLOAT,TUG_GRT:FLOAT,TPC:NUMERIC,SENT_BERALT_FLG:STRING,SAILD_FLG:STRING,ROTATION_NO:STRING,ROTATION_DTTM:STRING,ROTATION_CSTM_SITE_CD:STRING,REC_TYPE:STRING,PCS_VSL_CAT_CD:STRING,PCS_CMN_REF_NO:STRING,MSG_HDR_ID:NUMERIC,MRN_INVC_CLOSURE_INT_USER_ID:NUMERIC,MRN_INVC_CLOSURE_DTTM:STRING,MRN_CLOSURE_INT_USER_ID:NUMERIC,MRN_CLOSURE_FLG:STRING,MRN_CLOSURE_DTTM:STRING,MOTHER_FEEDER_BARGE_IND:STRING,MAIN_LINE_CD:STRING,MAIDEN_FLG:STRING,LEGACY_IMP_VOY_NO:STRING,LEGACY_EXP_VOY_NO:STRING,LD_VOY_NO:STRING,LD_TRADE_CD:STRING,LD_ROUTE_CD:STRING,LD_MNF_CLOSE_FLG:STRING,IS_VSL_DEFD_FLG:STRING,INT_VIA_NO:NUMERIC,IGM_RMRK:STRING,IGM_DTTM:STRING,EXT_VOY_FLG:STRING,ETD_DTTM:STRING,ETA_DTTM:STRING,EGM_RMRK:STRING,EGM_DTTM:STRING,EDI_FLG:STRING,DUMMY_VOY_FLG:STRING,DSCH_VOY_NO:STRING,DSCH_TRADE_CD:STRING,DSCH_LD_BOTH_IND:STRING,DEFN_STAGE_IND:STRING,DECK_CRG_GRT:FLOAT,CNSRTM_CD:STRING,BU_CD:STRING,BU_DESCR:STRING,BUNKER_VSL_FLG:STRING,BERTH_TYPE:STRING,BERTH_PRIORITY:STRING,ATUB_DTTM:STRING,ATHWART_STOWED_FLG:STRING,ATD_DTTM:STRING,ATB_DTTM:STRING,ATA_DTTM:STRING,VSL_BEAM:FLOAT,VSL_WIDTH:FLOAT,VSL_OVR_LEN:NUMERIC,PONT_MV_TM:NUMERIC,MIN_DRAFT_FORE:FLOAT,SUB_VSL_CAT_CD:STRING,DEPTH_MOULDED:NUMERIC,VSL_WK_AREA:NUMERIC,VSL_APP_FLG:STRING,VSL_GEARLESS:STRING,REDU_GRT_FLG:STRING,REDU_GRT:FLOAT,CNTRY_CD:STRING,LOG_DTTM:STRING,MANUF_DTTM:STRING,VSL_GRP_CD:STRING,VSL_CAT_CD:STRING,CALL_SIGN:STRING,PORT_OF_REG:STRING,VSL_CLASS:STRING,AGENT_CD:STRING,VSL_CELL_TYPE:STRING,SATELLITE_ID:STRING,WT_CAT_DEFN_CD:STRING,ROUTE_CD:STRING,PREF_BERTH_TO_BLRD:STRING,PREF_BERTH_NO:STRING,VSL_BAY_DEFN_CD:STRING,VSL_TYPE:STRING,VSL_SHORT_NM:STRING,PREF_BERTH_SIDE:STRING,QUAY_CD:STRING,LINE_CD:STRING,IMO_NO:STRING,DISPLACEMENT:NUMERIC,INT_VSL_CD:NUMERIC,NRT:FLOAT,PREF_BERTH_TO_MM:NUMERIC,VSL_HT:FLOAT,BERTH_TM:NUMERIC,HEADERGRT:FLOAT,MAX_DRAFT_FORE:FLOAT,MAX_DRAFT_AFT:FLOAT,MAX_DRAFT:NUMERIC,NT:FLOAT,GT:FLOAT,MIN_DRAFT:NUMERIC,SC_TORSION:NUMERIC,DIST_UD_ROW_PORTSD:FLOAT,DIST_UD_BAY_STERN:FLOAT,DIST_DK_ROW_STARSD:FLOAT,MIN_DRAFT_AFT:FLOAT,DECK_CRG:NUMERIC,PORT_CD:STRING,NDC_AGENT_CD:STRING,DEAD_WT:FLOAT,NDC_DTTM:STRING,NDC_NO:STRING,SHORE_CRN_CNT:NUMERIC,SHIP_CRN_CNT:NUMERIC,DSCH_PORT_RMRK:STRING,LD_PORT_RMRK:STRING,NOR_DTTM:STRING,PHO_CLEAR_DTTM:STRING,CSTM_EGM_DTTM:STRING,NEXT_PORT_CD:STRING,LAST_PORT_CD:STRING,CSTM_EGM_NO:STRING,DSCH_VSL_AGENT_CD:STRING,LD_VSL_AGENT_CD:STRING,ARR_DRAFT:NUMERIC,DRAFT:NUMERIC,ACT_ARR_DRAFT_AFT:NUMERIC,ACT_ARR_DRAFT_FORE:NUMERIC,VSL_FREE_BOARD:NUMERIC,VSL_NOR_DTTM:STRING,BASE_STS:STRING,CMDT_CD:STRING,CRG_TYPE:STRING,FOREIGN_COASTAL_IND:STRING,PKG_TYPE:STRING,RESTOW_TYPE:STRING,TOT_WT:NUMERIC,UNIT_CNT:NUMERIC,UNIT_WT:NUMERIC,COMMODITY:STRING,COMMODITY_TYPE:STRING,COMMODITY_TYPE_CODE:STRING,GRT:NUMERIC,HATCH:STRING,CHARTER_RATE:STRING,PORTID:NUMERIC,SHIPPER_RECIEVER:STRING,AGENT:STRING,FIRST_PILOT_REQUEST_TIME:STRING,FLAG:STRING,CARGO_TYPE_DESCR:STRING,LAST_PORT_OF_CALL:STRING,INMARSAT:STRING,MMSI_NO:STRING,NEXT_PORT_OF_CALL:STRING,IGM_WT:NUMERIC,EGM_WT:NUMERIC,BUDGET_VSL_CNT:FLOAT,BUDGET_GRT:FLOAT,BUDGET_TOT_WT:FLOAT,BUDGET_TEUS:FLOAT,EFF_DTTM:STRING,VSL_CAT:STRING,UPD_DTTM:STRING,DECLARED_SBU:STRING,COUNTRY:STRING,DECLARED_SBU_DESCR:STRING,VSL_GROUP:STRING,SUB_VSL_CAT:STRING,SURVEYOR_BOARD_DTTM:STRING,SURVEYOR_UNBOARD_DTTM:STRING,Ullage_Fm_Dttm:STRING,Ullage_To_Dttm:STRING,CRG_SEQ_ID:NUMERIC,CSTM_BOARD_DTTM:STRING,CSTM_CLEARED_DTTM:STRING,INSERT_DTTM:STRING,INS_UPD_DTTM:STRING,TimeStamp:STRING,Deleted:BOOL,Deleted_CMDT:BOOL,MRN_POC_CLOSURE_DTTM:STRING,MRN_POC_CLOSURE_INT_USER_NM:STRING,MRN_STVDR_CLOSURE_DTTM:STRING,Dsch_Port_Name:STRING,Ld_Port_Name:STRING,arr_draft_fore:NUMERIC,arr_draft_aft:NUMERIC,dep_draft_fore:NUMERIC,dep_draft_aft:NUMERIC,SouceName:STRING,operation:STRING,msg_published_time:TIMESTAMP"

class CustomParsing(beam.DoFn):
    """ Custom ParallelDo class to apply a custom transformation """
    def to_runner_api_parameter(self, unused_context):
        # Not very relevant, returns a URN (uniform resource name) and the payload
        return "beam:transforms:custom_parsing:custom_v0", None

    def process(self, element: bytes, timestamp=beam.DoFn.TimestampParam, window=beam.DoFn.WindowParam):
        import pandas as pd

        parsed = json.loads(element.decode("utf-8"))
        payload_data = parsed['payload']
        
        intermediate_data = {}
        if payload_data['before'] == None or 'before' not in payload_data:
            intermediate_data = payload_data['after']
            intermediate_data['operation'] = "INSERT"
        elif payload_data['after'] == None or 'after' not in payload_data:
            intermediate_data = payload_data['before']
            intermediate_data['operation'] = "DELETE"    
        else:
            intermediate_data = payload_data['after']
            intermediate_data['operation'] = "UPDATE-INSERT"
            
        df = pd.json_normalize(intermediate_data).to_dict(orient='records')[0]    
        df['msg_published_time'] = timestamp.to_rfc3339()

        print(df)
        yield df

def run():
    # Parsing arguments
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--input_subscription",
        help='Input PubSub subscription of the form "projects/<PROJECT>/subscriptions/<SUBSCRIPTION>."',
        default=INPUT_SUBSCRIPTION,
    )
    parser.add_argument(
        "--output_table", help="Output BigQuery Table", default=BIGQUERY_TABLE
    )
    parser.add_argument(
        "--output_schema",
        help="Output BigQuery Schema in text format",
        default=BIGQUERY_SCHEMA,
    )
    known_args, pipeline_args = parser.parse_known_args()

    # Creating pipeline options
    pipeline_options = PipelineOptions(pipeline_args)
    pipeline_options.view_as(StandardOptions).streaming = True

    # Defining our pipeline and its steps
    with beam.Pipeline(options=pipeline_options) as p:
        (
            p
            | "ReadFromPubSub" >> beam.io.gcp.pubsub.ReadFromPubSub(
                subscription=known_args.input_subscription, timestamp_attribute=None
            )
            | "CustomParse" >> beam.ParDo(CustomParsing())
            | "WriteToBigQuery" >> beam.io.WriteToBigQuery(
                known_args.output_table,
                schema=known_args.output_schema,
                write_disposition=beam.io.BigQueryDisposition.WRITE_APPEND,
            )
        )


if __name__ == "__main__":
    run()
