import argparse
import json
import os
import logging
import apache_beam as beam
from apache_beam.options.pipeline_options import PipelineOptions, StandardOptions
from google.cloud import storage
from google.cloud import bigquery_datatransfer
from apache_beam import window

#client = storage.Client()

logging.basicConfig(level=logging.INFO)
logging.getLogger().setLevel(logging.INFO)

# Service account key path
#os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = "/home/akash_yadav042119/PythonScripts/project-python-330110-8a147dea0659.json"


# INPUT_SUBSCRIPTION = "projects/project-python-330110/subscriptions/streaming_topic_1-sub"
INPUT_SUBSCRIPTION = "projects/apsez-svc-dev-datalake/subscriptions/CT1IPUAT.ANALYTICS_USER1.TEST_TABLES-sub"

class CustomParsing(beam.DoFn):
    
    """ Custom ParallelDo class to apply a custom transformation """
    def to_runner_api_parameter(self, unused_context):
        # Not very relevant, returns a URN (uniform resource name) and the payload
        return "beam:transforms:custom_parsing:custom_v0", None
  
    def process(self, element: bytes, timestamp=beam.DoFn.TimestampParam, window=beam.DoFn.WindowParam):
        import pandas as pd
        import pandas_gbq as pdq
        logging.info('installing lib')
        os.system('pip3 install pandas_gbq')
        #from google.cloud import bigquery_datatransfer

        #DYNAMIC SCHEMA EXTRACTION CODE BLOCK
        parsed = json.loads(element.decode("utf-8"))
        after_schema = parsed['schema']['fields'][1]
        debezium_schema = after_schema['fields']
        logging.info('creating schema of table')
        intermediate_schema ={}
        for i in debezium_schema:
            if i['type'] == 'int' or i['type'] == 'int32' or i['type'] == 'int64':
                intermediate_schema[i['field']] = 'INTEGER'
            elif i['type'] == 'string' or i['type'] == 'varchar' or i['type'] == 'varchar2':
                intermediate_schema[i['field']] = 'STRING'
            elif i['type'] == 'float' or i['type'] == 'float32' or i['type'] == 'float64':
                intermediate_schema[i['field']] = 'FLOAT'
            elif i['type'] == 'date':
                intermediate_schema[i['field']] = 'DATE'
            elif i['type'] == 'datetime':
                intermediate_schema[i['field']] = 'DATETIME'
            elif i['type'] == 'timestamp':
                intermediate_schema[i['field']] = 'TIMESTAMP'
        
        bigquery_schema = []
        for k,v in intermediate_schema.items():
            element_list={'name':k,'type':v}
            bigquery_schema.append(element_list)
        bigquery_schema.append({'name':'operation','type':'STRING'})
        bigquery_schema.append({'name':'msg_published_time','type':'TIMESTAMP'})
        
        print("BQ SCHEMA STRING:",bigquery_schema,"\n")
        
        logging.info('checking operation...')
        #BQ TABLE NAME CREATION
        payload_data = parsed['payload']
        debezium_table_name1 = payload_data['source']['schema']
        debezium_table_name2 = payload_data['source']['table']
        BIGQUERY_TABLE = "apsez-svc-dev-datalake"+"."+debezium_table_name1+"."+debezium_table_name2
        #BIGQUERY_TABLE = "apsez-svc-dev-datalake.debezium_stagging_table"+"."+debezium_table_name2
        intermediate_data = {}
        if payload_data['before'] == None or 'before' not in payload_data:
            intermediate_data = payload_data['after']
            intermediate_data['operation'] = "INSERT"
        elif payload_data['after'] == None or 'after' not in payload_data:
            intermediate_data = payload_data['before']
            intermediate_data['operation'] = "DELETE"    
        else:
            intermediate_data = payload_data['after']
            intermediate_data['operation'] = "UPDATE-INSERT"
            
        df = pd.DataFrame(intermediate_data,index=[1])  
        df['msg_published_time'] = timestamp.to_rfc3339()
        
        #WRITE_TO_BIGQUERY
        #yield df

        try:
            logging.info('loading data into bq table')
            pdq.to_gbq(df,BIGQUERY_TABLE,if_exists='append',table_schema=bigquery_schema,api_method="load_csv")  
        except  Exception as e:
            print('Error -',e)
            logging.info(e)

    def mergingtable():
       from google.cloud import bigquery
       client = bigquery.Client()
       query = """CALL debezium_replica.debezium_test_replica_creator_ctrddls_o()"""
       job = client.query(query)
       print("Executed")

def run():
    # Parsing arguments
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--input_subscription",
        help='Input PubSub subscription of the form "projects/<PROJECT>/subscriptions/<SUBSCRIPTION>."',
        default=INPUT_SUBSCRIPTION,
    )
    known_args, pipeline_args = parser.parse_known_args()

    # Creating pipeline options
    pipeline_options = PipelineOptions(pipeline_args)
    pipeline_options.view_as(StandardOptions).streaming = True

    # Defining our pipeline and its steps
    # with beam.Pipeline(options=pipeline_options) as p:
    #     (
           
    #         p | "ReadFromPubSub" >> beam.io.gcp.pubsub.ReadFromPubSub(subscription=known_args.input_subscription, timestamp_attribute=None)
    #           | "Processing and WriteToBQ" >> beam.ParDo(CustomParsing())
             
    #         p | "Dummy" >> beam.Create(['1'])
    #           | "windowing" >> beam.WindowInto(window.FixedWindows(60))
    #           | "mergelogic" >> beam.Map(mergingtable())

    #     )
    #options = PipelineOptions()
    pcoll = beam.Pipeline(options = pipeline_options)
    #dummy = pcoll | 'Initializing..' >> beam.Create(['1'])
    Data = (pcoll | 'ReadFromPubSub' >> beam.io.gcp.pubsub.ReadFromPubSub(subscription=known_args.input_subscription, timestamp_attribute=None))
    WriteToBQSTG = ( Data | "Processing and WriteToBQ" >> beam.ParDo(CustomParsing()))
    #WriteToBQREPLICA = ( Data | 'mergelogic' >> beam.Map(mergingtable))  
if __name__ == "__main__":
    run()
