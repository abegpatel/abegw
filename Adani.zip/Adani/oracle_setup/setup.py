import setuptools

setuptools.setup(
    name='set_libs',
    version='0.1.1',
    packages=setuptools.find_packages(),
    install_requires=['pandas'],
    data_files=[(".",["test_employee_pb2.py","test_customers_pb2.py"])],
    include_package_data=True
    
)
