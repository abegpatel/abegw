import argparse
import json
import os
import logging
import apache_beam as beam
from apache_beam.options.pipeline_options import PipelineOptions, StandardOptions
from google.cloud import storage



client = storage.Client()

logging.basicConfig(level=logging.INFO)
logging.getLogger().setLevel(logging.INFO)

# Service account key path
#os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = "/home/akash_yadav042119/PythonScripts/project-python-330110-8a147dea0659.json"

INPUT_SUBSCRIPTION = "projects/apsez-svc-dev-datalake/subscriptions/ENIPPRD.TOS_USR.CTROTHDTLS_O-sub"



BIGQUERY_TABLE = "apsez-svc-dev-datalake:Test_Dev.CTROTHDTLS_O_stg"
BIGQUERY_SCHEMA ="CTR_NO:STRING,LIFE_NO:INTEGER,CTR_WEIGH_FLG:STRING,BKNG_NO:STRING,ENTRY_MODE:STRING,EXIT_MODE:STRING,EXPT_LD_VSL_CD:STRING,FPD:STRING,POD:STRING,POL:STRING,INSIDE_CHK_DONE_FLG:STRING,RORO_LOLO_IND:STRING,ENTRY_MODE_TYPE:STRING,EXIT_MODE_TYPE:STRING,INVC_RQRD_FLG:STRING,INVC_FLG:STRING,CMDT_CD:STRING,EMPTY_CTR_CHK_STS:STRING,LD_INSTR_CD:STRING,LINER_TERM:STRING,SPL_USE_CD:STRING,STUFF_STRP_CD:INTEGER,TRANSSHIP_IND:STRING,WATER_HZ_CLS:STRING,ENTRY_DTTM:INTEGER,EXIT_DTTM:INTEGER,STUFF_STRP_DTTM:INTEGER,INVC_LINE_CD:STRING,ENTRY_INT_YD_TMNL_NO:INTEGER,EXIT_INT_YD_TMNL_NO:INTEGER,ADT_INS_DTTM:INTEGER,ADT_UPD_DTTM:INTEGER,INT_BKNG_NO:INTEGER,TRNSPT_DOC_NO:STRING,DUS_NO:STRING,CSTM_AGENT_CD:STRING,BL_RMRKS:STRING,BKNG_SEQ_NO:INTEGER,WEIGHBRIDGE_WT:FLOAT64,IMP_DOC_WT:FLOAT64,IMP_DOC_NO:STRING,IMP_DOC_DESCR:STRING,IMP_DOC_DTTM:INTEGER,INLAND_ORIGIN:STRING,HAUL_CD:STRING,EDI_FLG:STRING,SPL_ATTRIB_FLG:STRING,ITT_FLG:STRING,URGENT_DLVRY_FLG:STRING,INLAND_DEST:STRING,CSTM_REF_NO:STRING,BL_NO:STRING,CNSGN_S_DESCR:STRING,CTR_LEAKG_FLG:STRING,CTR_PIN:INTEGER,DELVRY_GRP_CD:STRING,EXT_INBOUND_INT_VCN_NO:INTEGER,EXT_OUTBOUND_INT_VCN_NO:INTEGER,FRWDR_S_DESCR:STRING,GRP_CD:STRING,INBOUND_TRAIN_NO:STRING,INFO_STS:STRING,INHLN_HZ_FLG:STRING,INSTR_CD:STRING,INT_DO_NO:INTEGER,INT_EARLY_LATE_RECVL_NO:INTEGER,OUTBOUND_TRAIN_NO:STRING,PLAND_CHSS_NO:STRING,PLAND_DRVR_ID:STRING,PLAND_TRUCK_REGN_NO:STRING,RECVL_GRP_CD:STRING,REGULARISED_IND:STRING,RESPONB_PTY:STRING,SHPR_S_DESCR:STRING,SMTP_DTTM:INTEGER,SMTP_NO:STRING,S_REM:STRING,WGN_NO:STRING,INT_CTR_NO:INTEGER,INT_DG_REG_NO:INTEGER,ADT_VER_STAMP:INTEGER,ADT_INS_USR_CD:STRING,ADT_UPD_USR_CD:STRING,ADT_TXN_CD:STRING,ADT_TXN_NO:INTEGER,ADT_INS_EXT_USR_FLG:STRING,ADT_UPD_EXT_USR_FLG:STRING,INT_BL_NO:INTEGER,DEPOT_CD:STRING,STEVEDORE_RMRK:STRING,PRIO_RMRK:STRING,POO:STRING,DEPOT_ORIGIN_CD:STRING,DEPOT_DEST_CD:STRING,OTH_ITT_FLG:STRING,SPL_STS:STRING,DRF_PRINT_SEQ_CD:STRING,SUB_LINE_NO:INTEGER,CRG_DESCR:STRING,CSNE_NM:STRING,CSNE_ADDR:STRING,RLS_UNTIL_DT:INTEGER,DRAY_FLG:STRING,RF_TAG_ID:STRING,DLVRY_OTH_ITT_FLG:STRING,IGM_NO:STRING,IGM_DTTM:INTEGER,SPL_STK_CD:STRING,LCL_SHARE_FLG:STRING,OT_DSCH_DTTM:INTEGER,PRE_GATE_FLG:STRING,PIN_NO:STRING,EXP_CSTM_CLRNCE_FLG:STRING,DUMMY_FLG:STRING,CHRGBL_PTY:STRING,GCR_FLG:STRING,MAIDEN_FLG:STRING,IMCO_LBL_EXISTS:STRING,DO_EXP_OVERRIDE_DATE:INTEGER,NON_INV_AGE:FLOAT64,TRNS_ADVICE_DTTM:INTEGER,MANIFEST_FLG:STRING,VOY_SEP_CD:STRING,CUST_APPROVAL_STS:STRING,CUST_PROCESSED_DTTM:INTEGER,LINE_NO:STRING,CUSTOM_FLAG:STRING,CUSTOM_PRCNT:INTEGER,DPD_FLAG:STRING,DLVRBLE_PTY:STRING,SCAN_FLG:STRING,SCAN_TYPE:STRING,PALLET_CNT:INTEGER,QTY:INTEGER,CRG_CONDITION:STRING,TNE_BOND_REF_NO:STRING,BORDER_SECURITY_POINT:STRING,FRWDR_NM:STRING,DPE_FLG:STRING,DPE_RPCT_PTY:STRING,MISC_PTY_CD:STRING,DLVY_ADDR_CD:STRING,BDL_IND_ENT:STRING,BDL_IND_EXT:STRING,MASTER_UNIT_ENT:INTEGER,MASTER_UNIT_EXT:INTEGER,operation:STRING,msg_published_time:TIMESTAMP" 



class CustomParsing(beam.DoFn):
    """ Custom ParallelDo class to apply a custom transformation """
    def to_runner_api_parameter(self, unused_context):
        # Not very relevant, returns a URN (uniform resource name) and the payload
        return "beam:transforms:custom_parsing:custom_v0", None

    def process(self, element: bytes, timestamp=beam.DoFn.TimestampParam, window=beam.DoFn.WindowParam):
        import pandas as pd

        parsed = json.loads(element.decode("utf-8"))
        payload_data = parsed['payload']
        
        intermediate_data = {}
        if payload_data['before'] == None or 'before' not in payload_data:
            intermediate_data = payload_data['after']
            intermediate_data['operation'] = "INSERT"
        elif payload_data['after'] == None or 'after' not in payload_data:
            intermediate_data = payload_data['before']
            intermediate_data['operation'] = "DELETE"    
        else:
            intermediate_data = payload_data['after']
            intermediate_data['operation'] = "UPDATE-INSERT"
            
        df = pd.json_normalize(intermediate_data).to_dict(orient='records')[0]
        df['msg_published_time'] = timestamp.to_rfc3339()

        print(df)
        yield df
		
def mergingtable(element):
    from google.cloud import bigquery
    import time
    while True:
      time.sleep(60)
      try:
             client = bigquery.Client()
             logging.info('Executing Query')
             query_job = client.query("""CALL `apsez-svc-dev-datalake.Test_Dev.CTROTHDTLS_O_SP`();""")
             results = query_job.result() 
             logging.info(results)
      except Exception as e:
             logging.info(e)	   

def run():
    # Parsing arguments
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--input_subscription",
        help='Input PubSub subscription of the form "projects/<PROJECT>/subscriptions/<SUBSCRIPTION>."',
        default=INPUT_SUBSCRIPTION,
    )
    parser.add_argument(
        "--output_table", help="Output BigQuery Table", default=BIGQUERY_TABLE
    )
    parser.add_argument(
        "--output_schema",
        help="Output BigQuery Schema in text format",
        default=BIGQUERY_SCHEMA,
    )
    known_args, pipeline_args = parser.parse_known_args()

    # Creating pipeline options
    pipeline_options = PipelineOptions(pipeline_args)
    pipeline_options.view_as(StandardOptions).streaming = True

    # Defining our pipeline and its steps
    # with beam.Pipeline(options=pipeline_options) as p:
        # (
            # p
            # | "ReadFromPubSub" >> beam.io.gcp.pubsub.ReadFromPubSub(
                # subscription=known_args.input_subscription, timestamp_attribute=None
            # )
            # | "CustomParse" >> beam.ParDo(CustomParsing())
            # | "WriteToBigQuery" >> beam.io.WriteToBigQuery(
                # known_args.output_table,
                # schema=known_args.output_schema,
                # write_disposition=beam.io.BigQueryDisposition.WRITE_APPEND,
            # )
        # )
    with beam.Pipeline(options=pipeline_options) as p:
      input_data = ( p | "ReadFromPubSub" >> beam.io.gcp.pubsub.ReadFromPubSub(subscription=known_args.input_subscription, timestamp_attribute=None))
      stagging_table  = ( input_data | "WriteToStaggingTable" >> beam.ParDo(CustomParsing()) 
	                                 | "WriteToBigQuery" >> beam.io.WriteToBigQuery(
                                                            known_args.output_table,
                                                            schema=known_args.output_schema,
                                                            write_disposition=beam.io.BigQueryDisposition.WRITE_APPEND,
            ))
      merging_table = ( p | "Start_Merge_Operation" >> beam.Create(['1']) | "WriteToMergeTable" >> beam.Map(mergingtable))	


if __name__ == "__main__":
    run()
