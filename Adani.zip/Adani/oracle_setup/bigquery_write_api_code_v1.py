import argparse
import json
import os
import logging
import apache_beam as beam
from apache_beam.options.pipeline_options import PipelineOptions, StandardOptions
from google.cloud import storage
from google.cloud import bigquery
import pandas as pd

from google.cloud import bigquery_storage_v1
from google.cloud.bigquery_storage_v1 import types
from google.cloud.bigquery_storage_v1 import writer
from google.protobuf import descriptor_pb2

import test_employee_pb2


logging.basicConfig(level=logging.INFO)
logging.getLogger().setLevel(logging.INFO)

os.environ["GOOGLE_APPLICATION_CREDENTIALS"]="apsez-svc-dev-datalake.json"
INPUT_SUBSCRIPTION = "projects/apsez-svc-dev-datalake/subscriptions/CT1IPUAT.ANALYTICS_USER1.TEST_TABLES-sub"



# Storage API Code

class CustomParsing(beam.DoFn):
    """ Custom ParallelDo class to apply a custom transformation """
    def to_runner_api_parameter(self, unused_context):
        return "beam:transforms:custom_parsing:custom_v0", None
    def setup(self):
        try:
            logging.info('copying files')
            from google.cloud import bigquery_storage_v1
            from google.cloud.bigquery_storage_v1 import types
            from google.cloud.bigquery_storage_v1 import writer
            from google.protobuf import descriptor_pb2
            import pandas as pd


            ############## NED TO FI ###############
            os.system('if [ ! -f test_employee_pb2.py ]; then gsutil cp gs://apsez_dataflow_test/dataflow_test_code/test_employee_pb2.py . && chmod 777 test_employee_pb2.py; fi')

            ############################################################

            logging.info('File Copied')
        except Exception as e:
            logging.exception(e)
            raise
    def process(self, element: bytes, timestamp=beam.DoFn.TimestampParam):
        from google.cloud import bigquery_storage_v1
        from google.cloud.bigquery_storage_v1 import types
        from google.cloud.bigquery_storage_v1 import writer
        from google.protobuf import descriptor_pb2
        import pandas as pd


        ######## NEED O FIX - IMPORT SHOULD BE DONE AFTER MSG READ ######################
        import test_employee_pb2
        
        ###########################################################

		#BQ TABLE NAME CREATIOn
        parsed = json.loads(element.decode("utf-8"))
        payload_data = parsed['payload']
        dataset_id = payload_data['source']['schema']
        table_id = payload_data['source']['table']
        project_id = "apsez-svc-dev-datalake"
		
		#Create a write stream, write some sample data, and commit the stream.
		
        write_client = bigquery_storage_v1.BigQueryWriteClient()
        parent = write_client.table_path(project_id, dataset_id, table_id)
        write_stream = types.WriteStream()
        
        write_stream.type_ = types.WriteStream.Type.PENDING
        write_stream = write_client.create_write_stream(parent=parent, write_stream=write_stream)
        stream_name = write_stream.name

		# Create a template wiith fields needed for the first request.
        request_template = types.AppendRowsRequest()

		# The initial request must contain the stream name.
        request_template.write_stream = stream_name

		# So that BigQuery knows how to parse the serialized_rows, generate a
		# protocol buffer representation of your message descriptor.
        proto_schema = types.ProtoSchema()
        proto_descriptor = descriptor_pb2.DescriptorProto()

        ##### NEED TO FIX ########

        test_employee_pb2.EmployeeRecord.DESCRIPTOR.CopyToProto(proto_descriptor)

        ##########################################################

        proto_schema.proto_descriptor = proto_descriptor
        proto_data = types.AppendRowsRequest.ProtoData()
        proto_data.writer_schema = proto_schema
        request_template.proto_rows = proto_data
        append_rows_stream = writer.AppendRowsStream(write_client, request_template)
        proto_rows = types.ProtoRows()

		# DATA EXTRACTION
		
        intermediate_data = {}
        if payload_data['before'] == None or 'before' not in payload_data:
            intermediate_data = payload_data['after']
            intermediate_data['OPERATION'] = "INSERT"
        elif payload_data['after'] == None or 'after' not in payload_data:
            intermediate_data = payload_data['before']
            intermediate_data['OPERATION'] = "DELETE"
        elif payload_data['before'] == None and payload_data['after'] == None:
            intermediate_data['ID'] = 0
            intermediate_data['NAME'] = 'NODATA'
            intermediate_data['IDNO'] = 0
            intermediate_data['OPERATION'] = "NO_OPERATION"
        else:
            intermediate_data = payload_data['after']
            intermediate_data['OPERATION'] = "UPDATE-INSERT"

        df = pd.DataFrame(intermediate_data,index=[1])

        
        df['MSG_PUBLISHED_TIME'] = timestamp.to_rfc3339()
        df1 = df.to_records(index=False)
        logging.info(df1)
		

        #################             NEED TO FIX         ####################        
	# DATA INSERATION
        row = test_employee_pb2.EmployeeRecord()

        ID = intermediate_data['ID']
        NAME = intermediate_data['NAME']
        IDNO =  intermediate_data['IDNO']
        OPERATION = intermediate_data['OPERATION']
        MSG_PUBLISHED_TIME = int(timestamp)
        
        row.ID = ID
        row.NAME= NAME
        row.IDNO = IDNO
        row.OPERATION = OPERATION
        row.MSG_PUBLISHED_TIME = MSG_PUBLISHED_TIME
        #logging.info(row.SerializeToSring())
        #return row.SerializeToString()


        ############################################################################
 
        proto_rows.serialized_rows.append(row.SerializeToString())

		# PROTO BUFFER
        request = types.AppendRowsRequest()
        request.offset = 0
        proto_data = types.AppendRowsRequest.ProtoData()
        proto_data.rows = proto_rows
        request.proto_rows = proto_data
        
        response_future_1 = append_rows_stream.send(request)
        append_rows_stream.close()
        
        write_client.finalize_write_stream(name=write_stream.name)

		# Commit the stream you created earlier.
        batch_commit_write_streams_request = types.BatchCommitWriteStreamsRequest()
        batch_commit_write_streams_request.parent = parent
        batch_commit_write_streams_request.write_streams = [write_stream.name]
        write_client.batch_commit_write_streams(batch_commit_write_streams_request)
        logging.info(f"Writes to stream: '{write_stream.name}' have been committed.")
def run():
    # Parsing arguments
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--input_subscription",
        help='Input PubSub subscription of the form "projects/<PROJECT>/subscriptions/<SUBSCRIPTION>."',
        default=INPUT_SUBSCRIPTION,
    )
   
    known_args, pipeline_args = parser.parse_known_args()
    # Creating pipeline options
    pipeline_options = PipelineOptions(pipeline_args)
    pipeline_options.view_as(StandardOptions).streaming = True
    # Defining our pipeline and its steps
    with beam.Pipeline(options=pipeline_options) as p:
      input_data = ( p | "ReadFromPubSub" >> beam.io.gcp.pubsub.ReadFromPubSub(subscription=known_args.input_subscription, timestamp_attribute=None))
      Stagging_Table  = ( input_data | "StaggingTable" >> beam.ParDo(CustomParsing()))
                                     
if __name__ == "__main__":
    run()

