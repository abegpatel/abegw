import pandas as pd
from google.cloud import bigquery

# Example data
df = pd.read_csv('gs://test_cloud_fucntion/T1/cloudfunctiontest1.csv')

# Load client
client = bigquery.Client(project='apsez-svc-dev-datalake')

# Define table name, in format dataset.table_name
table = 'Test_Dev.PG_Details4'

BigQuery_Schema = [{"name":"schema_name","type":"STRING"},{"name":"pg_size_pretty","type":"STRING"}]

job_config = bigquery.LoadJobConfig(
    # Specify a (partial) schema. All columns are always written to the
    # table. The schema is used to assist in data type definitions.
    schema=BigQuery_Schema,
    # [
        # bigquery.SchemaField("title", bigquery.enums.SqlTypeNames.STRING),
        # bigquery.SchemaField("wikidata_id", bigquery.enums.SqlTypeNames.STRING),
    # ],
    write_disposition="WRITE_TRUNCATE",
)

# Load data to BQ
job = client.load_table_from_dataframe(
    df, table, job_config=job_config
)  # Make an API request.
job.result()  # Wait for the job to complete.
