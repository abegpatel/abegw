from flask import Flask,jsonify,request
import functions_framework
from flask_restx import Api,Resource,fields,Namespace,reqparse


app = Flask(__name__)
api = Api(app,version = '1.0',title ='Pricing Calculator API',description='A simple API to calculate total price')
ns = api.namespace('calculator',description='Price Calculation Operations')

# Expected input format
request_model = api.model('PricingInput',{
    'name' : fields.String(required = True,description = 'The item name'),
    'quantity': fields.Integer(required = True,description = 'The quanitity of items'),
    'price_per_unit': fields.Integer(required = True,description = 'The Price per unit'),
    'discount' : fields.Float(required = False,description = 'Optional discount percentage')
})

# for mulitple reqyest at the same time in a list
pricing_model  = api.model('PricingList',{
    'items': fields.List(fields.Nested(request_model),required=True,description='List of all Item to calculate total prices')
})

response_model = api.model('PricingOutput',{
    'total_price' : fields.Integer(required=True,description='The total price')
})

"""# fine grained validation
parser = reqparse.RequestParser()
parser.add_argument('quantity',type=int,required='Quantity must be positive integer')
parser.add_argument('unit_price',type=int,required='Unit price must be positive integer')
parser.add_argument('discount',type=int,required='Optional discount Percentage')"""

@functions_framework.http
def main(request):
    return app(request)


def validate_inputs(quantity,unit_price,discount):
    if quantity <= 0 or unit_price <= 0:
        return jsonify(message="Quantity and error price must be positive integer"),400
    if discount < 0 or discount > 100 :
        ns.abort(400,"Discount must be between 0 and 100")
    

@ns.route("/calculate")
class PricingCalculator(Resource):
    @ns.expect(request_model,Validate=True)
    @ns.marshal_with(response_model)
    @api.doc(responses={200:'Success',400:'Validation Error'})
    def post(self):
        data = api.payload
        # data = request.json
        item_name =data['name']
        quantity = data['quantity']
        unit_price = data['price_per_unit']
        discount = data.get('discount',0)

        validate_inputs(quantity,unit_price,discount)

        total_price = quantity * unit_price
        if discount:
            total_price-=total_price*(discount/100)

        return {'item_name':item_name ,'total_price':total_price},200



if __name__ == '__main__':
    app.run(debug=True)

